package com.oateam.capicoin

import android.graphics.Canvas
import kotlin.math.sin

/** Title + login screen: Google, e-mail or guest. Also auto-connects with a saved session. */
class LoginScene(g: Game) : Scene(g) {
    private val th = Themes.all[0]
    private val amb = Scenery.Ambience(g)
    private var t = 0f
    private var state = 0 // 0 checking, 1 login buttons, 2 connecting, 3 offline
    private var msg = ""
    private var googleOn = false

    private val bGoogle = Button(0f, 0f, 0f, 0f, "Entrar com Google", 0xFFFFFFFF.toInt()) { google() }
    private val bEmail = Button(0f, 0f, 0f, 0f, "Entrar com e-mail", 0xFF1E88E5.toInt()) { email() }
    private val bGuest = Button(0f, 0f, 0f, 0f, "Jogar como convidado", 0xFF43A047.toInt()) { guest() }
    private val bRetry = Button(0f, 0f, 0f, 0f, "TENTAR DE NOVO", 0xFFFB8C00.toInt()) { start() }
    private val bServer = Button(0f, 0f, 0f, 0f, "Servidor", 0xFF546E7A.toInt()) { server() }
    private val buttons = listOf(bGoogle, bEmail, bGuest, bRetry, bServer)

    override val inGame: Boolean get() = false

    override fun layout() {
        val y0 = g.H * 0.62f
        bGoogle.set(140f, y0, g.W - 280f, 130f); bGoogle.textSize = 48f
        bEmail.set(140f, y0 + 165f, g.W - 280f, 130f); bEmail.textSize = 48f
        bGuest.set(140f, y0 + 330f, g.W - 280f, 130f); bGuest.textSize = 48f
        bRetry.set(190f, y0 + 120f, g.W - 380f, 140f)
        bServer.set(g.W / 2 - 150f, g.H - 150f, 300f, 90f); bServer.textSize = 34f
        bGoogle.textColor = 0xFF37474F.toInt(); bGoogle.textOutline = 0xFFFFFFFF.toInt()
        for (b in listOf(bGoogle, bEmail, bGuest)) { b.labelDx = 44f; b.textSize = 46f }
    }

    override fun enter() { g.audio.startMusic(); start() }

    private fun start() {
        state = 0; msg = "Conectando..."
        g.net.call("GET", "/health") { r ->
            if (!r.ok) { state = 3; msg = "Não consegui falar com o servidor."; return@call }
            googleOn = r.j["google"].bool()
            if (g.settings.token != null) connect() else state = 1
        }
    }

    private fun connect() {
        state = 2; msg = "Carregando sua ilha..."
        g.refreshProfile { r ->
            when {
                r.ok -> proceed()
                r.status == 401 -> { g.settings.token = null; state = 1 }
                else -> { state = 3; msg = r.message }
            }
        }
    }

    private fun proceed() {
        g.host.requestNotifications()
        g.slot.layout(); g.village.layout()
        if (!g.settings.seenIntro) g.goto(CutsceneScene(g, Scripts.intro()) { g.settings.seenIntro = true; g.goto(g.slot) })
        else g.goto(g.slot)
    }

    private fun gotToken(r: Res) {
        if (!r.ok) { g.error(r); state = 1; return }
        g.settings.token = r.j["token"].str()
        g.settings.lastToastEvent = 0
        connect()
    }

    private fun guest() {
        state = 2; msg = "Criando sua ilha..."
        g.net.call("POST", "/auth/guest", mapOf("deviceId" to g.host.deviceId())) { gotToken(it) }
    }

    private fun email() {
        g.host.prompt("Entrar com e-mail", listOf(Host.Field("E-mail", Host.Field.EMAIL), Host.Field("Senha", Host.Field.PASSWORD)), "ENTRAR", "CRIAR CONTA") { v, extra ->
            if (extra) register()
            else if (v != null) {
                state = 2; msg = "Entrando..."
                g.net.call("POST", "/auth/login", mapOf("email" to v[0], "password" to v[1])) { gotToken(it) }
            }
        }
    }

    private fun register() {
        g.host.prompt("Criar conta", listOf(Host.Field("Seu nome no jogo"), Host.Field("E-mail", Host.Field.EMAIL), Host.Field("Senha (mín. 6)", Host.Field.PASSWORD)), "CRIAR") { v, _ ->
            if (v != null) {
                state = 2; msg = "Criando conta..."
                g.net.call("POST", "/auth/register", mapOf("name" to v[0], "email" to v[1], "password" to v[2])) { gotToken(it) }
            }
        }
    }

    private fun google() {
        if (!googleOn) { g.toast(Game.T_INFO, "Login com Google", "Ainda não configurado no servidor (veja o LEIA-ME)."); return }
        g.host.openUrl(g.net.base + "/auth/google/start")
    }

    private fun server() {
        g.host.prompt("Endereço do servidor", listOf(Host.Field("URL (ex: https://meuservidor.com)", Host.Field.TEXT, g.settings.serverUrl)), "SALVAR") { v, _ ->
            if (v != null && v[0].isNotBlank()) {
                var u = v[0].trim()
                if (!u.startsWith("http")) u = "http://$u"
                g.settings.serverUrl = u
                start()
            }
        }
    }

    override fun update(dt: Float) {
        t += dt
        amb.update(dt, th, g.W, g.H)
        bGoogle.visible = state == 1; bEmail.visible = state == 1; bGuest.visible = state == 1
        bRetry.visible = state == 3
        bServer.visible = state == 1 || state == 3
    }

    override fun draw(c: Canvas) {
        Scenery.background(c, th, g.W, g.H, g.scale)
        amb.draw(c, th, g.W, g.H, g.time)
        Ui.dim(c, g.W, g.H, 0.28f)
        val cy = g.H * 0.15f
        val k = Ease.outElastic(clamp01(t / 1.2f))
        Art.rays(c, g.W / 2, g.H * 0.4f, 700f, g.time, 0xFFFFF59D.toInt(), 18, 0.6f)
        c.save(); c.scale(k, k, g.W / 2, cy); c.rotate(sin(g.time * 1.5f) * 2f, g.W / 2, cy)
        Ui.text(c, "CAPI", g.W / 2, cy - 70f, 190f, gold = true, ow = 30f)
        Ui.text(c, "COIN", g.W / 2, cy + 100f, 190f, gold = true, ow = 30f)
        c.restore()
        Ui.text(c, "Ilhas do Tesouro", g.W / 2, cy + 230f, 60f)
        val ck = Ease.outBack(clamp01((t - 0.3f) / 0.6f))
        Chars.barao(c, g.W * 0.79f, g.H * 0.585f, 0.62f * ck, g.time, Chars.VMood.SMIRK, flip = true)
        Art.capi(c, g.W * 0.38f, g.H * 0.58f, 0.95f * ck, g.time, Art.Mood.HAPPY, 1, 0, swing = sin(g.time * 3f) * 20f)
        for (i in 0 until 4) Art.coinSpin(c, g.W / 2 + sin(g.time + i * 1.6f) * 430f, g.H * 0.36f + i * 60f + sin(g.time * 2f + i) * 30f, 32f, g.time * 4f + i)
        when (state) {
            0, 2 -> { UiX.spinner(c, g.W / 2, g.H * 0.72f, 50f, g.time); Ui.text(c, msg, g.W / 2, g.H * 0.72f + 100f, 46f) }
            3 -> {
                Ui.panel(c, 80f, g.H * 0.62f - 120f, g.W - 80f, g.H * 0.62f + 90f, 0xFFC62828.toInt(), 40f)
                Ui.text(c, msg, g.W / 2, g.H * 0.62f - 60f, 40f, maxW = g.W - 220f)
                Ui.text(c, g.settings.serverUrl, g.W / 2, g.H * 0.62f + 10f, 32f, 0xFFFFCDD2.toInt(), maxW = g.W - 220f, ow = 4f)
            }
        }
        for (b in buttons) b.draw(c, g.time)
        if (bGoogle.visible) {
            val off = if (bGoogle.pressed) 14f else 0f
            Art.iconGoogle(c, bGoogle.x + 70f, bGoogle.y + bGoogle.h / 2 + off, 70f)
            Art.iconMail(c, bEmail.x + 70f, bEmail.y + bEmail.h / 2 + (if (bEmail.pressed) 14f else 0f), 70f)
            Art.avatar(c, bGuest.x + 70f, bGuest.y + bGuest.h / 2 + (if (bGuest.pressed) 14f else 0f), 40f, 0)
        }
        if (bGoogle.visible) Ui.text(c, "Convidado: sua ilha fica salva neste aparelho", g.W / 2, bGuest.y + bGuest.h + 50f, 30f, 0xFFE0E0E0.toInt(), ow = 4f)
    }

    override fun touch(type: Int, x: Float, y: Float) {
        for (b in buttons) if (b.touch(type, x, y, g)) return
    }
}
