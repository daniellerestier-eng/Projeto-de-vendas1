package com.oateam.capicoin

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import kotlin.math.sin

object Who { const val CAPI = 0; const val BARAO = 1; const val QUATI = 2; const val ONCA = 3; const val TUCANO = 4; const val MACHINE = 5; const val BOAT = 6; const val VBOAT = 7; const val ISLAND = 8; const val NARRATOR = -1 }

class Actor(val who: Int, val x: Float, val yFrac: Float, val s: Float, val mood: Int = 0, val enter: Int = 0, val flip: Boolean = false, val prop: Int = 0, val themeIdx: Int = 0)
/** bg: theme kind 0..7, or Shot.SEA. fx: 0 none, 1 shake, 2 confetti, 3 dust, 4 golden glow, 5 lightning */
class Shot(val bg: Int, val actors: List<Actor>, val speaker: Int, val text: String, val fx: Int = 0, val night: Boolean = false) { companion object { const val SEA = 100 } }

object Scripts {
    fun intro(): List<Shot> = listOf(
        Shot(Themes.JUNGLE, listOf(Actor(Who.CAPI, 540f, 0.66f, 1.15f, Art.Mood.HAPPY, 3)), Who.NARRATOR,
            "Na Ilha da Laranja vivia a Capi, a capivara mais feliz de todo o Brasil."),
        Shot(Shot.SEA, listOf(Actor(Who.VBOAT, 680f, 0.56f, 1.2f, enter = 2)), Who.NARRATOR,
            "Até que, numa noite de tempestade, surgiu no horizonte o navio do temido Barão Tatu...", 5, night = true),
        Shot(Themes.JUNGLE, listOf(Actor(Who.BARAO, 540f, 0.68f, 1.25f, Chars.VMood.LAUGH, 3)), Who.BARAO,
            "HAHAHA! Todas as moedas desta ilha agora são MINHAS! Hahaha!", 1, night = true),
        Shot(Themes.JUNGLE, listOf(Actor(Who.CAPI, 540f, 0.68f, 1.1f, Art.Mood.SAD, 1)), Who.CAPI,
            "Ele levou tudo... e destruiu a nossa vila inteira!", 3),
        Shot(Themes.JUNGLE, listOf(Actor(Who.MACHINE, 720f, 0.62f, 1f, enter = 3), Actor(Who.CAPI, 300f, 0.7f, 0.95f, Art.Mood.WOW, 1)), Who.NARRATOR,
            "Mas, no meio dos escombros, Capi encontrou a lendária MÁQUINA DOURADA!", 4),
        Shot(Themes.JUNGLE, listOf(Actor(Who.CAPI, 420f, 0.68f, 1.1f, Art.Mood.HAPPY, 3, prop = 1), Actor(Who.QUATI, 800f, 0.7f, 0.9f, enter = 2)), Who.CAPI,
            "Cada giro dá moedas! Vou reconstruir tudo e dar o troco nesse tatu!", 2),
        Shot(Themes.JUNGLE, listOf(Actor(Who.CAPI, 540f, 0.68f, 1.1f, Art.Mood.HAPPY, 0, prop = 1)), Who.NARRATOR,
            "Gire, construa, ataque e saqueie as ilhas. Sua aventura começa agora!", 2),
    )

    fun voyage(nextVillage: Int): List<Shot> {
        val th = Themes.forVillage(nextVillage)
        return listOf(
            Shot(Shot.SEA, listOf(Actor(Who.BOAT, 540f, 0.58f, 1.1f, enter = 1)), Who.CAPI, "Vila completa! Hora de zarpar rumo à próxima ilha!", 2),
            Shot(Shot.SEA, listOf(Actor(Who.BOAT, 300f, 0.6f, 0.8f), Actor(Who.VBOAT, 820f, 0.55f, 0.95f, enter = 2), Actor(Who.BARAO, 840f, 0.42f, 0.55f, Chars.VMood.ANGRY, 3, flip = true)), Who.BARAO,
                "Você não vai escapar de mim, capivara! Minha frota está em todas as ilhas!", 1),
            Shot(Shot.SEA, listOf(Actor(Who.ISLAND, 640f, 0.5f, 1.3f, enter = 2, themeIdx = (nextVillage - 1) % Themes.all.size), Actor(Who.BOAT, 300f, 0.62f, 0.85f)), Who.NARRATOR,
                "Terra à vista! Bem-vinda a ${th.name}!", 2),
        )
    }
}

/** Plays a list of shots with characters, letterbox and typewriter dialogue. */
class CutsceneScene(g: Game, private val shots: List<Shot>, private val onDone: () -> Unit) : Scene(g) {
    private var idx = 0
    private var st = 0f
    private var chars = 0f
    private var finished = false
    private val amb = Scenery.Ambience(g)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val skip = Button(0f, 0f, 0f, 0f, "PULAR ▶▶", 0xFF424242.toInt()) { finish() }
    private var blipAcc = 0f
    private var flash = 0f

    override val inGame: Boolean get() = false
    override fun layout() { skip.set(g.W - 290f, 150f, 250f, 90f); skip.textSize = 34f }
    override fun enter() { startShot() }

    private val shot get() = shots[idx]

    private fun startShot() {
        st = 0f; chars = 0f
        when (shot.fx) {
            1 -> { g.shake(16f, 0.6f); g.audio.play(if (shot.speaker == Who.BARAO) "laugh" else "hammer", 0.8f) }
            2 -> { g.fx.confetti(90); g.audio.play("win", 0.7f) }
            3 -> { g.fx.dust(g.W / 2, g.H * 0.6f, 30, 0xFFBCAAA4.toInt(), 450f); g.audio.play("crumble", 0.7f) }
            4 -> { g.audio.play("jackpot", 0.6f); g.fx.burst(720f, g.H * 0.5f, 40, P.STAR, intArrayOf(0xFFFFF59D.toInt(), -1), 1100f, 22f, 1.2f, 600f) }
            5 -> { flash = 1f; g.audio.play("hammer", 0.5f, 0.6f) }
        }
        if (shot.speaker == Who.BARAO && shot.fx != 1) g.audio.play("laugh", 0.5f)
    }

    private fun finish() { if (!finished) { finished = true; onDone() } }

    private fun next() {
        if (chars < shot.text.length) { chars = shot.text.length.toFloat(); return }
        if (idx < shots.size - 1) { idx++; startShot(); g.audio.play("whoosh", 0.4f) } else finish()
    }

    override fun update(dt: Float) {
        st += dt
        flash = (flash - dt * 2.5f).coerceAtLeast(0f)
        val bgKind = if (shot.bg == Shot.SEA) Themes.BEACH else shot.bg
        amb.update(dt, Themes.all[bgKind % Themes.all.size], g.W, g.H)
        if (st > 0.45f) {
            val before = chars.toInt()
            chars = (chars + dt * 42f).coerceAtMost(shot.text.length.toFloat())
            if (chars.toInt() > before) { blipAcc += 1f; if (blipAcc >= 2f) { blipAcc = 0f; g.audio.play("blip", 0.35f, if (shot.speaker == Who.BARAO) 0.7f else 1.2f) } }
        }
        if (shot.fx == 5 && sin(st * 7f) > 0.97f) flash = 0.7f
    }

    override fun draw(c: Canvas) {
        val s = shot
        val zoom = 1f + 0.04f * clamp01(st / 4f)
        c.save(); c.scale(zoom, zoom, g.W / 2, g.H * 0.55f)
        if (s.bg == Shot.SEA) drawSea(c, s.night)
        else {
            val th = Themes.all[s.bg % Themes.all.size]
            Scenery.background(c, th, g.W, g.H, g.scale)
            amb.draw(c, th, g.W, g.H, g.time)
        }
        if (s.night) Ui.dim(c, g.W, g.H, 0.45f)
        for ((i, a) in s.actors.withIndex()) drawActor(c, a, i)
        c.restore()
        // letterbox
        p.shader = null; p.color = 0xFF000000.toInt()
        val bar = 130f * clamp01(st / 0.3f).coerceAtLeast(if (idx > 0) 1f else 0f)
        c.drawRect(0f, 0f, g.W, bar, p); c.drawRect(0f, g.H - bar, g.W, g.H, p)
        if (flash > 0f) { p.color = withAlpha(0xFFE3F2FD.toInt(), (flash * 220).toInt()); c.drawRect(0f, 0f, g.W, g.H, p) }
        drawDialog(c)
        skip.draw(c, g.time)
        // progress dots
        for (i in shots.indices) { p.color = if (i == idx) 0xFFFFD54F.toInt() else 0x66FFFFFF; c.drawCircle(g.W / 2 + (i - (shots.size - 1) / 2f) * 30f, 70f, if (i == idx) 10f else 7f, p) }
    }

    private fun drawActor(c: Canvas, a: Actor, i: Int) {
        val e = clamp01((st - i * 0.15f) / 0.55f)
        var x = a.x; val y = g.H * a.yFrac
        var sc = a.s
        when (a.enter) {
            1 -> x = lerp(-300f, a.x, Ease.outBack(e))
            2 -> x = lerp(g.W + 300f, a.x, Ease.outBack(e))
            3 -> sc = a.s * Ease.outBack(e)
        }
        if (sc <= 0.01f) return
        val talking = shot.speaker == a.who && chars < shot.text.length && st > 0.45f
        val hop = if (talking) -kotlin.math.abs(sin(g.time * 14f)) * 10f else 0f
        when (a.who) {
            Who.CAPI -> Art.capi(c, x, y + hop, sc, g.time, if (talking && a.mood == Art.Mood.IDLE) Art.Mood.HAPPY else a.mood, a.prop, 0, swing = sin(g.time * 3f) * 18f)
            Who.BARAO -> Chars.barao(c, x, y + hop, sc, g.time, a.mood, a.flip)
            Who.QUATI -> Chars.quati(c, x, y, sc, g.time, true)
            Who.ONCA -> Chars.onca(c, x, y, sc, g.time, true)
            Who.TUCANO -> Chars.tucano(c, x, y, sc, g.time, true)
            Who.MACHINE -> miniMachine(c, x, y, sc)
            Who.BOAT -> { Chars.boat(c, x, y, sc, g.time); Art.capi(c, x - 40f * sc, y - 60f * sc + sin(g.time * 2.4f) * 8f, 0.42f * sc, g.time, Art.Mood.HAPPY, 0, 0) }
            Who.VBOAT -> Chars.boat(c, x, y, sc, g.time, villain = true)
            Who.ISLAND -> Chars.island(c, x, y, sc, Themes.all[a.themeIdx])
        }
    }

    private fun miniMachine(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s)
        Art.rays(c, 0f, -180f, 520f, g.time * 1.5f, 0xFFFFF59D.toInt(), 16, 0.9f)
        Ui.panel(c, -200f, -340f, 200f, 0f, 0xFFFFB300.toInt(), 40f, bw = 9f)
        Ui.panel(c, -170f, -270f, 170f, -90f, 0xFF7F0000.toInt(), 24f, bw = 6f)
        for (k in 0..2) {
            p.shader = null; p.color = -1; c.drawRoundRect(-155f + k * 105f, -255f, -65f + k * 105f, -105f, 16f, 16f, p)
            Art.symbol(c, Sym.CAPI, -110f + k * 105f, -180f, 92f)
        }
        Ui.text(c, "CAPI COIN", 0f, -305f, 44f, gold = true, ow = 7f)
        for (k in 0 until 10) { p.color = if ((k + (g.time * 8).toInt()) % 2 == 0) -1 else 0xFFFF8A80.toInt(); c.drawCircle(-180f + k * 40f, -20f, 9f, p) }
        c.restore()
    }

    private fun drawSea(c: Canvas, night: Boolean) {
        val hz = g.H * 0.45f
        p.color = -1; p.shader = LinearGradient(0f, 0f, 0f, hz, if (night) 0xFF0D1B3E.toInt() else 0xFF29B6F6.toInt(), if (night) 0xFF37474F.toInt() else 0xFFB3E5FC.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, g.W, hz + 2f, p)
        p.shader = LinearGradient(0f, hz, 0f, g.H, if (night) 0xFF1A237E.toInt() else 0xFF4FC3F7.toInt(), if (night) 0xFF000033.toInt() else 0xFF01579B.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, hz, g.W, g.H, p); p.shader = null
        if (!night) { Art.glow(c, g.W * 0.8f, hz * 0.35f, 300f, 0xFFFFF59D.toInt(), 0.9f); p.color = 0xFFFFF9C4.toInt(); c.drawCircle(g.W * 0.8f, hz * 0.35f, 80f, p) }
        else { p.color = 0xFFFFF8E1.toInt(); c.drawCircle(g.W * 0.2f, hz * 0.3f, 60f, p) }
        for (i in 0 until 3) Art.cloud(c, ((i * 420f + g.time * 18f) % (g.W + 500f)) - 250f, 120f + i * 90f, 0.7f, if (night) 0xFF455A64.toInt() else -1, 220)
        p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = 0x66FFFFFF
        val path = Path()
        for (row in 0 until 9) {
            val yy = hz + 40f + row * row * 18f + row * 30f
            path.reset(); path.moveTo(-20f, yy)
            var x = -20f
            while (x <= g.W + 20f) { path.lineTo(x, yy + sin(x * 0.02f + g.time * (1.5f + row * 0.2f) + row) * (6f + row * 2f)); x += 20f }
            c.drawPath(path, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun drawDialog(c: Canvas) {
        if (st < 0.3f) return
        val k = Ease.outBack(clamp01((st - 0.3f) / 0.35f))
        val top = g.H - 600f; val bot = g.H - 180f
        c.save(); c.scale(1f, k, g.W / 2, bot)
        Ui.panel(c, 40f, top, g.W - 40f, bot, 0xFF1A237E.toInt(), 40f, bw = 8f)
        val (name, col) = when (shot.speaker) { Who.CAPI -> "Capi" to 0xFFF57C00.toInt(); Who.BARAO -> "Barão Tatu" to 0xFF7B1FA2.toInt(); else -> "Narrador" to 0xFF00897B.toInt() }
        Ui.panel(c, 80f, top - 50f, 80f + Ui.measure(name, 46f) + 70f, top + 40f, col, 26f, bw = 6f)
        Ui.text(c, name, 115f, top - 5f, 46f, align = Paint.Align.LEFT)
        val shown = shot.text.substring(0, chars.toInt().coerceIn(0, shot.text.length))
        val lines = wrapText(shot.text, 48f, g.W - 200f)
        var used = 0
        for ((i, line) in lines.withIndex()) {
            val take = (shown.length - used).coerceIn(0, line.length)
            if (take > 0) Ui.text(c, line.substring(0, take), 90f, top + 90f + i * 66f, 48f, align = Paint.Align.LEFT, ow = 6f)
            used += line.length + 1
        }
        if (chars >= shot.text.length) {
            val b = sin(g.time * 8f) * 8f
            Ui.text(c, "toque ▼", g.W - 160f, bot - 50f + b, 36f, 0xFFFFEB3B.toInt(), ow = 5f)
        }
        c.restore()
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (skip.touch(type, x, y, g)) return
        if (type == Game.UP && st > 0.3f) next()
    }

    override fun back(): Boolean { finish(); return true }
}

/** In-game dialogue with a character portrait (tutorials, villain taunts). */
class DialogPopup(g: Game, private val lines: List<Pair<Int, String>>, private val after: (() -> Unit)? = null) : Popup(g) {
    private var i = 0
    private var chars = 0f
    private var lt = 0f
    init { onClosed = after }

    override fun update(dt: Float) {
        super.update(dt)
        lt += dt
        val text = lines[i].second
        if (lt > 0.25f && chars < text.length) {
            val before = chars.toInt()
            chars = (chars + dt * 50f).coerceAtMost(text.length.toFloat())
            if (chars.toInt() / 3 > before / 3) g.audio.play("blip", 0.3f, if (lines[i].first == Who.BARAO) 0.7f else 1.2f)
        }
    }

    override fun draw(c: Canvas) {
        Ui.dim(c, g.W, g.H, dimAlpha() * 0.6f)
        val k = k()
        val top = g.H - 640f; val bot = g.H - 120f
        val who = lines[i].first
        c.save(); c.translate(0f, (1f - k) * 500f)
        // character standing on the dialog box
        val cx = 200f
        when (who) {
            Who.BARAO -> Chars.barao(c, cx, top + 60f, 0.62f, g.time, Chars.VMood.SMIRK)
            Who.QUATI -> Chars.quati(c, cx, top + 50f, 0.9f, g.time, true)
            Who.ONCA -> Chars.onca(c, cx, top + 50f, 0.9f, g.time, true)
            Who.TUCANO -> Chars.tucano(c, cx, top + 50f, 0.9f, g.time, true)
            else -> Art.capi(c, cx, top + 70f, 0.72f, g.time, if (chars < lines[i].second.length) Art.Mood.HAPPY else Art.Mood.IDLE, 0, 0)
        }
        Ui.panel(c, 40f, top + 30f, g.W - 40f, bot, 0xFF1A237E.toInt(), 40f, bw = 8f)
        val (name, col) = when (who) { Who.BARAO -> "Barão Tatu" to 0xFF7B1FA2.toInt(); Who.QUATI -> "Quati" to 0xFFF57C00.toInt(); Who.ONCA -> "Onça" to 0xFFF57C00.toInt(); Who.TUCANO -> "Tucano" to 0xFF00897B.toInt(); else -> "Capi" to 0xFFF57C00.toInt() }
        Ui.panel(c, 380f, top - 10f, 380f + Ui.measure(name, 44f) + 70f, top + 74f, col, 26f, bw = 6f)
        Ui.text(c, name, 415f, top + 32f, 44f, align = Paint.Align.LEFT)
        val text = lines[i].second
        val shown = chars.toInt().coerceIn(0, text.length)
        var used = 0
        for ((n, line) in wrapText(text, 46f, g.W - 180f).withIndex()) {
            val take = (shown - used).coerceIn(0, line.length)
            if (take > 0) Ui.text(c, line.substring(0, take), 80f, top + 140f + n * 62f, 46f, align = Paint.Align.LEFT, ow = 6f)
            used += line.length + 1
        }
        if (chars >= text.length) Ui.text(c, if (i < lines.size - 1) "toque ▼" else "OK ▶", g.W - 150f, bot - 50f + sin(g.time * 8f) * 6f, 38f, 0xFFFFEB3B.toInt(), ow = 5f)
        c.restore()
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (type != Game.UP || t < 0.3f) return
        if (chars < lines[i].second.length) { chars = lines[i].second.length.toFloat(); return }
        if (i < lines.size - 1) { i++; chars = 0f; lt = 0f } else close()
    }
}

/** Tutorial tips shown once per device. */
object Tips {
    fun show(g: Game, key: String, after: (() -> Unit)? = null): Boolean {
        if (g.settings.seen(key)) return false
        val lines: List<Pair<Int, String>> = when (key) {
            "spin" -> listOf(Who.CAPI to "Toque em GIRAR! Moedas e sacos dão dinheiro na hora.", Who.CAPI to "3 martelos = ATAQUE. 3 mapas = SAQUE. 3 escudos protegem sua vila. 3 gemas = gemas!")
            "turbo" -> listOf(Who.CAPI to "Dica de mestre: ligue o TURBO pra girar muito mais rápido, e SEGURE o botão GIRAR para o automático!")
            "village" -> listOf(Who.CAPI to "Aqui a gente reconstrói! São 5 prédios com 5 níveis cada.", Who.CAPI to "Complete a vila inteira para navegar até a próxima ilha e ganhar prêmios!")
            "attack" -> listOf(Who.CAPI to "Escolha um prédio do rival e solte o martelo! Se ele tiver escudo, o ataque é bloqueado.", Who.CAPI to "Quer outro alvo? Toque em TROCAR ALVO. Quem te atacou aparece como VINGANÇA!")
            "raid" -> listOf(Who.QUATI to "Fareja aqui, fareja ali... Cave em 3 lugares! Um deles esconde o Tesouro Real!")
            "pets" -> listOf(Who.ONCA to "Pets dão bônus incríveis! Dê um petisco e o pet fica acordado por 4 horas.", Who.TUCANO to "O Quati cava mais nos saques, a Onça ganha mais nos ataques e eu defendo sua vila!")
            "friends" -> listOf(Who.CAPI to "Mande seu código para os amigos! Todo dia vocês podem trocar presentes de giros.")
            "attacked" -> listOf(Who.BARAO to "Hahaha! Estão atacando sua vila, capivara! Junte escudos se quiser dormir tranquila...")
            "shop" -> listOf(Who.CAPI to "Na loja você compra giros, gemas e moedas. Pagamento por PIX, cai na hora!")
            else -> return false
        }
        g.settings.markSeen(key)
        g.show(DialogPopup(g, lines, after))
        return true
    }
}
