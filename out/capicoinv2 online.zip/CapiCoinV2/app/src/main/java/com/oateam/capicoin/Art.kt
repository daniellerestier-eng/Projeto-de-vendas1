package com.oateam.capicoin

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

object Sym {
    const val COIN = 0; const val BAG = 1; const val RAID = 2; const val HAMMER = 3
    const val SHIELD = 4; const val ENERGY = 5; const val CAPI = 6; const val GEM = 7
    const val COUNT = 8
    val glowColor = intArrayOf(0xFFFFD54F.toInt(), 0xFFFFB74D.toInt(), 0xFFEF5350.toInt(), 0xFFFF7043.toInt(), 0xFF42A5F5.toInt(), 0xFFBA68C8.toInt(), 0xFFFFEE58.toInt(), 0xFF4DD0E1.toInt())
}

/** Procedural art: mascot, slot symbols, icons. Everything is drawn with vectors. */
object Art {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val o = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND }
    private val path = Path()
    private val path2 = Path()
    private val r = RectF()
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    const val INK = 0xFF2B1608.toInt()

    private val symCache = arrayOfNulls<Bitmap>(Sym.COUNT)
    private var cacheScale = 0f
    private const val SYM_BOX = 220f

    fun init(scale: Float) {
        if (cacheScale == scale && symCache[0] != null) return
        cacheScale = scale
        val px = (SYM_BOX * scale).toInt().coerceAtLeast(16)
        for (i in 0 until Sym.COUNT) {
            val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            c.scale(scale, scale)
            c.translate(SYM_BOX / 2, SYM_BOX / 2)
            drawSymbolRaw(c, i)
            symCache[i] = b
        }
    }

    /** Draws a cached symbol centered at (x,y), size = box size. */
    fun symbol(c: Canvas, id: Int, x: Float, y: Float, size: Float, alpha: Int = 255, stretchY: Float = 1f) {
        val b = symCache[id]
        if (b == null) {
            c.save(); c.translate(x, y); c.scale(size / SYM_BOX, size / SYM_BOX * stretchY); drawSymbolRaw(c, id); c.restore(); return
        }
        val hw = size / 2; val hh = size / 2 * stretchY
        r.set(x - hw, y - hh, x + hw, y + hh)
        bmpPaint.alpha = alpha
        c.drawBitmap(b, null, r, bmpPaint)
        bmpPaint.alpha = 255
    }

    private fun drawSymbolRaw(c: Canvas, id: Int) {
        glow(c, 0f, 4f, 108f, Sym.glowColor[id], 0.55f)
        when (id) {
            Sym.COIN -> {
                coin(c, -44f, 38f, 50f); coin(c, 46f, 42f, 48f)
                coin(c, 0f, -6f, 72f)
                sparkle(c, 62f, -62f, 20f); sparkle(c, -70f, -40f, 12f)
            }
            Sym.BAG -> bag(c)
            Sym.RAID -> raidMap(c)
            Sym.HAMMER -> {
                outline(9f, 0xAAFFFFFF.toInt())
                r.set(-100f, -100f, 60f, 60f); c.drawArc(r, 190f, 70f, false, o)
                r.set(-86f, -86f, 46f, 46f); c.drawArc(r, 200f, 55f, false, o)
                c.save(); c.rotate(-32f); goldHammer(c, 1f); c.restore()
            }
            Sym.SHIELD -> shield(c, 0f, 0f, 1f, 0xFF1E88E5.toInt(), true)
            Sym.ENERGY -> capsule(c, 0f, 0f, 1f)
            Sym.CAPI -> {
                burst(c, 0f, 0f, 104f, 0xFFFFF176.toInt(), 0xFFFF8F00.toInt(), 14, 0f)
                c.save(); c.translate(0f, 128f); c.scale(0.5f, 0.5f); capi(c, 0f, 0f, 1f, 0f, Mood.HAPPY, 0, 0, headOnly = true); c.restore()
                crown(c, 0f, -76f, 0.62f)
            }
            Sym.GEM -> { gem(c, 0f, 6f, 1f, 0xFF26C6DA.toInt()); sparkle(c, 58f, -58f, 18f); sparkle(c, -62f, 30f, 11f) }
        }
    }

    // ---------------------------------------------------------------- primitives
    private fun outline(w: Float, col: Int = INK) { o.strokeWidth = w; o.color = col; o.shader = null; o.pathEffect = null }

    fun coin(c: Canvas, x: Float, y: Float, rad: Float) {
        p.color = -1; p.shader = RadialGradient(x - rad * 0.35f, y - rad * 0.4f, rad * 1.5f,
            intArrayOf(0xFFFFFDE7.toInt(), 0xFFFFD54F.toInt(), 0xFFFFA000.toInt(), 0xFFE65100.toInt()),
            floatArrayOf(0f, 0.35f, 0.75f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, rad, p)
        p.shader = null
        outline(rad * 0.09f, 0xFFB26A00.toInt()); c.drawCircle(x, y, rad * 0.76f, o)
        p.color = 0xFFFFE57F.toInt()
        starPath(x, y + rad * 0.03f, rad * 0.46f, rad * 0.2f, 5)
        c.drawPath(path, p)
        outline(rad * 0.06f, 0xFFC77800.toInt()); c.drawPath(path, o)
        outline(rad * 0.08f); c.drawCircle(x, y, rad, o)
        p.color = 0x99FFFFFF.toInt()
        r.set(x - rad * 0.7f, y - rad * 0.75f, x + rad * 0.1f, y - rad * 0.2f)
        c.drawArc(r, 200f, 70f, false, o.apply { color = 0xCCFFFFFF.toInt(); strokeWidth = rad * 0.1f })
    }

    fun coinSpin(c: Canvas, x: Float, y: Float, rad: Float, phase: Float) {
        val w = abs(cos(phase))
        c.save(); c.translate(x, y); c.scale(0.12f + 0.88f * w, 1f)
        if (w < 0.3f) {
            p.shader = null; p.color = 0xFFE69500.toInt()
            c.drawCircle(0f, 0f, rad, p)
            outline(rad * 0.12f); c.drawCircle(0f, 0f, rad, o)
        } else coin(c, 0f, 0f, rad)
        c.restore()
    }

    fun starPath(cx: Float, cy: Float, ro: Float, ri: Float, n: Int) {
        path.reset()
        for (i in 0 until n * 2) {
            val a = (-PI / 2 + i * PI / n).toFloat()
            val rr = if (i % 2 == 0) ro else ri
            val px = cx + cos(a) * rr; val py = cy + sin(a) * rr
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
    }

    fun star(c: Canvas, x: Float, y: Float, rad: Float, filled: Boolean) {
        starPath(x, y, rad, rad * 0.45f, 5)
        if (filled) {
            p.color = -1; p.shader = LinearGradient(0f, y - rad, 0f, y + rad, 0xFFFFF176.toInt(), 0xFFFF8F00.toInt(), Shader.TileMode.CLAMP)
        } else { p.shader = null; p.color = 0x66000000 }
        c.drawPath(path, p); p.shader = null
        outline(rad * 0.16f); c.drawPath(path, o)
    }

    fun burst(c: Canvas, x: Float, y: Float, rad: Float, c1: Int, c2: Int, rays: Int, rot: Float) {
        p.color = -1; p.shader = RadialGradient(x, y, rad, c1, c2, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, rad, p)
        p.shader = null
        p.color = 0x55FFFFFF
        for (i in 0 until rays) {
            val a = rot + i * 2 * PI.toFloat() / rays
            path.reset(); path.moveTo(x, y)
            path.lineTo(x + cos(a - 0.11f) * rad, y + sin(a - 0.11f) * rad)
            path.lineTo(x + cos(a + 0.11f) * rad, y + sin(a + 0.11f) * rad); path.close()
            c.drawPath(path, p)
        }
        outline(7f); c.drawCircle(x, y, rad, o)
    }

    /** Big soft radial glow. */
    fun glow(c: Canvas, x: Float, y: Float, rad: Float, color: Int, a: Float = 1f) {
        if (rad <= 1f) return
        p.color = -1; p.shader = RadialGradient(x, y, rad, withAlpha(color, (200 * clamp01(a)).toInt()), withAlpha(color, 0), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, rad, p)
        p.shader = null
    }

    /** Rotating light rays behind rewards. */
    fun rays(c: Canvas, x: Float, y: Float, rad: Float, t: Float, color: Int = 0xFFFFF59D.toInt(), n: Int = 16, a: Float = 1f) {
        p.color = -1; p.shader = RadialGradient(x, y, rad, withAlpha(color, (170 * a).toInt()), withAlpha(color, 0), Shader.TileMode.CLAMP)
        for (i in 0 until n) {
            val ang = t * 0.5f + i * 2 * PI.toFloat() / n
            path.reset(); path.moveTo(x, y)
            path.lineTo(x + cos(ang - 0.09f) * rad, y + sin(ang - 0.09f) * rad)
            path.lineTo(x + cos(ang + 0.09f) * rad, y + sin(ang + 0.09f) * rad); path.close()
            c.drawPath(path, p)
        }
        p.shader = null
    }

    // ---------------------------------------------------------------- symbols
    private fun bag(c: Canvas) {
        path.reset()
        path.moveTo(-28f, -50f)
        path.cubicTo(-100f, -15f, -105f, 88f, 0f, 88f)
        path.cubicTo(105f, 88f, 100f, -15f, 28f, -50f)
        path.close()
        p.color = -1; p.shader = RadialGradient(-25f, 0f, 120f, 0xFFD7A46A.toInt(), 0xFF7B4A22.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        outline(8f); c.drawPath(path, o)
        // ruffle
        path.reset()
        path.moveTo(-30f, -52f); path.lineTo(-52f, -88f); path.lineTo(-18f, -74f); path.lineTo(0f, -96f)
        path.lineTo(18f, -74f); path.lineTo(52f, -88f); path.lineTo(30f, -52f); path.close()
        p.color = 0xFFC08A55.toInt(); c.drawPath(path, p); c.drawPath(path, o)
        // rope
        r.set(-40f, -62f, 40f, -44f)
        p.color = 0xFFFFC107.toInt(); c.drawRoundRect(r, 9f, 9f, p); outline(6f); c.drawRoundRect(r, 9f, 9f, o)
        // $
        Ui.text(c, "$", 0f, 22f, 92f, 0xFFFFD54F.toInt(), ow = 12f)
        coin(c, -62f, 78f, 26f); coin(c, 64f, 80f, 24f); coin(c, 18f, 92f, 22f)
    }

    private fun raidMap(c: Canvas) {
        c.save(); c.rotate(-8f)
        r.set(-82f, -62f, 82f, 66f)
        p.color = -1; p.shader = LinearGradient(0f, -62f, 0f, 66f, 0xFFFFF3D6.toInt(), 0xFFE8C48A.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(r, p); p.shader = null
        outline(7f); c.drawRect(r, o)
        // rolls
        for (sx in floatArrayOf(-88f, 88f)) {
            r.set(sx - 14f, -70f, sx + 14f, 74f)
            p.color = -1; p.shader = LinearGradient(sx - 14f, 0f, sx + 14f, 0f, 0xFFD9AE6B.toInt(), 0xFFFFF0CF.toInt(), Shader.TileMode.MIRROR)
            c.drawRoundRect(r, 14f, 14f, p); p.shader = null
            c.drawRoundRect(r, 14f, 14f, o)
        }
        // island blob
        p.color = 0x5581C784
        c.drawOval(-60f, -30f, 40f, 40f, p)
        // dashed trail
        path.reset(); path.moveTo(-60f, 40f); path.cubicTo(-40f, -40f, 10f, 40f, 40f, -22f)
        o.strokeWidth = 7f; o.color = 0xFF8D2B0B.toInt(); o.pathEffect = DashPathEffect(floatArrayOf(14f, 12f), 0f)
        c.drawPath(path, o); o.pathEffect = null
        // X
        outline(16f, 0xFFD32F2F.toInt())
        c.drawLine(28f, -40f, 62f, -6f, o); c.drawLine(62f, -40f, 28f, -6f, o)
        c.restore()
        // shovel
        c.save(); c.translate(40f, 46f); c.rotate(40f)
        r.set(-7f, -90f, 7f, 20f); p.color = 0xFF8D5A2B.toInt(); c.drawRect(r, p); outline(5f); c.drawRect(r, o)
        r.set(-20f, -102f, 20f, -88f); c.drawRoundRect(r, 6f, 6f, p); c.drawRoundRect(r, 6f, 6f, o)
        path.reset(); path.moveTo(-28f, 16f); path.lineTo(28f, 16f); path.lineTo(24f, 58f); path.quadTo(0f, 82f, -24f, 58f); path.close()
        p.color = -1; p.shader = LinearGradient(-28f, 0f, 28f, 0f, 0xFFECEFF1.toInt(), 0xFF78909C.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null; c.drawPath(path, o)
        c.restore()
    }

    fun hammer(c: Canvas, s: Float) {
        c.save(); c.scale(s, s)
        r.set(-13f, -30f, 13f, 98f)
        p.color = -1; p.shader = LinearGradient(-13f, 0f, 13f, 0f, 0xFFBC8A5F.toInt(), 0xFF6D4425.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 10f, 10f, p); p.shader = null
        outline(7f); c.drawRoundRect(r, 10f, 10f, o)
        p.color = 0xFF4E2C14.toInt()
        for (i in 0..2) { r.set(-15f, 50f + i * 15f, 15f, 58f + i * 15f); c.drawRect(r, p) }
        r.set(-82f, -86f, 82f, -22f)
        p.color = -1; p.shader = LinearGradient(0f, -86f, 0f, -22f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFB0BEC5.toInt(), 0xFF546E7A.toInt()), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 16f, 16f, p); p.shader = null
        c.drawRoundRect(r, 16f, 16f, o)
        p.color = 0xFFFFC107.toInt()
        for (bx in floatArrayOf(-50f, 36f)) { r.set(bx, -88f, bx + 14f, -20f); c.drawRect(r, p); outline(5f); c.drawRect(r, o) }
        r.set(-96f, -80f, -76f, -28f); p.color = 0xFF455A64.toInt(); c.drawRoundRect(r, 8f, 8f, p); outline(6f); c.drawRoundRect(r, 8f, 8f, o)
        r.set(76f, -80f, 96f, -28f); c.drawRoundRect(r, 8f, 8f, p); c.drawRoundRect(r, 8f, 8f, o)
        c.restore()
    }

    fun shield(c: Canvas, x: Float, y: Float, s: Float, inner: Int, fancy: Boolean = false) {
        c.save(); c.translate(x, y); c.scale(s, s)
        shieldPath(1f)
        p.color = -1; p.shader = if (fancy) LinearGradient(-85f, -90f, 85f, 95f, 0xFFFFF59D.toInt(), 0xFFF9A825.toInt(), Shader.TileMode.CLAMP) else LinearGradient(-85f, -90f, 85f, 95f, 0xFFFFFFFF.toInt(), 0xFF90A4AE.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        outline(8f); c.drawPath(path, o)
        shieldPath(0.78f)
        p.color = -1; p.shader = LinearGradient(0f, -70f, 0f, 75f, lighten(inner, 0.35f), darken(inner, 0.35f), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        outline(5f, darken(inner, 0.6f)); c.drawPath(path, o)
        if (fancy) { gem(c, 0f, 2f, 0.42f, 0xFFE53935.toInt()) } else star(c, 0f, 0f, 38f, true)
        p.color = 0x55FFFFFF
        path.reset(); path.moveTo(-60f, -55f); path.lineTo(-10f, -62f); path.lineTo(-58f, 10f); path.close()
        c.drawPath(path, p)
        c.restore()
    }

    private fun shieldPath(k: Float) {
        path.reset()
        path.moveTo(0f, -92f * k)
        path.cubicTo(30f * k, -72f * k, 62f * k, -76f * k, 86f * k, -82f * k)
        path.lineTo(86f * k, -8f * k)
        path.cubicTo(86f * k, 50f * k, 42f * k, 80f * k, 0f, 96f * k)
        path.cubicTo(-42f * k, 80f * k, -86f * k, 50f * k, -86f * k, -8f * k)
        path.lineTo(-86f * k, -82f * k)
        path.cubicTo(-62f * k, -76f * k, -30f * k, -72f * k, 0f, -92f * k)
        path.close()
    }

    private fun energy(c: Canvas) {
        p.color = -1; p.shader = RadialGradient(-20f, -25f, 110f, intArrayOf(0xFFF3E5F5.toInt(), 0xFFAB47BC.toInt(), 0xFF4A148C.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(0f, 0f, 86f, p); p.shader = null
        outline(8f); c.drawCircle(0f, 0f, 86f, o)
        boltPath(0f, 0f, 1f)
        p.color = -1; p.shader = LinearGradient(0f, -75f, 0f, 75f, 0xFFFFFDE7.toInt(), 0xFFFFB300.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        outline(7f, 0xFF6A1B00.toInt()); c.drawPath(path, o)
        p.color = 0x88FFFFFF.toInt(); c.drawOval(-55f, -66f, -5f, -36f, p)
    }

    private fun boltPath(x: Float, y: Float, s: Float) {
        path.reset()
        path.moveTo(x + 18f * s, y - 78f * s); path.lineTo(x - 42f * s, y + 10f * s); path.lineTo(x - 2f * s, y + 10f * s)
        path.lineTo(x - 20f * s, y + 78f * s); path.lineTo(x + 44f * s, y - 14f * s); path.lineTo(x + 4f * s, y - 14f * s)
        path.lineTo(x + 30f * s, y - 78f * s); path.close()
    }

    fun sparkle(c: Canvas, x: Float, y: Float, rr: Float, col: Int = -1) {
        p.shader = null; p.color = col
        path.reset(); path.moveTo(x, y - rr); path.quadTo(x, y, x + rr, y); path.quadTo(x, y, x, y + rr); path.quadTo(x, y, x - rr, y); path.quadTo(x, y, x, y - rr); path.close()
        c.drawPath(path, p)
    }

    /** Faceted diamond. */
    fun gem(c: Canvas, x: Float, y: Float, s: Float, col: Int) {
        c.save(); c.translate(x, y); c.scale(s, s)
        // crown (top) + pavilion (bottom)
        path.reset(); path.moveTo(-88f, -28f); path.lineTo(-52f, -72f); path.lineTo(52f, -72f); path.lineTo(88f, -28f); path.lineTo(0f, 86f); path.close()
        p.color = -1; p.shader = LinearGradient(-80f, -70f, 80f, 86f, lighten(col, 0.55f), darken(col, 0.35f), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        p.color = withAlpha(lighten(col, 0.7f), 200)
        path2.reset(); path2.moveTo(-52f, -72f); path2.lineTo(-26f, -28f); path2.lineTo(26f, -28f); path2.lineTo(52f, -72f); path2.close(); c.drawPath(path2, p)
        p.color = withAlpha(darken(col, 0.25f), 150)
        path2.reset(); path2.moveTo(26f, -28f); path2.lineTo(88f, -28f); path2.lineTo(0f, 86f); path2.close(); c.drawPath(path2, p)
        p.color = withAlpha(lighten(col, 0.35f), 140)
        path2.reset(); path2.moveTo(-88f, -28f); path2.lineTo(-26f, -28f); path2.lineTo(0f, 86f); path2.close(); c.drawPath(path2, p)
        outline(3.5f, withAlpha(0xFFFFFFFF.toInt(), 170))
        c.drawLine(-88f, -28f, 88f, -28f, o); c.drawLine(-26f, -28f, 0f, 86f, o); c.drawLine(26f, -28f, 0f, 86f, o)
        c.drawLine(-52f, -72f, -26f, -28f, o); c.drawLine(52f, -72f, 26f, -28f, o); c.drawLine(0f, -72f, -26f, -28f, o); c.drawLine(0f, -72f, 26f, -28f, o)
        outline(7f); c.drawPath(path, o)
        p.color = 0xCCFFFFFF.toInt(); path2.reset(); path2.moveTo(-60f, -60f); path2.lineTo(-40f, -60f); path2.lineTo(-62f, -32f); path2.lineTo(-74f, -32f); path2.close(); c.drawPath(path2, p)
        c.restore()
    }

    /** Energy capsule (spins). */
    fun capsule(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s); c.rotate(-18f)
        r.set(-50f, -92f, 50f, 92f)
        p.color = -1; p.shader = LinearGradient(-50f, 0f, 50f, 0f, intArrayOf(0xFF6A1B9A.toInt(), 0xFFCE93D8.toInt(), 0xFF8E24AA.toInt(), 0xFF4A148C.toInt()), floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 50f, 50f, p); p.shader = null
        // liquid
        p.color = withAlpha(0xFFE040FB.toInt(), 160); r.set(-40f, 0f, 40f, 82f); c.drawRoundRect(r, 40f, 40f, p)
        p.color = 0x88FFFFFF.toInt(); c.drawCircle(-14f, 40f, 7f, p); c.drawCircle(12f, 58f, 5f, p); c.drawCircle(4f, 22f, 4f, p)
        // metal band
        r.set(-52f, -14f, 52f, 6f); p.color = -1; p.shader = LinearGradient(0f, -14f, 0f, 6f, 0xFFFFF59D.toInt(), 0xFFFF8F00.toInt(), Shader.TileMode.CLAMP); c.drawRect(r, p); p.shader = null
        outline(5f); c.drawRect(r, o)
        r.set(-50f, -92f, 50f, 92f); outline(8f); c.drawRoundRect(r, 50f, 50f, o)
        boltPath(0f, -48f, 0.48f)
        p.color = -1; p.shader = LinearGradient(0f, -90f, 0f, -10f, 0xFFFFFDE7.toInt(), 0xFFFFC107.toInt(), Shader.TileMode.CLAMP); c.drawPath(path, p); p.shader = null
        outline(4f, 0xFF4A148C.toInt()); c.drawPath(path, o)
        p.color = 0xAAFFFFFF.toInt(); r.set(-36f, -80f, -20f, 70f); c.drawRoundRect(r, 8f, 8f, p)
        c.restore()
    }

    fun crown(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s)
        path.reset(); path.moveTo(-70f, 40f); path.lineTo(-80f, -30f); path.lineTo(-38f, 6f); path.lineTo(0f, -50f); path.lineTo(38f, 6f); path.lineTo(80f, -30f); path.lineTo(70f, 40f); path.close()
        p.color = -1; p.shader = LinearGradient(0f, -50f, 0f, 40f, 0xFFFFF59D.toInt(), 0xFFFF8F00.toInt(), Shader.TileMode.CLAMP); c.drawPath(path, p); p.shader = null
        outline(7f); c.drawPath(path, o)
        p.color = 0xFFE53935.toInt(); c.drawCircle(0f, 18f, 11f, p); p.color = 0xFF1E88E5.toInt(); c.drawCircle(-40f, 22f, 8f, p); c.drawCircle(40f, 22f, 8f, p)
        p.color = 0xFFFFF59D.toInt(); c.drawCircle(-80f, -32f, 9f, p); c.drawCircle(0f, -52f, 10f, p); c.drawCircle(80f, -32f, 9f, p)
        c.restore()
    }

    fun goldHammer(c: Canvas, s: Float) {
        c.save(); c.scale(s, s)
        r.set(-14f, -30f, 14f, 100f)
        p.color = -1; p.shader = LinearGradient(-14f, 0f, 14f, 0f, 0xFFE57373.toInt(), 0xFF8E1F1F.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 12f, 12f, p); p.shader = null
        outline(7f); c.drawRoundRect(r, 12f, 12f, o)
        p.color = 0xFFFFD54F.toInt(); r.set(-16f, 84f, 16f, 104f); c.drawRoundRect(r, 8f, 8f, p); outline(5f); c.drawRoundRect(r, 8f, 8f, o)
        r.set(-86f, -92f, 86f, -22f)
        p.color = -1; p.shader = LinearGradient(0f, -92f, 0f, -22f, intArrayOf(0xFFFFFDE7.toInt(), 0xFFFFD54F.toInt(), 0xFFF57F17.toInt()), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 18f, 18f, p); p.shader = null
        outline(8f); c.drawRoundRect(r, 18f, 18f, o)
        p.color = 0x99FFFFFF.toInt(); r.set(-74f, -84f, 70f, -70f); c.drawRoundRect(r, 7f, 7f, p)
        p.color = 0xFFE53935.toInt(); c.drawCircle(0f, -57f, 13f, p); outline(4f); c.drawCircle(0f, -57f, 13f, o)
        c.restore()
    }

    /** Cartoon glove pointer. Fingertip at (x,y); rot rotates around fingertip. */
    fun hand(c: Canvas, x: Float, y: Float, s: Float, rot: Float, press: Float = 0f) {
        c.save(); c.translate(x, y); c.rotate(rot); c.scale(s * (1f - 0.08f * press), s * (1f - 0.08f * press))
        val white = 0xFFFFFFFF.toInt(); val shade = 0xFFD7DCE6.toInt()
        // shadow
        p.shader = null; p.color = 0x40000000
        c.save(); c.translate(10f, 12f)
        r.set(-30f, 66f, 64f, 168f); c.drawRoundRect(r, 36f, 36f, p)
        r.set(-17f, -2f, 17f, 100f); c.drawRoundRect(r, 17f, 17f, p)
        c.restore()
        // cuff
        r.set(-34f, 156f, 70f, 204f)
        p.color = -1; p.shader = LinearGradient(0f, 156f, 0f, 204f, 0xFFFFFFFF.toInt(), 0xFFB0BEC5.toInt(), Shader.TileMode.CLAMP); c.drawRoundRect(r, 16f, 16f, p); p.shader = null
        outline(6f); c.drawRoundRect(r, 16f, 16f, o)
        outline(4f, 0xFF90A4AE.toInt()); c.drawLine(-22f, 172f, 58f, 172f, o); c.drawLine(-22f, 188f, 58f, 188f, o)
        // fist
        r.set(-30f, 66f, 64f, 166f)
        p.color = -1; p.shader = LinearGradient(-30f, 0f, 64f, 0f, white, shade, Shader.TileMode.CLAMP); c.drawRoundRect(r, 36f, 36f, p); p.shader = null
        outline(6f); c.drawRoundRect(r, 36f, 36f, o)
        // folded fingers (knuckles)
        for (k in 0..2) {
            val ky = 92f + k * 26f
            r.set(26f, ky - 16f, 74f, ky + 16f)
            p.color = -1; p.shader = LinearGradient(26f, 0f, 74f, 0f, white, shade, Shader.TileMode.CLAMP); c.drawRoundRect(r, 16f, 16f, p); p.shader = null
            outline(5f); c.drawRoundRect(r, 16f, 16f, o)
        }
        // thumb
        c.save(); c.rotate(-28f, -24f, 118f)
        r.set(-58f, 100f, -6f, 136f)
        p.color = -1; p.shader = LinearGradient(0f, 100f, 0f, 136f, white, shade, Shader.TileMode.CLAMP); c.drawRoundRect(r, 18f, 18f, p); p.shader = null
        outline(6f); c.drawRoundRect(r, 18f, 18f, o)
        c.restore()
        // index finger
        r.set(-18f, 0f, 18f, 104f)
        p.color = -1; p.shader = LinearGradient(-18f, 0f, 18f, 0f, white, shade, Shader.TileMode.CLAMP); c.drawRoundRect(r, 18f, 18f, p); p.shader = null
        outline(6f); c.drawRoundRect(r, 18f, 18f, o)
        outline(3.5f, 0xFFB0BEC5.toInt()); c.drawLine(-8f, 40f, 6f, 40f, o); c.drawLine(-8f, 66f, 6f, 66f, o)
        p.color = 0xCCFFFFFF.toInt(); r.set(-11f, 8f, -3f, 34f); c.drawRoundRect(r, 4f, 4f, p)
        c.restore()
    }

    /** Tap ripple drawn at the fingertip. */
    fun ripple(c: Canvas, x: Float, y: Float, t: Float) {
        for (k in 0..1) {
            val ph = ((t * 1.4f + k * 0.5f) % 1f)
            outline(8f * (1f - ph), withAlpha(0xFFFFFFFF.toInt(), (220 * (1f - ph)).toInt()))
            c.drawCircle(x, y, 20f + ph * 70f, o)
        }
    }

    fun petisco(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s)
        // bone-shaped cookie
        path.reset()
        path.addCircle(-62f, -22f, 28f, Path.Direction.CW); path.addCircle(-62f, 22f, 28f, Path.Direction.CW)
        path.addCircle(62f, -22f, 28f, Path.Direction.CW); path.addCircle(62f, 22f, 28f, Path.Direction.CW)
        r.set(-66f, -30f, 66f, 30f); path.addRect(r, Path.Direction.CW)
        p.color = -1; p.shader = LinearGradient(0f, -50f, 0f, 50f, 0xFFFFCC80.toInt(), 0xFFD68A3C.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        p.color = 0xFF8D4F2C.toInt()
        c.drawCircle(-20f, -8f, 6f, p); c.drawCircle(12f, 6f, 6f, p); c.drawCircle(34f, -10f, 5f, p); c.drawCircle(-40f, 12f, 5f, p)
        outline(7f); c.drawCircle(-62f, -22f, 28f, o); c.drawCircle(-62f, 22f, 28f, o); c.drawCircle(62f, -22f, 28f, o); c.drawCircle(62f, 22f, 28f, o)
        p.color = -1; p.shader = LinearGradient(0f, -50f, 0f, 50f, 0xFFFFCC80.toInt(), 0xFFD68A3C.toInt(), Shader.TileMode.CLAMP)
        r.set(-62f, -28f, 62f, 28f); c.drawRect(r, p); p.shader = null
        p.color = 0xFF8D4F2C.toInt(); c.drawCircle(-20f, -8f, 6f, p); c.drawCircle(12f, 6f, 6f, p); c.drawCircle(34f, -10f, 5f, p)
        outline(7f); c.drawLine(-62f, -28f, 62f, -28f, o); c.drawLine(-62f, 28f, 62f, 28f, o)
        c.restore()
    }

    fun lock(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s)
        outline(16f, 0xFF455A64.toInt()); r.set(-34f, -70f, 34f, 10f); c.drawArc(r, 180f, 180f, false, o)
        outline(6f); r.set(-46f, -76f, 46f, 16f); c.drawArc(r, 180f, 180f, false, o)
        r.set(-56f, -26f, 56f, 62f)
        p.color = -1; p.shader = LinearGradient(0f, -26f, 0f, 62f, 0xFFFFE082.toInt(), 0xFFF9A825.toInt(), Shader.TileMode.CLAMP); c.drawRoundRect(r, 14f, 14f, p); p.shader = null
        outline(7f); c.drawRoundRect(r, 14f, 14f, o)
        p.color = INK; c.drawCircle(0f, 12f, 11f, p); c.drawRect(-5f, 14f, 5f, 40f, p)
        c.restore()
    }

    fun iconGem(c: Canvas, x: Float, y: Float, s: Float) = gem(c, x, y + s * 0.04f, s / 190f, 0xFF26C6DA.toInt())
    fun iconPetisco(c: Canvas, x: Float, y: Float, s: Float) = petisco(c, x, y, s / 200f)
    fun iconSpins(c: Canvas, x: Float, y: Float, s: Float) = capsule(c, x, y, s / 200f)

    fun iconBell(c: Canvas, x: Float, y: Float, s: Float, t: Float, ring: Boolean) {
        c.save(); c.translate(x, y); val k = s / 100f; c.scale(k, k)
        if (ring) c.rotate(kotlin.math.sin(t * 18f) * 14f, 0f, -40f)
        path.reset(); path.moveTo(-34f, 22f); path.cubicTo(-34f, -30f, -26f, -40f, 0f, -40f); path.cubicTo(26f, -40f, 34f, -30f, 34f, 22f); path.lineTo(42f, 30f); path.lineTo(-42f, 30f); path.close()
        p.color = -1; p.shader = LinearGradient(0f, -40f, 0f, 30f, 0xFFFFF59D.toInt(), 0xFFFFA000.toInt(), Shader.TileMode.CLAMP); c.drawPath(path, p); p.shader = null
        outline(7f); c.drawPath(path, o)
        p.color = 0xFFFFA000.toInt(); c.drawCircle(0f, 38f, 10f, p); c.drawCircle(0f, -44f, 7f, p); outline(5f); c.drawCircle(0f, 38f, 10f, o)
        p.color = 0x88FFFFFF.toInt(); r.set(-22f, -28f, -12f, 14f); c.drawRoundRect(r, 5f, 5f, p)
        c.restore()
    }

    fun iconScroll(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); val k = s / 100f; c.scale(k, k)
        r.set(-32f, -40f, 32f, 40f); p.color = -1; p.shader = LinearGradient(0f, -40f, 0f, 40f, 0xFFFFF8E1.toInt(), 0xFFE8C48A.toInt(), Shader.TileMode.CLAMP); c.drawRect(r, p); p.shader = null
        outline(6f); c.drawRect(r, o)
        for (sy in floatArrayOf(-44f, 44f)) { r.set(-40f, sy - 9f, 40f, sy + 9f); p.color = 0xFFC8955A.toInt(); c.drawRoundRect(r, 9f, 9f, p); outline(5f); c.drawRoundRect(r, 9f, 9f, o) }
        outline(5f, 0xFF8D6E63.toInt()); c.drawLine(-20f, -18f, 20f, -18f, o); c.drawLine(-20f, 0f, 20f, 0f, o); c.drawLine(-20f, 18f, 8f, 18f, o)
        outline(8f, 0xFF43A047.toInt()); c.drawLine(-26f, -22f, -18f, -12f, o); c.drawLine(-18f, -12f, -6f, -30f, o)
        c.restore()
    }

    fun iconFriends(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); val k = s / 100f; c.scale(k, k)
        c.save(); c.translate(-20f, 52f); c.scale(0.2f, 0.2f); capi(c, 0f, 0f, 1f, 0f, Mood.HAPPY, 0, 0, headOnly = true); c.restore()
        c.save(); c.translate(24f, 60f); c.scale(0.21f, 0.21f); capi(c, 0f, 0f, 1f, 0f, Mood.IDLE, 0, 0xFFD7A86E.toInt(), headOnly = true); c.restore()
        p.color = 0xFFE91E63.toInt(); heart(c, 2f, -40f, 16f)
        c.restore()
    }

    fun heart(c: Canvas, x: Float, y: Float, rr: Float) {
        path.reset(); path.moveTo(x, y + rr); path.cubicTo(x - rr * 2f, y - rr * 0.2f, x - rr * 0.8f, y - rr * 1.6f, x, y - rr * 0.5f)
        path.cubicTo(x + rr * 0.8f, y - rr * 1.6f, x + rr * 2f, y - rr * 0.2f, x, y + rr); path.close()
        c.drawPath(path, p); outline(rr * 0.25f); c.drawPath(path, o)
    }

    fun iconPaw(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); val k = s / 100f; c.scale(k, k)
        p.color = -1; p.shader = LinearGradient(0f, -40f, 0f, 40f, 0xFFFFCC80.toInt(), 0xFFE65100.toInt(), Shader.TileMode.CLAMP)
        c.drawOval(-28f, -4f, 28f, 40f, p)
        c.drawOval(-44f, -30f, -22f, -2f, p); c.drawOval(-20f, -46f, 2f, -16f, p); c.drawOval(6f, -46f, 28f, -16f, p); c.drawOval(26f, -30f, 48f, -2f, p)
        p.shader = null
        outline(6f); c.drawOval(-28f, -4f, 28f, 40f, o); c.drawOval(-44f, -30f, -22f, -2f, o); c.drawOval(-20f, -46f, 2f, -16f, o); c.drawOval(6f, -46f, 28f, -16f, o); c.drawOval(26f, -30f, 48f, -2f, o)
        c.restore()
    }

    fun iconShop(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); val k = s / 100f; c.scale(k, k)
        outline(8f); r.set(-20f, -48f, 20f, -8f); c.drawArc(r, 180f, 180f, false, o)
        path.reset(); path.moveTo(-38f, -24f); path.lineTo(38f, -24f); path.lineTo(44f, 42f); path.lineTo(-44f, 42f); path.close()
        p.color = -1; p.shader = LinearGradient(0f, -24f, 0f, 42f, 0xFFFF8A80.toInt(), 0xFFC62828.toInt(), Shader.TileMode.CLAMP); c.drawPath(path, p); p.shader = null
        outline(7f); c.drawPath(path, o)
        coin(c, 0f, 10f, 18f)
        c.restore()
    }

    fun iconGift(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); val k = s / 100f; c.scale(k, k)
        r.set(-40f, -12f, 40f, 44f); p.color = -1; p.shader = LinearGradient(0f, -12f, 0f, 44f, 0xFFBA68C8.toInt(), 0xFF6A1B9A.toInt(), Shader.TileMode.CLAMP); c.drawRect(r, p); p.shader = null
        outline(6f); c.drawRect(r, o)
        r.set(-46f, -30f, 46f, -10f); p.color = 0xFFCE93D8.toInt(); c.drawRect(r, p); c.drawRect(r, o)
        p.color = 0xFFFFD54F.toInt(); c.drawRect(-9f, -30f, 9f, 44f, p); outline(4f); c.drawRect(-9f, -30f, 9f, 44f, o)
        p.color = 0xFFFFD54F.toInt(); c.drawOval(-34f, -50f, -2f, -28f, p); c.drawOval(2f, -50f, 34f, -28f, p); outline(5f); c.drawOval(-34f, -50f, -2f, -28f, o); c.drawOval(2f, -50f, 34f, -28f, o)
        c.restore()
    }

    fun iconTrophy(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); val k = s / 100f; c.scale(k, k)
        p.color = -1; p.shader = LinearGradient(0f, -44f, 0f, 44f, 0xFFFFF59D.toInt(), 0xFFFF8F00.toInt(), Shader.TileMode.CLAMP)
        path.reset(); path.moveTo(-34f, -44f); path.lineTo(34f, -44f); path.cubicTo(34f, 0f, 14f, 14f, 0f, 14f); path.cubicTo(-14f, 14f, -34f, 0f, -34f, -44f); path.close(); c.drawPath(path, p)
        r.set(-10f, 10f, 10f, 30f); c.drawRect(r, p); r.set(-30f, 28f, 30f, 44f); c.drawRoundRect(r, 6f, 6f, p); p.shader = null
        outline(6f); c.drawPath(path, o); c.drawRoundRect(r, 6f, 6f, o)
        r.set(-52f, -40f, -22f, -6f); c.drawArc(r, 90f, 180f, false, o); r.set(22f, -40f, 52f, -6f); c.drawArc(r, 270f, 180f, false, o)
        c.restore()
    }

    fun iconTurbo(c: Canvas, x: Float, y: Float, s: Float, on: Boolean, t: Float) {
        if (on) glow(c, x, y, s * 0.9f, 0xFF00E5FF.toInt(), 0.7f + 0.3f * kotlin.math.sin(t * 10f))
        boltPath(x, y, s / 170f)
        p.color = -1; p.shader = LinearGradient(0f, y - s / 2, 0f, y + s / 2, if (on) 0xFFE0F7FA.toInt() else 0xFFFFFDE7.toInt(), if (on) 0xFF00B8D4.toInt() else 0xFF9E9E9E.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        outline(s * 0.05f); c.drawPath(path, o)
    }

    fun iconPix(c: Canvas, x: Float, y: Float, s: Float, col: Int = 0xFF32BCAD.toInt()) {
        c.save(); c.translate(x, y); val k = s / 100f; c.scale(k, k); c.rotate(45f)
        p.shader = null; p.color = col
        for (q in 0..3) { c.save(); c.rotate(q * 90f); r.set(6f, 6f, 40f, 40f); c.drawRoundRect(r, 10f, 10f, p); c.restore() }
        c.restore()
    }

    fun iconCopy(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); val k = s / 100f; c.scale(k, k)
        outline(8f, 0xFFFFFFFF.toInt())
        r.set(-30f, -36f, 18f, 22f); c.drawRoundRect(r, 8f, 8f, o)
        p.color = 0x55FFFFFF; r.set(-14f, -20f, 34f, 38f); c.drawRoundRect(r, 8f, 8f, p); c.drawRoundRect(r, 8f, 8f, o)
        c.restore()
    }

    fun iconGoogle(c: Canvas, x: Float, y: Float, s: Float) {
        val rr = s * 0.42f; val w = s * 0.17f
        o.shader = null; o.pathEffect = null; o.strokeWidth = w; o.strokeCap = Paint.Cap.BUTT
        r.set(x - rr, y - rr, x + rr, y + rr)
        o.color = 0xFFEA4335.toInt(); c.drawArc(r, 200f, 110f, false, o)
        o.color = 0xFFFBBC05.toInt(); c.drawArc(r, 130f, 72f, false, o)
        o.color = 0xFF34A853.toInt(); c.drawArc(r, 40f, 92f, false, o)
        o.color = 0xFF4285F4.toInt(); c.drawArc(r, -6f, 48f, false, o)
        p.shader = null; p.color = 0xFF4285F4.toInt(); c.drawRect(x, y - w / 2, x + rr + w / 2, y + w / 2, p)
        o.strokeCap = Paint.Cap.ROUND
    }

    fun iconMail(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); val k = s / 100f; c.scale(k, k)
        r.set(-42f, -30f, 42f, 30f); p.color = 0xFFFFFFFF.toInt(); c.drawRoundRect(r, 8f, 8f, p); outline(6f); c.drawRoundRect(r, 8f, 8f, o)
        c.drawLine(-40f, -26f, 0f, 6f, o); c.drawLine(40f, -26f, 0f, 6f, o)
        c.restore()
    }

    /** Round avatar: capi face over a colored medallion. */
    fun avatar(c: Canvas, x: Float, y: Float, rad: Float, id: Int, ring: Int = 0xFFFFD54F.toInt()) {
        val bgs = intArrayOf(0xFF26A69A.toInt(), 0xFF5C6BC0.toInt(), 0xFFEC407A.toInt(), 0xFFFFA726.toInt(), 0xFF66BB6A.toInt(), 0xFF8D6E63.toInt())
        val bg = bgs[((id % bgs.size) + bgs.size) % bgs.size]
        p.color = -1; p.shader = RadialGradient(x - rad * 0.3f, y - rad * 0.4f, rad * 1.4f, lighten(bg, 0.35f), darken(bg, 0.25f), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, rad, p); p.shader = null
        val sc = c.save()
        path.reset(); path.addCircle(x, y, rad - 2f, Path.Direction.CW); c.clipPath(path)
        c.save(); c.translate(x, y + rad * 1.05f); c.scale(rad / 210f, rad / 210f); capi(c, 0f, 0f, 1f, 0f, Mood.HAPPY, 0, 0, headOnly = true); c.restore()
        c.restoreToCount(sc)
        outline(rad * 0.12f, ring); c.drawCircle(x, y, rad, o)
        outline(rad * 0.05f); c.drawCircle(x, y, rad + rad * 0.07f, o)
    }

    // ---------------------------------------------------------------- icons (UI)
    fun iconCoin(c: Canvas, x: Float, y: Float, s: Float) = coin(c, x, y, s * 0.5f)
    fun iconShield(c: Canvas, x: Float, y: Float, s: Float, on: Boolean) {
        if (on) shield(c, x, y, s / 190f, 0xFF1E88E5.toInt())
        else {
            c.save(); c.translate(x, y); c.scale(s / 190f, s / 190f)
            shieldPath(1f); p.shader = null; p.color = 0x55000000; c.drawPath(path, p)
            outline(8f, 0x99FFFFFF.toInt()); c.drawPath(path, o)
            c.restore()
        }
    }
    fun iconEnergy(c: Canvas, x: Float, y: Float, s: Float) {
        boltPath(x, y, s / 160f)
        p.color = -1; p.shader = LinearGradient(0f, y - s / 2, 0f, y + s / 2, 0xFFFFFDE7.toInt(), 0xFFFFB300.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        outline(s * 0.05f); c.drawPath(path, o)
    }
    fun iconHouse(c: Canvas, x: Float, y: Float, s: Float) {
        val k = s / 100f
        r.set(x - 32 * k, y - 10 * k, x + 32 * k, y + 40 * k)
        p.color = 0xFFFFE0B2.toInt(); c.drawRect(r, p); outline(6 * k); c.drawRect(r, o)
        path.reset(); path.moveTo(x - 46 * k, y - 6 * k); path.lineTo(x, y - 44 * k); path.lineTo(x + 46 * k, y - 6 * k); path.close()
        p.color = 0xFFE53935.toInt(); c.drawPath(path, p); c.drawPath(path, o)
        r.set(x - 10 * k, y + 12 * k, x + 10 * k, y + 40 * k); p.color = 0xFF6D4C41.toInt(); c.drawRect(r, p); c.drawRect(r, o)
    }
    fun iconWheel(c: Canvas, x: Float, y: Float, s: Float, t: Float) {
        val rad = s * 0.46f
        val cols = intArrayOf(0xFFE53935.toInt(), 0xFFFFC107.toInt(), 0xFF43A047.toInt(), 0xFF1E88E5.toInt())
        for (i in 0 until 8) {
            p.color = cols[i % 4]
            r.set(x - rad, y - rad, x + rad, y + rad)
            c.drawArc(r, t * 40f + i * 45f, 45f, true, p)
        }
        outline(s * 0.06f); c.drawCircle(x, y, rad, o)
        p.color = 0xFFFFF59D.toInt(); c.drawCircle(x, y, rad * 0.22f, p); c.drawCircle(x, y, rad * 0.22f, o)
    }
    fun iconChest(c: Canvas, x: Float, y: Float, s: Float) = chest(c, x, y + s * 0.1f, s / 200f, 0f, 0)
    fun iconGear(c: Canvas, x: Float, y: Float, s: Float) {
        val rad = s * 0.42f
        p.color = 0xFFCFD8DC.toInt()
        path.reset()
        for (i in 0 until 16) {
            val a = i * PI.toFloat() / 8
            val rr = if (i % 2 == 0) rad else rad * 0.78f
            val a0 = a - 0.18f; val a1 = a + 0.18f
            if (i == 0) path.moveTo(x + cos(a0) * rr, y + sin(a0) * rr) else path.lineTo(x + cos(a0) * rr, y + sin(a0) * rr)
            path.lineTo(x + cos(a1) * rr, y + sin(a1) * rr)
        }
        path.close()
        c.drawPath(path, p); outline(s * 0.06f); c.drawPath(path, o)
        p.color = 0xFF546E7A.toInt(); c.drawCircle(x, y, rad * 0.35f, p); c.drawCircle(x, y, rad * 0.35f, o)
    }
    fun iconHammer(c: Canvas, x: Float, y: Float, s: Float) { c.save(); c.translate(x, y); c.rotate(-30f); hammer(c, s / 210f); c.restore() }

    /** Treasure chest. kind 0 wood, 1 gold, 2 magic. open 0..1 */
    fun chest(c: Canvas, x: Float, y: Float, s: Float, open: Float, kind: Int) {
        c.save(); c.translate(x, y); c.scale(s, s)
        val body = when (kind) { 1 -> 0xFFFFB300.toInt(); 2 -> 0xFF7E57C2.toInt(); else -> 0xFF9C5B2E.toInt() }
        val band = when (kind) { 1 -> 0xFFFFF176.toInt(); 2 -> 0xFF4DD0E1.toInt(); else -> 0xFFB0BEC5.toInt() }
        if (open > 0f) glow(c, 0f, -40f, 200f * open, if (kind == 2) 0xFFE1BEE7.toInt() else 0xFFFFF59D.toInt(), open)
        r.set(-95f, -40f, 95f, 70f)
        p.color = -1; p.shader = LinearGradient(0f, -40f, 0f, 70f, lighten(body, 0.2f), darken(body, 0.3f), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 12f, 12f, p); p.shader = null
        outline(8f); c.drawRoundRect(r, 12f, 12f, o)
        p.color = band
        for (bx in floatArrayOf(-70f, 52f)) { r.set(bx, -40f, bx + 18f, 70f); c.drawRect(r, p); outline(5f); c.drawRect(r, o) }
        // lid
        c.save(); c.translate(0f, -40f); c.rotate(-open * 35f, -95f, 0f)
        path.reset(); path.moveTo(-98f, 0f); path.lineTo(-98f, -40f); path.cubicTo(-98f, -95f, 98f, -95f, 98f, -40f); path.lineTo(98f, 0f); path.close()
        p.color = -1; p.shader = LinearGradient(0f, -90f, 0f, 0f, lighten(body, 0.35f), darken(body, 0.1f), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        outline(8f); c.drawPath(path, o)
        p.color = band
        for (bx in floatArrayOf(-70f, 52f)) { r.set(bx, -82f, bx + 18f, 0f); c.drawRect(r, p); outline(5f); c.drawRect(r, o) }
        c.restore()
        // lock
        r.set(-18f, -52f, 18f, -10f); p.color = band; c.drawRoundRect(r, 8f, 8f, p); outline(6f); c.drawRoundRect(r, 8f, 8f, o)
        p.color = INK; c.drawCircle(0f, -34f, 6f, p)
        c.restore()
    }

    // ---------------------------------------------------------------- mascot "Capi"
    object Mood { const val IDLE = 0; const val HAPPY = 1; const val WOW = 2; const val SAD = 3 }

    /**
     * Capi the capybara with an orange on her head and a red bandana.
     * (x,y) = feet position. prop: 0 none, 1 hammer, 2 shovel. tint: 0 = natural, else monochrome material color.
     */
    fun capi(c: Canvas, x: Float, y: Float, s: Float, t: Float, mood: Int, prop: Int, tint: Int, headOnly: Boolean = false, swing: Float = 0f, blinkOk: Boolean = true) {
        val fur = if (tint == 0) 0xFFA8693A.toInt() else tint
        val furD = darken(fur, 0.28f)
        val furL = lighten(fur, 0.28f)
        val snout = if (tint == 0) 0xFF7A4724.toInt() else darken(tint, 0.18f)
        val ink = if (tint == 0) INK else darken(tint, 0.65f)
        c.save(); c.translate(x, y); c.scale(s, s)
        val bob = if (headOnly) 0f else sin(t * 2.4f) * 5f
        if (!headOnly) {
            // shadow
            p.shader = null; p.color = 0x44000000; c.drawOval(-120f, -18f, 120f, 16f, p)
            // feet
            p.color = furD
            c.drawOval(-95f, -30f, -18f, 6f, p); c.drawOval(18f, -30f, 95f, 6f, p)
            outline(7f, ink); c.drawOval(-95f, -30f, -18f, 6f, o); c.drawOval(18f, -30f, 95f, 6f, o)
            // body
            c.save(); c.translate(0f, bob * 0.5f)
            p.color = -1; p.shader = RadialGradient(-30f, -150f, 190f, furL, furD, Shader.TileMode.CLAMP)
            c.drawOval(-118f, -210f, 118f, -8f, p); p.shader = null
            outline(8f, ink); c.drawOval(-118f, -210f, 118f, -8f, o)
            p.color = withAlpha(lighten(fur, 0.45f), 200); c.drawOval(-70f, -160f, 70f, -28f, p)
            // left arm
            c.save(); c.rotate(18f, -100f, -150f)
            p.color = fur; c.drawOval(-130f, -165f, -78f, -62f, p); outline(7f, ink); c.drawOval(-130f, -165f, -78f, -62f, o)
            c.restore()
            // right arm (+prop)
            c.save()
            val armRot = if (prop != 0) -165f + swing else -18f
            c.rotate(armRot, 96f, -150f)
            if (prop == 1) { c.save(); c.translate(104f, 34f); c.rotate(180f); goldHammer(c, 0.85f); c.restore() }
            if (prop == 2) { c.save(); c.translate(104f, -40f); c.rotate(180f); shovel(c, 0.8f); c.restore() }
            p.color = fur; c.drawOval(78f, -165f, 130f, -62f, p); outline(7f, ink); c.drawOval(78f, -165f, 130f, -62f, o)
            c.restore()
            c.restore()
        }
        c.save(); c.translate(0f, bob)
        // bandana
        if (!headOnly) {
            path.reset(); path.moveTo(-88f, -200f); path.lineTo(88f, -200f); path.lineTo(0f, -128f); path.close()
            p.color = if (tint == 0) 0xFFE53935.toInt() else darken(tint, 0.1f); c.drawPath(path, p)
            outline(7f, ink); c.drawPath(path, o)
            p.color = 0xCCFFFFFF.toInt()
            c.drawCircle(-40f, -186f, 7f, p); c.drawCircle(10f, -182f, 7f, p); c.drawCircle(46f, -190f, 6f, p); c.drawCircle(-8f, -158f, 6f, p)
        }
        // ears
        for (ex in floatArrayOf(-78f, 78f)) {
            p.color = furD; c.drawCircle(ex, -338f, 24f, p); outline(7f, ink); c.drawCircle(ex, -338f, 24f, o)
            p.color = if (tint == 0) 0xFFF4A3A8.toInt() else furL; c.drawCircle(ex, -336f, 11f, p)
        }
        // head
        r.set(-102f, -350f, 102f, -182f)
        p.color = -1; p.shader = RadialGradient(-30f, -320f, 230f, furL, fur, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 80f, 80f, p); p.shader = null
        outline(8f, ink); c.drawRoundRect(r, 80f, 80f, o)
        // snout
        r.set(-76f, -276f, 76f, -188f)
        p.color = snout; c.drawRoundRect(r, 44f, 44f, p); outline(6f, ink); c.drawRoundRect(r, 44f, 44f, o)
        p.color = ink
        c.drawOval(-36f, -258f, -16f, -244f, p); c.drawOval(16f, -258f, 36f, -244f, p)
        // mouth
        when (mood) {
            Mood.HAPPY, Mood.WOW -> {
                path.reset(); path.moveTo(-26f, -226f); path.quadTo(0f, -224f, 26f, -226f); path.quadTo(22f, -194f, 0f, -194f); path.quadTo(-22f, -194f, -26f, -226f); path.close()
                p.color = 0xFF7B1F1F.toInt(); c.drawPath(path, p)
                p.color = 0xFFF06292.toInt(); c.drawOval(-12f, -210f, 12f, -196f, p)
                outline(5f, ink); c.drawPath(path, o)
            }
            Mood.SAD -> { outline(6f, ink); path.reset(); path.moveTo(-20f, -206f); path.quadTo(0f, -222f, 20f, -206f); c.drawPath(path, o) }
            else -> { outline(6f, ink); path.reset(); path.moveTo(-22f, -220f); path.quadTo(0f, -204f, 22f, -220f); c.drawPath(path, o) }
        }
        // cheeks
        p.color = 0x66FF6F91; c.drawCircle(-78f, -240f, 18f, p); c.drawCircle(78f, -240f, 18f, p)
        // eyes
        val blink = blinkOk && (t % 3.4f) < 0.13f
        for (ex in floatArrayOf(-50f, 50f)) {
            if (mood == Mood.HAPPY) {
                outline(8f, ink); r.set(ex - 16f, -306f, ex + 16f, -280f); c.drawArc(r, 200f, 140f, false, o)
            } else if (blink) {
                outline(7f, ink); c.drawLine(ex - 14f, -294f, ex + 14f, -294f, o)
            } else {
                val ey = if (mood == Mood.WOW) 20f else 16f
                p.color = ink; c.drawOval(ex - 13f, -294f - ey, ex + 13f, -294f + ey, p)
                p.color = Color.WHITE; c.drawCircle(ex - 4f, -300f, 6f, p); c.drawCircle(ex + 5f, -286f, 3f, p)
                if (mood == Mood.SAD) { outline(6f, ink); c.drawLine(ex - 18f, -322f + (if (ex < 0) 8f else 0f), ex + 18f, -322f + (if (ex < 0) 0f else 8f), o) }
            }
        }
        // orange on head
        if (tint == 0 || headOnly) {
            p.color = -1; p.shader = RadialGradient(-12f, -392f, 52f, 0xFFFFCC80.toInt(), 0xFFF57C00.toInt(), Shader.TileMode.CLAMP)
        } else p.color = lighten(tint, 0.15f)
        c.drawCircle(0f, -378f, 38f, p); p.shader = null
        outline(7f, ink); c.drawCircle(0f, -378f, 38f, o)
        p.color = if (tint == 0) 0xFF7CB342.toInt() else furL
        c.save(); c.rotate(-25f, 14f, -416f); c.drawOval(4f, -426f, 44f, -408f, p); outline(5f, ink); c.drawOval(4f, -426f, 44f, -408f, o); c.restore()
        p.color = 0x88FFFFFF.toInt(); c.drawCircle(-14f, -392f, 9f, p)
        c.restore()
        c.restore()
    }

    fun shovel(c: Canvas, s: Float) {
        c.save(); c.scale(s, s)
        r.set(-8f, -100f, 8f, 40f); p.color = 0xFF8D5A2B.toInt(); c.drawRect(r, p); outline(6f); c.drawRect(r, o)
        r.set(-24f, -116f, 24f, -98f); c.drawRoundRect(r, 8f, 8f, p); c.drawRoundRect(r, 8f, 8f, o)
        path.reset(); path.moveTo(-34f, 34f); path.lineTo(34f, 34f); path.lineTo(30f, 84f); path.quadTo(0f, 112f, -30f, 84f); path.close()
        p.color = -1; p.shader = LinearGradient(-34f, 0f, 34f, 0f, 0xFFECEFF1.toInt(), 0xFF78909C.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null; c.drawPath(path, o)
        c.restore()
    }

    /** Cloud made of puffs. */
    fun cloud(c: Canvas, x: Float, y: Float, s: Float, col: Int, a: Int = 230) {
        p.shader = null
        p.color = withAlpha(darken(col, 0.18f), (a * 0.6f).toInt())
        c.drawOval(x - 120 * s, y + 10 * s, x + 130 * s, y + 52 * s, p)
        p.color = withAlpha(col, a)
        c.drawCircle(x - 70 * s, y + 20 * s, 42 * s, p)
        c.drawCircle(x - 15 * s, y - 10 * s, 62 * s, p)
        c.drawCircle(x + 55 * s, y + 6 * s, 50 * s, p)
        c.drawCircle(x + 100 * s, y + 26 * s, 32 * s, p)
        r.set(x - 110 * s, y + 10 * s, x + 130 * s, y + 52 * s); c.drawRoundRect(r, 30 * s, 30 * s, p)
    }
}
