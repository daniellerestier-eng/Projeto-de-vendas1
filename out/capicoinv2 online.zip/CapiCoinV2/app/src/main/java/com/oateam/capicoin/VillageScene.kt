package com.oateam.capicoin

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.exp
import kotlin.math.sin

/** Building slot positions shared by village/attack scenes. */
object Layout {
    private val pos = arrayOf(
        floatArrayOf(866f, 0.525f, 1.0f),   // house
        floatArrayOf(200f, 0.505f, 0.95f),  // tower
        floatArrayOf(805f, 0.695f, 1.12f),  // statue
        floatArrayOf(285f, 0.705f, 1.1f),   // market
        floatArrayOf(540f, 0.47f, 1.0f)     // temple
    )
    val drawOrder = intArrayOf(4, 1, 0, 3, 2)
    fun x(slot: Int) = pos[slot][0]
    fun y(slot: Int, h: Float) = h * pos[slot][1]
    fun s(slot: Int) = pos[slot][2]
}

class VillageScene(g: Game) : Scene(g) {
    private val amb = Scenery.Ambience(g)
    private val pop = FloatArray(5) { 1f }
    private val shakeCard = FloatArray(5)
    private val pressed = BooleanArray(5)
    private val cards = Array(5) { RectF() }
    private var panelTop = 0f
    private var tip = -1; private var tipT = 0f
    private var completeShown = false
    private var smokeAcc = 0f
    private var lastVillage = g.prof?.village ?: 1
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spinBtn = Button(0f, 0f, 0f, 0f, "GIRAR", 0xFFE53935.toInt()) { g.goto(g.slot) }

    init { spinBtn.icon = { c, x, y, s -> Art.symbol(c, Sym.COIN, x, y, s * 1.1f) } }

    private fun names(): List<String> = g.prof?.j?.get("buildingNames")?.list?.map { it.str() } ?: g.prof?.theme?.buildings?.toList() ?: List(5) { "Prédio" }

    override fun layout() {
        panelTop = g.H - 520f
        val w = (g.W - 40f - 4 * 14f) / 5
        for (i in 0 until 5) cards[i].set(20f + i * (w + 14f), panelTop + 150f, 20f + i * (w + 14f) + w, g.H - 40f)
        spinBtn.set(g.W - 250f, 240f, 220f, 150f)
    }

    override fun enter() {
        completeShown = false
        g.audio.startMusic()
        val pr = g.prof ?: return
        if (lastVillage != pr.village) {
            lastVillage = pr.village
            g.banner("NOVA VILA!", pr.theme.name, 0xFF80DEEA.toInt(), 2.2f)
            g.fx.confetti(80)
        }
        if (pr.complete) { completeShown = true; g.show(VillageCompletePopup(g)) }
        else Tips.show(g, "village")
    }

    private fun tryBuild(i: Int) {
        val pr = g.prof ?: return
        val dmg = pr.damaged[i]
        if (!dmg && pr.levels[i] >= MAX_LEVEL) { tip = i; tipT = 1.6f; g.audio.play("tick"); return }
        val cost = pr.costs[i]
        if (pr.coins < cost) {
            shakeCard[i] = 0.4f
            g.audio.play("tick", 0.8f, 0.7f); g.audio.vibrate(40, 80)
            g.fx.text("Faltam " + Fmt.n(cost - pr.coins), cards[i].centerX().coerceIn(200f, g.W - 200f), cards[i].top - 40f, 0xFFFF8A80.toInt(), 50f)
            return
        }
        // optimistic: animate right away, the server confirms
        pr.coins -= cost
        if (dmg) pr.damaged[i] = false else pr.levels[i]++
        pop[i] = 0f
        val bx = Layout.x(i); val by = Layout.y(i, g.H)
        g.fx.dust(bx, by - 30f, 14, 0xFFEFEBE9.toInt(), 120f)
        g.fx.burst(bx, by - Scenery.height(i, pr.levels[i]) * Layout.s(i) * 0.6f, 22, P.STAR, intArrayOf(0xFFFFF59D.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFD54F.toInt()), 900f, 22f, 0.9f, 800f)
        g.audio.play("build"); g.audio.vibrate(60, 140); g.shake(6f, 0.25f)
        g.fx.text(if (dmg) "Reparado!" else "Nível ${pr.levels[i]}!", bx, by - Scenery.height(i, pr.levels[i]) * Layout.s(i) - 40f, 0xFFB9F6CA.toInt(), 64f)
        tip = i; tipT = 1.4f
        g.net.call("POST", "/api/build", mapOf("slot" to i)) { r ->
            if (!r.ok) { g.error(r); g.refreshProfile(); return@call }
            if (r.j["result"]["complete"].bool() && !completeShown) {
                completeShown = true
                g.audio.play("complete"); g.fx.confetti(160)
                g.show(VillageCompletePopup(g))
            }
        }
    }

    override fun update(dt: Float) {
        val pr = g.prof ?: return
        amb.update(dt, pr.theme, g.W, g.H)
        for (i in 0 until 5) { pop[i] = (pop[i] + dt * 1.6f).coerceAtMost(1f); shakeCard[i] = (shakeCard[i] - dt).coerceAtLeast(0f) }
        if (tipT > 0f) tipT -= dt
        smokeAcc += dt
        if (smokeAcc > 0.25f) {
            smokeAcc = 0f
            for (i in 0 until 5) {
                val x = Layout.x(i); val y = Layout.y(i, g.H); val s = Layout.s(i)
                if (pr.damaged[i]) {
                    val q = g.fx.spawn(P.SMOKE, x + rnd(-50f, 50f) * s, y - 120f * s, rnd(-20f, 20f), rnd(-120f, -60f), 1.6f, 26f, 0xFF616161.toInt(), 0f); q.grow = 30f; q.drag = 0.99f
                } else if (i == 0 && pr.levels[0] >= 3) {
                    val lv = pr.levels[0]
                    val cx = x + (170f + lv * 14f) * 0.18f * s + 17f * s
                    val q = g.fx.spawn(P.SMOKE, cx, y - (110f + lv * 16f + 90f + lv * 4f) * s, rnd(-10f, 10f), rnd(-80f, -50f), 1.8f, 14f, 0xFFECEFF1.toInt(), 0f); q.grow = 18f; q.drag = 0.99f
                }
            }
        }
    }

    override fun draw(c: Canvas) {
        val pr = g.prof ?: return
        val th = pr.theme
        Scenery.background(c, th, g.W, g.H, g.scale)
        for (i in Layout.drawOrder) {
            val k = pop[i]
            val sc = Layout.s(i) * (if (k < 1f) 1f + 0.35f * exp(-k * 6f) * sin(k * 22f) else 1f)
            Scenery.building(c, th, i, pr.levels[i], pr.damaged[i], Layout.x(i), Layout.y(i, g.H), sc, g.time + i)
        }
        amb.draw(c, th, g.W, g.H, g.time)
        val nm = names()
        if (tip >= 0 && tipT > 0f) {
            val x = Layout.x(tip).coerceIn(220f, g.W - 220f)
            val y = Layout.y(tip, g.H) - Scenery.height(tip, pr.levels[tip]) * Layout.s(tip) - 110f
            val a = clamp01(tipT / 0.3f)
            c.save(); c.scale(a, a, x, y)
            Ui.panel(c, x - 210f, y - 50f, x + 210f, y + 50f, 0xFF3949AB.toInt(), 30f, bw = 6f)
            Ui.text(c, nm.getOrElse(tip) { "" } + (if (pr.levels[tip] >= MAX_LEVEL) " ★" else ""), x, y, 36f, maxW = 390f)
            c.restore()
        }
        drawPanel(c, pr, th, nm)
        spinBtn.draw(c, g.time)
        g.drawHud(c)
        Ui.pill(c, 30f, 250f, 560f, 330f, 0xAA1B0E05.toInt())
        Ui.text(c, "VILA ${pr.village}", 70f, 276f, 40f, align = Paint.Align.LEFT, gold = true)
        Ui.text(c, th.name, 70f, 312f, 30f, align = Paint.Align.LEFT, maxW = 470f)
    }

    private fun drawPanel(c: Canvas, pr: Profile, th: Theme, nm: List<String>) {
        Ui.panel(c, 0f, panelTop, g.W, g.H + 60f, 0xFF4E342E.toInt(), 50f)
        val prog = pr.progress
        Ui.text(c, "Construa tudo para a próxima ilha!", g.W / 2, panelTop + 44f, 38f, 0xFFFFF3C4.toInt(), maxW = g.W - 80f)
        Ui.bar(c, 60f, panelTop + 80f, g.W - 60f, panelTop + 124f, prog, 0xFFFFEE58.toInt(), 0xFFF9A825.toInt())
        Ui.text(c, "${(prog * 100).toInt()}%", g.W / 2, panelTop + 102f, 32f)
        for (i in 0 until 5) {
            val rc = cards[i]
            val lv = pr.levels[i]; val dmg = pr.damaged[i]
            val maxed = lv >= MAX_LEVEL && !dmg
            val cost = pr.costs[i]
            val afford = !maxed && pr.coins >= cost
            val sx = if (shakeCard[i] > 0f) sin(shakeCard[i] * 60f) * 12f else 0f
            val off = if (pressed[i]) 8f else 0f
            c.save(); c.translate(sx, off)
            val col = when { maxed -> 0xFF2E7D32.toInt(); dmg -> 0xFFC62828.toInt(); afford -> 0xFF1565C0.toInt(); else -> 0xFF455A64.toInt() }
            Ui.panel(c, rc.left, rc.top, rc.right, rc.bottom, col, 30f, bw = 6f)
            val save = c.save()
            c.clipRect(rc.left + 6f, rc.top + 6f, rc.right - 6f, rc.top + 150f)
            val mlv = maxOf(lv, 1)
            Scenery.building(c, th, i, mlv, false, rc.centerX(), rc.top + 140f, minOf(0.32f, 128f / (Scenery.height(i, mlv) + 60f)), g.time + i)
            c.restoreToCount(save)
            val sw = 30f; val sx0 = rc.centerX() - sw * 2
            for (s in 0 until MAX_LEVEL) Art.star(c, sx0 + s * sw, rc.top + 168f, 14f, s < lv)
            Ui.text(c, nm.getOrElse(i) { "" }, rc.centerX(), rc.top + 204f, 25f, maxW = rc.width() - 16f, ow = 4f)
            if (maxed) Ui.text(c, "MÁXIMO", rc.centerX(), rc.bottom - 50f, 32f, 0xFFB9F6CA.toInt())
            else {
                Ui.text(c, if (dmg) "REPARAR" else if (lv == 0) "CONSTRUIR" else "MELHORAR", rc.centerX(), rc.bottom - 78f, 24f, if (dmg) 0xFFFFCDD2.toInt() else 0xFFFFF3C4.toInt(), maxW = rc.width() - 12f, ow = 4f)
                Art.coin(c, rc.left + 30f, rc.bottom - 36f, 16f)
                Ui.text(c, Fmt.n(cost), rc.centerX() + 14f, rc.bottom - 36f, 32f, if (afford) 0xFFFFFFFF.toInt() else 0xFFFF8A80.toInt(), maxW = rc.width() - 58f)
                if (afford) {
                    val a = 0.5f + 0.5f * sin(g.time * 5f + i)
                    p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = withAlpha(0xFFFFEB3B.toInt(), (a * 255).toInt())
                    c.drawRoundRect(rc, 30f, 30f, p); p.style = Paint.Style.FILL
                }
            }
            c.restore()
        }
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (g.hudTouch(type, x, y)) return
        if (spinBtn.touch(type, x, y, g)) return
        for (i in 0 until 5) {
            val inside = cards[i].contains(x, y)
            when (type) {
                Game.DOWN -> pressed[i] = inside
                Game.MOVE -> if (!inside) pressed[i] = false
                Game.UP -> if (pressed[i]) { pressed[i] = false; if (inside) tryBuild(i) }
            }
        }
        val pr = g.prof ?: return
        if (type == Game.UP && y < panelTop) {
            for (i in Layout.drawOrder.reversed()) {
                val bx = Layout.x(i); val by = Layout.y(i, g.H); val s = Layout.s(i)
                val hgt = Scenery.height(i, pr.levels[i]) * s
                if (x in bx - 150f * s..bx + 150f * s && y in by - hgt..by + 20f) { tip = i; tipT = 1.6f; pop[i] = 0.4f; g.audio.play("pop", 0.6f); break }
            }
        }
    }

    override fun back(): Boolean { g.goto(g.slot); return true }
}

/** Village of another player (or bot) as sent by the server. */
class Target(val j: J) {
    val id = j["id"].long()
    val name = j["name"].str("Rival")
    val avatar = j["avatar"].int()
    val village = j["village"].int(1)
    val levels = IntArray(5) { j["levels"][it].int() }
    val damaged = BooleanArray(5) { j["damaged"][it].bool() }
    val bot = j["bot"].bool()
    val friend = j["friend"].bool()
    val revenge = j["revenge"].bool()
    val coins = j["coins"].long()
    val theme: Theme get() = Themes.forVillage(village)
    val tag: String get() = when { revenge -> "VINGANÇA"; friend -> "AMIGO"; bot -> "RIVAL"; else -> "JOGADOR" }
    val tagColor: Int get() = when { revenge -> 0xFFC62828.toInt(); friend -> 0xFF7B1FA2.toInt(); bot -> 0xFF546E7A.toInt(); else -> 0xFF1565C0.toInt() }
}

/** Attack a rival village with a giant hammer (resolved by the server). */
class AttackScene(g: Game) : Scene(g) {
    private val amb = Scenery.Ambience(g)
    private var state = 0 // 0 loading, 1 choose, 2 flying, 3 result
    private var target: Target? = null
    private var options: List<Target> = emptyList()
    private var slot = -1
    private var flyT = 0f
    private var resultT = 0f
    private var shieldT = -1f
    private var hit: J? = null
    private var reward = 0L
    private val shakeB = FloatArray(5)
    private val cont = Button(0f, 0f, 0f, 0f, "CONTINUAR", 0xFF43A047.toInt()) { g.goto(g.slot) }
    private val change = Button(0f, 0f, 0f, 0f, "TROCAR ALVO", 0xFF5E35B1.toInt()) { g.show(TargetPopup(g, options) { id -> load(id) }) }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun layout() { cont.set(g.W / 2 - 120f, g.H - 260f, 460f, 150f); change.set(g.W - 330f, 470f, 300f, 96f); change.textSize = 34f }
    override fun enter() { cont.visible = false; g.audio.play("alarm", 0.5f); load(null) }

    private fun load(id: Long?) {
        state = 0
        g.net.call("POST", "/api/attack/start", if (id != null) mapOf("targetId" to id) else emptyMap()) { r ->
            if (!r.ok) { g.error(r); g.goto(g.slot); return@call }
            target = Target(r.j["result"]["target"])
            options = r.j["result"]["options"].list.map { Target(it) }
            state = 1
            if (!Tips.show(g, "attack") && target?.revenge == true) g.banner("VINGANÇA!", "${target?.name} te atacou antes", 0xFFFF5252.toInt())
        }
    }

    override fun update(dt: Float) {
        val th = target?.theme ?: Themes.all[0]
        amb.update(dt, th, g.W, g.H)
        for (i in 0 until 5) shakeB[i] = (shakeB[i] - dt).coerceAtLeast(0f)
        change.visible = state == 1 && options.size > 1
        if (state == 2) {
            flyT = (flyT + dt / 0.65f).coerceAtMost(1f)
            if (flyT >= 1f && hit != null) { state = 3; impact(hit!!) }
        } else if (state == 3) {
            resultT += dt
            if (resultT > 1.4f && !cont.visible) { cont.visible = true; cont.pulse = true }
        }
        if (shieldT >= 0f) shieldT += dt
    }

    private fun impact(h: J) {
        val t = target ?: return
        val s = h["slot"].int(slot)
        val bx = Layout.x(if (s >= 0) s else slot); val by = Layout.y(if (s >= 0) s else slot, g.H); val sc = Layout.s(if (s >= 0) s else slot)
        val hy = by - Scenery.height(slot, t.levels[slot]) * sc * 0.5f
        reward = h["reward"].long()
        val blocked = h["blocked"].strOrNull()
        if (blocked != null) {
            shieldT = 0f
            g.audio.play("shield"); g.shake(8f); g.audio.vibrate(80, 120)
            g.banner("BLOQUEADO!", if (blocked == "pet") "O Tucano Guardião de ${t.name} defendeu!" else "${t.name} tinha um escudo", 0xFF90CAF9.toInt())
            g.fx.burst(bx, hy, 30, P.SPARK, intArrayOf(0xFF90CAF9.toInt(), 0xFFFFFFFF.toInt()), 1000f, 10f, 0.8f, 600f)
        } else if (s >= 0) {
            t.damaged[s] = true
            shakeB[s] = 0.6f
            g.audio.play("hammer"); g.audio.play("crumble", 0.8f)
            g.shake(30f, 0.6f); g.flash = 0.6f; g.audio.vibrate(220, 255)
            g.fx.burst(bx, hy, 40, P.DEBRIS, intArrayOf(darken(t.theme.wall, 0.2f), t.theme.roof, 0xFF8D6E63.toInt()), 1300f, 22f, 1.3f, 1800f)
            g.fx.burst(bx, hy, 30, P.SPARK, intArrayOf(0xFFFFD180.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF6D00.toInt()), 1100f, 12f, 0.6f, 300f)
            g.fx.dust(bx, by - 40f, 22, 0xFFBCAAA4.toInt(), 160f)
            val pb = h["petBonus"].long()
            g.banner("DESTRUÍDO!", "+" + Fmt.n(reward) + " moedas" + (if (pb > 0) " (Onça +" + Fmt.n(pb) + ")" else ""), 0xFFFF8A65.toInt())
        }
        g.coinsFly(reward, bx, hy)
        g.audio.play("coins_big", 0.7f)
    }

    override fun draw(c: Canvas) {
        val t = target
        val th = t?.theme ?: Themes.all[0]
        Scenery.background(c, th, g.W, g.H, g.scale)
        if (t != null) for (i in Layout.drawOrder) {
            val sx = if (shakeB[i] > 0f) sin(shakeB[i] * 70f) * 18f else 0f
            Scenery.building(c, th, i, t.levels[i], t.damaged[i], Layout.x(i) + sx, Layout.y(i, g.H), Layout.s(i), g.time + i)
            if (state == 1 && t.levels[i] > 0 && !t.damaged[i]) {
                val a = 0.5f + 0.5f * sin(g.time * 6f + i)
                drawTarget(c, Layout.x(i), Layout.y(i, g.H) - Scenery.height(i, t.levels[i]) * Layout.s(i) - 50f + sin(g.time * 4f + i) * 10f, a)
            }
        }
        amb.draw(c, th, g.W, g.H, g.time)
        if (shieldT >= 0f) {
            val k = Ease.outBack(clamp01(shieldT / 0.4f)); val a = clamp01(2.2f - shieldT)
            val cx = g.W / 2; val cy = g.H * 0.62f
            p.color = -1; p.shader = android.graphics.RadialGradient(cx, cy, 700f * k + 1f, withAlpha(0xFF42A5F5.toInt(), (40 * a).toInt()), withAlpha(0xFF90CAF9.toInt(), (170 * a).toInt()), android.graphics.Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, 700f * k, p); p.shader = null
            p.style = Paint.Style.STROKE; p.strokeWidth = 10f; p.color = withAlpha(0xFFE3F2FD.toInt(), (255 * a).toInt())
            c.drawCircle(cx, cy, 700f * k, p); p.style = Paint.Style.FILL
        }
        val cx = if (state == 3) 190f else g.W / 2; val cy = g.H - 60f
        val swing = if (state == 1) sin(g.time * 3f) * 15f else if (state == 2) -60f else 20f
        val pr = g.prof
        if (pr != null && pr.activePet == "onca" && pr.petAwake()) Chars.onca(c, cx + 230f, cy, 0.6f, g.time, true)
        Art.capi(c, cx, cy, 0.9f, g.time, if (state == 3) (if (hit?.get("blocked")?.isNull == false) Art.Mood.SAD else Art.Mood.HAPPY) else Art.Mood.WOW, if (state <= 1) 1 else 0, 0, swing = swing)
        if (state == 2 && t != null) {
            val k = Ease.inOutQuad(flyT)
            val tx = Layout.x(slot); val ty = Layout.y(slot, g.H) - Scenery.height(slot, t.levels[slot]) * Layout.s(slot) * 0.5f
            val x0 = cx + 60f; val y0 = cy - 400f
            val x = lerp(x0, tx, k); val y = lerp(y0, ty, k) - sin(k * Math.PI.toFloat()) * 380f
            c.save(); c.translate(x, y); c.rotate(k * 900f); Art.goldHammer(c, 1.2f - k * 0.4f); c.restore()
        }
        // header
        Ui.panel(c, 30f, 230f, g.W - 30f, 450f, 0xFFC62828.toInt(), 40f)
        if (t == null) { UiX.spinner(c, g.W / 2, 340f, 40f, g.time); Ui.text(c, "Procurando alvo...", g.W / 2, 410f, 34f) }
        else {
            Art.avatar(c, 120f, 340f, 62f, t.avatar)
            Ui.text(c, t.name, 210f, 300f, 54f, align = Paint.Align.LEFT, gold = true, maxW = 780f)
            Ui.pill(c, 210f, 340f, 210f + Ui.measure(t.tag, 30f) + 40f, 386f, t.tagColor)
            Ui.text(c, t.tag, 230f, 363f, 30f, align = Paint.Align.LEFT, ow = 4f)
            Ui.text(c, when (state) { 1 -> "Toque em um prédio para destruir!"; 2 -> "Lá vai..."; else -> "Recompensa: " + Fmt.n(reward) }, 210f, 418f, 36f, align = Paint.Align.LEFT, maxW = g.W - 260f)
        }
        change.draw(c, g.time)
        cont.draw(c, g.time)
        g.drawHud(c)
    }

    private fun drawTarget(c: Canvas, x: Float, y: Float, a: Float) {
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 10f
        p.color = withAlpha(0xFFFF1744.toInt(), (150 + 105 * a).toInt())
        c.drawCircle(x, y, 40f, p); c.drawCircle(x, y, 16f, p)
        c.drawLine(x - 60f, y, x - 28f, y, p); c.drawLine(x + 28f, y, x + 60f, y, p)
        c.drawLine(x, y - 60f, x, y - 28f, p); c.drawLine(x, y + 28f, x, y + 60f, p)
        p.style = Paint.Style.FILL
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (cont.touch(type, x, y, g)) return
        if (change.touch(type, x, y, g)) return
        val t = target ?: return
        if (state != 1 || type != Game.UP) return
        for (i in Layout.drawOrder.reversed()) {
            if (t.levels[i] <= 0) continue
            val bx = Layout.x(i); val by = Layout.y(i, g.H); val s = Layout.s(i)
            val hgt = Scenery.height(i, t.levels[i]) * s
            if (x in bx - 160f * s..bx + 160f * s && y in by - hgt - 100f..by + 30f) {
                slot = i; state = 2; flyT = 0f; hit = null
                g.audio.play("whoosh"); g.audio.vibrate(30, 100)
                g.net.call("POST", "/api/attack/hit", mapOf("targetId" to t.id, "slot" to i)) { r ->
                    if (r.ok) hit = r.j["result"] else { g.error(r); state = 1 }
                }
                return
            }
        }
    }

    override fun back(): Boolean = true
}

/** Dig spots on a rival island (values come from the server). */
class RaidScene(g: Game) : Scene(g) {
    private val amb = Scenery.Ambience(g)
    private var target: Target? = null
    private val values = LongArray(9)
    private val kinds = IntArray(9)
    private val dug = BooleanArray(9)
    private val revealT = FloatArray(9) { -1f }
    private var digging = -1
    private var digT = 0f
    private var digRes: J? = null
    private var digsLeft = 3
    private var total = 0L
    private var endT = -1f
    private var loading = true
    private val cont = Button(0f, 0f, 0f, 0f, "CONTINUAR", 0xFF43A047.toInt()) { g.goto(g.slot) }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun spotX(i: Int) = 230f + (i % 3) * 310f
    private fun spotY(i: Int) = g.H * (0.47f + (i / 3) * 0.135f)

    override fun layout() { cont.set(g.W / 2 - 120f, g.H - 230f, 460f, 150f) }
    override fun enter() {
        cont.visible = false
        g.net.call("POST", "/api/raid/start") { r ->
            if (!r.ok) { g.error(r); g.goto(g.slot); return@call }
            val res = r.j["result"]
            target = Target(res["target"])
            for (d in res["dug"].list) { val s = d["spot"].int(); dug[s] = true; values[s] = d["value"].long(); kinds[s] = d["kind"].int(); revealT[s] = 1f }
            digsLeft = res["digs"].int(3) - res["dug"].size
            loading = false
            if (!Tips.show(g, "raid") && res["digs"].int(3) > 3) g.banner("+1 BURACO!", "Seu Quati farejou mais um!", 0xFFFFCC80.toInt())
        }
    }

    override fun update(dt: Float) {
        amb.update(dt, target?.theme ?: Themes.all[1], g.W, g.H)
        for (i in 0 until 9) if (revealT[i] >= 0f) revealT[i] += dt
        if (digging >= 0) {
            val prev = digT
            digT += dt
            for (m in floatArrayOf(0.1f, 0.3f, 0.5f)) if (prev < m && digT >= m) g.fx.burst(spotX(digging), spotY(digging), 10, P.DEBRIS, intArrayOf(0xFF795548.toInt(), 0xFF5D4037.toInt(), 0xFFA1887F.toInt()), 700f, 14f, 0.8f, 1800f)
            val res = digRes
            if (digT >= 0.6f && res != null) {
                val i = digging; digging = -1
                dug[i] = true; revealT[i] = 0f
                values[i] = res["value"].long(); kinds[i] = res["kind"].int()
                total += values[i]
                g.coinsFly(values[i], spotX(i), spotY(i) - 60f)
                g.fx.text("+" + Fmt.n(values[i]), spotX(i), spotY(i) - 140f, 0xFFFFEB3B.toInt(), 64f)
                if (kinds[i] == 3) { g.audio.play("jackpot", 0.8f); g.fx.confetti(70); g.banner("TESOURO REAL!", "+" + Fmt.n(values[i]), 0xFFFFD54F.toInt()); g.audio.vibrate(160, 220) }
                else { g.audio.play(if (kinds[i] >= 2) "win" else "coin"); g.audio.vibrate(50, 120) }
                digsLeft = res["left"].int(digsLeft - 1)
                if (res["done"].bool()) {
                    endT = 0f
                    for (a in res["all"].list) { val s = a["spot"].int(); if (!dug[s]) { values[s] = a["value"].long(); kinds[s] = a["kind"].int() } }
                }
            }
        }
        if (endT >= 0f) {
            endT += dt
            if (endT > 1.0f) for (i in 0 until 9) if (!dug[i] && revealT[i] < 0f) revealT[i] = 0f
            if (endT > 1.6f && !cont.visible) { cont.visible = true; cont.pulse = true }
        }
    }

    override fun draw(c: Canvas) {
        val th = target?.theme ?: Themes.all[1]
        Scenery.background(c, th, g.W, g.H, g.scale)
        amb.draw(c, th, g.W, g.H, g.time)
        for (i in 0 until 9) {
            val x = spotX(i); val y = spotY(i)
            if (dug[i] || revealT[i] >= 0f) {
                p.shader = null; p.color = 0xFF3E2723.toInt(); c.drawOval(x - 120f, y - 34f, x + 120f, y + 38f, p)
                p.color = 0xFF8D6E63.toInt(); c.drawOval(x - 130f, y + 10f, x - 64f, y + 44f, p); c.drawOval(x + 64f, y + 8f, x + 135f, y + 44f, p)
                val rt = revealT[i]
                if (rt >= 0f) {
                    val k = Ease.outBack(clamp01(rt / 0.45f))
                    val alpha = if (dug[i]) 255 else 140
                    val yy = y - 50f * k
                    c.save(); c.scale(k, k, x, y)
                    if (dug[i] && kinds[i] == 3) Art.rays(c, x, yy, 200f, g.time * 2f, 0xFFFFF59D.toInt(), 12, 0.8f)
                    when (kinds[i]) {
                        3 -> Art.chest(c, x, yy, 0.6f, clamp01(rt * 2f), 1)
                        2 -> Art.symbol(c, Sym.BAG, x, yy - 10f, 150f, alpha)
                        1 -> { Art.coin(c, x - 30f, yy, 30f); Art.coin(c, x + 30f, yy + 4f, 30f); Art.coin(c, x, yy - 30f, 32f) }
                        else -> Art.coin(c, x, yy, 30f)
                    }
                    c.restore()
                    Ui.text(c, Fmt.n(values[i]), x, y + 66f, 40f, if (dug[i]) 0xFFFFEB3B.toInt() else 0xBBFFFFFF.toInt(), alpha = if (dug[i]) 1f else 0.75f)
                }
            } else {
                val wob = if (digging == i) sin(digT * 40f) * 6f else 0f
                val ms = c.save(); c.scale(1.25f, 1.25f, x, y)
                p.shader = null; p.color = 0x55000000; c.drawOval(x - 115f, y - 10f, x + 115f, y + 40f, p)
                p.color = 0xFF8D6E63.toInt(); c.drawOval(x - 105f + wob, y - 52f, x + 105f + wob, y + 30f, p)
                p.color = 0xFFA1887F.toInt(); c.drawOval(x - 80f + wob, y - 50f, x + 60f + wob, y - 6f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 16f; p.color = 0xFFD32F2F.toInt()
                val a = if (digsLeft > 0 && !loading) 0.8f + 0.2f * sin(g.time * 5f + i) else 0.4f
                p.alpha = (255 * a).toInt()
                c.drawLine(x - 28f, y - 36f, x + 28f, y + 4f, p); c.drawLine(x + 28f, y - 36f, x - 28f, y + 4f, p)
                p.style = Paint.Style.FILL; p.alpha = 255
                c.restoreToCount(ms)
                if (digging == i) { c.save(); c.translate(x + 60f, y - 90f); c.rotate(-30f + sin(digT * 30f) * 25f); Art.shovel(c, 0.9f); c.restore() }
            }
        }
        val pr = g.prof
        if (pr != null && pr.activePet == "quati" && pr.petAwake()) Chars.quati(c, 360f, g.H - 40f, 0.55f, g.time, true)
        Art.capi(c, 140f, g.H - 40f, 0.55f, g.time, if (endT >= 0f) Art.Mood.HAPPY else Art.Mood.IDLE, 2, 0, swing = sin(g.time * 4f) * 15f)
        Ui.panel(c, 30f, 230f, g.W - 30f, 420f, 0xFFF9A825.toInt(), 40f)
        val t = target
        if (t == null) { UiX.spinner(c, g.W / 2, 320f, 40f, g.time) }
        else {
            Art.avatar(c, 120f, 325f, 60f, t.avatar)
            Ui.text(c, "SAQUE: ${t.name}", 210f, 290f, 50f, align = Paint.Align.LEFT, maxW = g.W - 270f)
            Ui.text(c, if (digsLeft > 0) "Escolha onde cavar · restam $digsLeft" else "Total saqueado: " + Fmt.n(total), 210f, 360f, 38f, align = Paint.Align.LEFT, maxW = g.W - 270f)
        }
        cont.draw(c, g.time)
        g.drawHud(c)
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (cont.touch(type, x, y, g)) return
        if (type != Game.UP || digging >= 0 || digsLeft <= 0 || loading) return
        for (i in 0 until 9) {
            if (dug[i]) continue
            val dx = x - spotX(i); val dy = y - spotY(i)
            if (dx * dx / (150f * 150f) + dy * dy / (100f * 100f) <= 1f) {
                digging = i; digT = 0f; digRes = null
                g.audio.play("dig"); g.audio.vibrate(30, 90)
                g.net.call("POST", "/api/raid/dig", mapOf("spot" to i)) { r ->
                    if (r.ok) digRes = r.j["result"] else { g.error(r); digging = -1 }
                }
                return
            }
        }
    }

    override fun back(): Boolean = true
}
