package com.oateam.capicoin

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Village backgrounds (cached) + ambient life + buildings. */
object Scenery {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val o = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND }
    private val path = Path()
    private val path2 = Path()
    private val r = RectF()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val INK = Art.INK

    private class Cached(val kind: Int, val w: Float, val h: Float, val bmp: Bitmap)
    private val cache = ArrayList<Cached>()

    fun horizon(h: Float) = h * 0.33f

    // ===================================================================== background
    fun background(c: Canvas, th: Theme, w: Float, h: Float, scale: Float) {
        var hit: Cached? = null
        for (k in cache) if (k.kind == th.kind && k.w == w && k.h == h) hit = k
        if (hit == null) {
            val bw = (w * scale).toInt().coerceAtLeast(1); val bh = (h * scale).toInt().coerceAtLeast(1)
            val bmp = try { Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888) } catch (e: OutOfMemoryError) { null }
            if (bmp == null) { paintBackground(c, th, w, h); return }
            val cc = Canvas(bmp); cc.scale(scale, scale)
            paintBackground(cc, th, w, h)
            if (cache.size >= 2) { cache.removeAt(0).bmp.recycle() }
            hit = Cached(th.kind, w, h, bmp); cache.add(hit)
        }
        r.set(0f, 0f, w, h)
        c.drawBitmap(hit.bmp, null, r, bmpPaint)
    }

    private fun paintBackground(c: Canvas, th: Theme, w: Float, h: Float) {
        val hz = horizon(h)
        val rnd = java.util.Random(1000L + th.kind * 77L)
        val night = th.kind == Themes.VOLCANO || th.kind == Themes.NEON
        // sky
        p.color = -1; p.shader = LinearGradient(0f, 0f, 0f, hz + 60f, th.sky1, th.sky2, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, hz + 80f, p); p.shader = null
        if (night) {
            for (i in 0 until 90) {
                p.color = withAlpha(0xFFFFFFFF.toInt(), 80 + rnd.nextInt(170))
                c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * hz * 0.9f, 1.5f + rnd.nextFloat() * 3f, p)
            }
            Art.glow(c, w * 0.78f, hz * 0.3f, 200f, 0xFFFFF8E1.toInt(), 0.7f)
            p.color = 0xFFFFF8E1.toInt(); c.drawCircle(w * 0.78f, hz * 0.3f, 70f, p)
            p.color = 0x22000000; c.drawCircle(w * 0.75f, hz * 0.27f, 16f, p); c.drawCircle(w * 0.81f, hz * 0.34f, 11f, p)
        } else {
            Art.glow(c, w * 0.8f, hz * 0.28f, 330f, 0xFFFFF59D.toInt(), 0.9f)
            p.color = 0xFFFFF9C4.toInt(); c.drawCircle(w * 0.8f, hz * 0.28f, 86f, p)
        }
        // far layer
        when (th.kind) {
            Themes.SNOW -> {
                mountains(c, w, hz + 40f, 360f, 0xFF90A4AE.toInt(), rnd, true, 5)
                mountains(c, w, hz + 70f, 240f, 0xFFB0BEC5.toInt(), rnd, true, 7)
            }
            Themes.VOLCANO -> {
                // big volcano
                Art.glow(c, w * 0.5f, hz - 300f, 420f, 0xFFFF3D00.toInt(), 0.8f)
                path.reset(); path.moveTo(w * 0.02f, hz + 80f); path.quadTo(w * 0.3f, hz - 120f, w * 0.41f, hz - 290f); path.lineTo(w * 0.59f, hz - 290f)
                path.quadTo(w * 0.7f, hz - 120f, w * 0.98f, hz + 80f); path.close()
                p.color = -1; p.shader = LinearGradient(0f, hz - 290f, 0f, hz + 80f, 0xFF795548.toInt(), 0xFF2B1A14.toInt(), Shader.TileMode.CLAMP)
                c.drawPath(path, p); p.shader = null
                o.shader = null; o.pathEffect = null; o.strokeWidth = 6f; o.color = 0xFF1B0F0B.toInt(); c.drawPath(path, o)
                p.color = 0xFF3E1F14.toInt(); c.drawOval(w * 0.41f, hz - 306f, w * 0.59f, hz - 274f, p)
                p.color = 0xFFFF9100.toInt(); c.drawOval(w * 0.43f, hz - 300f, w * 0.57f, hz - 280f, p)
                o.strokeWidth = 16f; o.color = 0xFFFF6D00.toInt()
                path.reset(); path.moveTo(w * 0.46f, hz - 288f); path.cubicTo(w * 0.44f, hz - 200f, w * 0.40f, hz - 160f, w * 0.36f, hz - 40f); c.drawPath(path, o)
                path.reset(); path.moveTo(w * 0.55f, hz - 288f); path.cubicTo(w * 0.57f, hz - 190f, w * 0.63f, hz - 120f, w * 0.68f, hz + 10f); c.drawPath(path, o)
                o.strokeWidth = 6f; o.color = 0xFFFFD180.toInt()
                path.reset(); path.moveTo(w * 0.46f, hz - 288f); path.cubicTo(w * 0.44f, hz - 200f, w * 0.40f, hz - 160f, w * 0.36f, hz - 40f); c.drawPath(path, o)
                path.reset(); path.moveTo(w * 0.55f, hz - 288f); path.cubicTo(w * 0.57f, hz - 190f, w * 0.63f, hz - 120f, w * 0.68f, hz + 10f); c.drawPath(path, o)
                mountains(c, w, hz + 70f, 160f, 0xFF2B1A14.toInt(), rnd, false, 6)
            }
            Themes.NEON -> {
                var x = -20f
                while (x < w) {
                    val bw = 60f + rnd.nextFloat() * 110f; val bh = 120f + rnd.nextFloat() * 330f
                    p.color = mixColor(0xFF1B1035.toInt(), 0xFF2E1A5C.toInt(), rnd.nextFloat())
                    c.drawRect(x, hz + 60f - bh, x + bw, hz + 80f, p)
                    var wy = hz + 60f - bh + 18f
                    while (wy < hz + 50f) {
                        var wx = x + 10f
                        while (wx < x + bw - 16f) {
                            if (rnd.nextFloat() < 0.45f) {
                                p.color = if (rnd.nextBoolean()) 0xCC00F5D4.toInt() else 0xCCF72585.toInt()
                                c.drawRect(wx, wy, wx + 10f, wy + 14f, p)
                            }
                            wx += 22f
                        }
                        wy += 28f
                    }
                    x += bw + 6f
                }
            }
            Themes.DESERT -> {
                for (i in 0 until 3) {
                    val px = w * (0.15f + i * 0.32f); val ps = 120f + rnd.nextFloat() * 80f
                    path.reset(); path.moveTo(px - ps, hz + 60f); path.lineTo(px, hz + 60f - ps * 1.1f); path.lineTo(px + ps, hz + 60f); path.close()
                    p.color = 0xFFD9A15E.toInt(); c.drawPath(path, p)
                    path.reset(); path.moveTo(px, hz + 60f - ps * 1.1f); path.lineTo(px + ps, hz + 60f); path.lineTo(px + ps * 0.2f, hz + 60f); path.close()
                    p.color = 0xFFB97E3D.toInt(); c.drawPath(path, p)
                }
                dunes(c, w, hz + 60f, 0xFFE8B36A.toInt(), 50f)
            }
            Themes.CANDY -> {
                hills(c, w, hz + 50f, 140f, 0xFFCE93D8.toInt(), 3, 0f)
                hills(c, w, hz + 80f, 100f, 0xFFF8BBD0.toInt(), 4, 1.3f)
            }
            Themes.BEACH, Themes.PIRATE -> {
                mountains(c, w, hz + 20f, 120f, 0xFF4DB6AC.toInt(), rnd, false, 4)
            }
            else -> {
                mountains(c, w, hz + 40f, 280f, 0xFF5C9E8F.toInt(), rnd, false, 5)
                mountains(c, w, hz + 60f, 170f, 0xFF3F7F5A.toInt(), rnd, false, 7)
            }
        }
        // sea for beach/pirate
        if (th.kind == Themes.BEACH || th.kind == Themes.PIRATE) {
            val seaB = hz + 210f
            p.color = -1; p.shader = LinearGradient(0f, hz + 20f, 0f, seaB, 0xFF4FC3F7.toInt(), 0xFF0277BD.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, hz + 20f, w, seaB + 40f, p); p.shader = null
            p.color = 0x66FFFFFF
            for (i in 0 until 26) {
                val sx = rnd.nextFloat() * w; val sy = hz + 40f + rnd.nextFloat() * 150f
                c.drawRoundRect(sx, sy, sx + 30f + rnd.nextFloat() * 40f, sy + 5f, 3f, 3f, p)
            }
            if (th.kind == Themes.PIRATE) ship(c, w * 0.25f, hz + 110f, 0.8f)
            else { // sailboat
                path.reset(); path.moveTo(w * 0.3f, hz + 90f); path.lineTo(w * 0.3f, hz + 10f); path.lineTo(w * 0.35f, hz + 85f); path.close()
                p.color = 0xFFFFFFFF.toInt(); c.drawPath(path, p)
                p.color = 0xFFE53935.toInt(); c.drawRoundRect(w * 0.27f, hz + 90f, w * 0.37f, hz + 104f, 8f, 8f, p)
            }
        }
        // ground
        val gTop = if (th.kind == Themes.BEACH || th.kind == Themes.PIRATE) hz + 200f else hz + 70f
        path.reset(); path.moveTo(0f, gTop + 30f)
        var gx = 0f
        while (gx <= w) { path.lineTo(gx, gTop + sin(gx * 0.012f + th.kind) * 18f); gx += 30f }
        path.lineTo(w, h); path.lineTo(0f, h); path.close()
        p.color = -1; p.shader = LinearGradient(0f, gTop, 0f, h, th.ground1, th.ground2, Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        if (th.kind == Themes.BEACH || th.kind == Themes.PIRATE) {
            o.strokeWidth = 14f; o.color = 0xAAFFFFFF.toInt(); o.shader = null
            c.drawPath(wavyLine(w, gTop - 4f), o)
        }
        if (th.kind == Themes.NEON) {
            o.strokeWidth = 4f; o.color = 0x99F72585.toInt()
            val vx = w / 2; val vy = gTop - 40f
            for (i in -12..12) c.drawLine(vx + i * 30f, vy, vx + i * 260f, h, o)
            var yy = gTop; var step = 20f
            while (yy < h) { c.drawLine(0f, yy, w, yy, o); yy += step; step *= 1.18f }
        }
        // ground texture spots
        for (i in 0 until 70) {
            val sx = rnd.nextFloat() * w; val sy = gTop + 40f + rnd.nextFloat() * (h - gTop - 40f)
            val sz = 6f + rnd.nextFloat() * 14f
            p.color = when (th.kind) {
                Themes.CANDY -> intArrayOf(0xFFFF5252.toInt(), 0xFF40C4FF.toInt(), 0xFFFFEB3B.toInt(), 0xFFFFFFFF.toInt())[rnd.nextInt(4)]
                Themes.NEON -> 0x5500F5D4
                Themes.VOLCANO -> 0x55FF6D00
                else -> withAlpha(darken(th.ground2, 0.15f), 90)
            }
            if (th.kind == Themes.CANDY) c.drawRoundRect(sx, sy, sx + sz * 1.8f, sy + sz * 0.6f, 4f, 4f, p)
            else c.drawOval(sx, sy, sx + sz * 2f, sy + sz, p)
        }
        // path (dirt road)
        if (th.kind != Themes.NEON) {
            path.reset()
            path.moveTo(w * 0.42f, h); path.cubicTo(w * 0.35f, h * 0.8f, w * 0.68f, h * 0.66f, w * 0.52f, h * 0.48f)
            path.lineTo(w * 0.58f, h * 0.48f); path.cubicTo(w * 0.8f, h * 0.66f, w * 0.5f, h * 0.8f, w * 0.62f, h); path.close()
            p.color = when (th.kind) {
                Themes.SNOW -> 0x55B0BEC5; Themes.VOLCANO -> 0x30FF8A65; Themes.CANDY -> 0x88FFFFFF.toInt()
                else -> withAlpha(lighten(th.ground1, 0.35f), 150)
            }
            c.drawPath(path, p)
        }
        // lava pools
        if (th.kind == Themes.VOLCANO) {
            for (i in 0 until 4) {
                val lx = rnd.nextFloat() * w; val ly = gTop + 200f + rnd.nextFloat() * (h - gTop - 300f)
                p.color = -1; p.shader = RadialGradient(lx, ly, 120f, 0xFFFFD180.toInt(), 0xFFDD2C00.toInt(), Shader.TileMode.CLAMP)
                c.drawOval(lx - 110f, ly - 30f, lx + 110f, ly + 30f, p); p.shader = null
                o.strokeWidth = 6f; o.color = 0xFF1B0F0B.toInt(); c.drawOval(lx - 110f, ly - 30f, lx + 110f, ly + 30f, o)
            }
        }
        // side decorations
        decorations(c, th, w, h, gTop, rnd)
        // vignette
        p.color = -1; p.shader = RadialGradient(w / 2, h * 0.5f, h * 0.75f, 0x00000000, 0x66000000, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null
    }

    private fun wavyLine(w: Float, y: Float): Path {
        val pp = Path(); pp.moveTo(0f, y)
        var x = 0f
        while (x <= w) { pp.lineTo(x, y + sin(x * 0.03f) * 6f); x += 12f }
        return pp
    }

    private fun mountains(c: Canvas, w: Float, base: Float, hgt: Float, col: Int, rnd: java.util.Random, snowCap: Boolean, n: Int) {
        val step = w / (n - 1)
        for (i in 0 until n) {
            val mx = i * step + (rnd.nextFloat() - 0.5f) * step * 0.4f
            val mh = hgt * (0.6f + rnd.nextFloat() * 0.5f)
            val mw = step * (0.8f + rnd.nextFloat() * 0.4f)
            path.reset(); path.moveTo(mx - mw, base); path.lineTo(mx, base - mh); path.lineTo(mx + mw, base); path.close()
            p.color = -1; p.shader = LinearGradient(0f, base - mh, 0f, base, lighten(col, 0.1f), darken(col, 0.15f), Shader.TileMode.CLAMP)
            c.drawPath(path, p); p.shader = null
            path.reset(); path.moveTo(mx, base - mh); path.lineTo(mx + mw, base); path.lineTo(mx + mw * 0.15f, base); path.close()
            p.color = 0x22000000; c.drawPath(path, p)
            if (snowCap) {
                val k = 0.32f
                path.reset(); path.moveTo(mx, base - mh); path.lineTo(mx + mw * k, base - mh * (1 - k))
                path.lineTo(mx + mw * k * 0.4f, base - mh * (1 - k) + 18f); path.lineTo(mx, base - mh * (1 - k) - 6f)
                path.lineTo(mx - mw * k * 0.4f, base - mh * (1 - k) + 16f); path.lineTo(mx - mw * k, base - mh * (1 - k)); path.close()
                p.color = 0xFFFFFFFF.toInt(); c.drawPath(path, p)
            }
        }
    }

    private fun hills(c: Canvas, w: Float, base: Float, hgt: Float, col: Int, n: Int, ph: Float) {
        path.reset(); path.moveTo(0f, base + 60f)
        var x = 0f
        while (x <= w) { path.lineTo(x, base - (0.5f + 0.5f * sin(x / w * n * PI.toFloat() + ph)) * hgt); x += 20f }
        path.lineTo(w, base + 60f); path.close()
        p.color = col; c.drawPath(path, p)
    }

    private fun dunes(c: Canvas, w: Float, base: Float, col: Int, hgt: Float) {
        path.reset(); path.moveTo(0f, base + 40f)
        var x = 0f
        while (x <= w) { path.lineTo(x, base - (0.5f + 0.5f * sin(x * 0.006f)) * hgt); x += 20f }
        path.lineTo(w, base + 40f); path.close()
        p.color = col; c.drawPath(path, p)
    }

    private fun ship(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s)
        path.reset(); path.moveTo(-120f, 0f); path.lineTo(120f, 0f); path.lineTo(90f, 45f); path.lineTo(-95f, 45f); path.close()
        p.color = 0xFF5D4037.toInt(); c.drawPath(path, p)
        o.strokeWidth = 5f; o.color = INK; c.drawPath(path, o)
        p.color = 0xFF3E2723.toInt(); c.drawRect(-6f, -170f, 6f, 0f, p)
        for (k in 0..1) {
            val sy = -160f + k * 80f
            path.reset(); path.moveTo(-70f + k * 10, sy); path.quadTo(0f, sy + 20f, 70f - k * 10, sy); path.lineTo(64f - k * 10, sy + 66f); path.quadTo(0f, sy + 80f, -64f + k * 10, sy + 66f); path.close()
            p.color = 0xFFF5F0E1.toInt(); c.drawPath(path, p); c.drawPath(path, o)
        }
        p.color = 0xFF212121.toInt(); c.drawRect(6f, -170f, 50f, -146f, p)
        c.restore()
    }

    private fun decorations(c: Canvas, th: Theme, w: Float, h: Float, gTop: Float, rnd: java.util.Random) {
        val spots = floatArrayOf(-30f, h * 0.42f, 1.15f, w + 20f, h * 0.44f, 1.05f, 40f, h * 0.86f, 1.35f, w - 40f, h * 0.9f, 1.4f, w * 0.2f, gTop + 60f, 0.6f, w * 0.86f, gTop + 70f, 0.6f)
        var i = 0
        while (i < spots.size) {
            val x = spots[i]; val y = spots[i + 1]; val s = spots[i + 2]
            when (th.kind) {
                Themes.JUNGLE, Themes.BEACH, Themes.PIRATE -> palm(c, x, y, s, rnd)
                Themes.DESERT -> cactus(c, x, y, s * 0.8f)
                Themes.SNOW -> pine(c, x, y, s)
                Themes.VOLCANO -> rock(c, x, y, s)
                Themes.CANDY -> lollipop(c, x, y, s * 0.72f, rnd)
                Themes.NEON -> lamp(c, x, y, s)
            }
            i += 3
        }
        // bushes
        if (th.kind == Themes.JUNGLE || th.kind == Themes.CANDY) {
            for (k in 0 until 6) {
                val bx = rnd.nextFloat() * w; val by = gTop + 120f + rnd.nextFloat() * (h - gTop - 200f)
                if (bx > w * 0.3f && bx < w * 0.7f) continue
                bush(c, bx, by, 0.6f + rnd.nextFloat() * 0.5f, if (th.kind == Themes.CANDY) 0xFFF06292.toInt() else 0xFF388E3C.toInt())
            }
        }
        if (th.kind == Themes.SNOW) snowman(c, w * 0.1f, h * 0.7f, 0.9f)
        if (th.kind == Themes.PIRATE) Art.chest(c, w * 0.88f, h * 0.75f, 0.5f, 0f, 0)
    }

    private fun palm(c: Canvas, x: Float, y: Float, s: Float, rnd: java.util.Random) {
        c.save(); c.translate(x, y); c.scale(s, s)
        path.reset(); path.moveTo(-18f, 0f); path.quadTo(-10f, -180f, 30f, -330f); path.lineTo(48f, -326f); path.quadTo(14f, -180f, 18f, 0f); path.close()
        p.color = -1; p.shader = LinearGradient(-18f, 0f, 18f, 0f, 0xFFA1887F.toInt(), 0xFF6D4C41.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        o.strokeWidth = 6f; o.color = INK; c.drawPath(path, o)
        o.strokeWidth = 4f; o.color = 0x664E342E
        for (k in 0 until 9) { val yy = -30f - k * 33f; c.drawLine(-14f + k * 4f, yy, 16f + k * 4f, yy - 4f, o) }
        val tx = 40f; val ty = -330f
        for (k in 0 until 7) {
            val a = (-PI.toFloat() * 0.95f) + k * (PI.toFloat() * 1.1f / 6f)
            val ex = tx + cos(a) * 190f; val ey = ty + sin(a) * 120f + 40f
            path.reset(); path.moveTo(tx, ty)
            path.quadTo((tx + ex) / 2 + sin(a) * 40f, (ty + ey) / 2 - 70f, ex, ey)
            path.quadTo((tx + ex) / 2, (ty + ey) / 2 - 20f, tx, ty + 10f); path.close()
            p.color = if (k % 2 == 0) 0xFF43A047.toInt() else 0xFF2E7D32.toInt()
            c.drawPath(path, p); o.strokeWidth = 5f; o.color = 0xFF1B5E20.toInt(); c.drawPath(path, o)
        }
        p.color = 0xFF6D4C41.toInt()
        c.drawCircle(tx - 14f, ty + 18f, 16f, p); c.drawCircle(tx + 12f, ty + 22f, 16f, p)
        c.restore()
    }

    private fun cactus(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s)
        p.color = 0xFF43A047.toInt(); o.strokeWidth = 7f; o.color = INK
        r.set(-34f, -260f, 34f, 0f); c.drawRoundRect(r, 34f, 34f, p); c.drawRoundRect(r, 34f, 34f, o)
        path.reset(); path.moveTo(-30f, -110f); path.lineTo(-80f, -110f); path.lineTo(-80f, -190f)
        o.strokeWidth = 40f; o.color = INK; c.drawPath(path, o); o.strokeWidth = 28f; o.color = 0xFF43A047.toInt(); c.drawPath(path, o)
        path.reset(); path.moveTo(30f, -150f); path.lineTo(76f, -150f); path.lineTo(76f, -220f)
        o.strokeWidth = 40f; o.color = INK; c.drawPath(path, o); o.strokeWidth = 28f; o.color = 0xFF43A047.toInt(); c.drawPath(path, o)
        o.strokeWidth = 4f; o.color = 0xFF2E7D32.toInt(); c.drawLine(0f, -240f, 0f, -10f, o)
        p.color = 0xFFFF4081.toInt(); c.drawCircle(0f, -262f, 14f, p)
        c.restore()
    }

    private fun pine(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s)
        p.color = 0xFF5D4037.toInt(); c.drawRect(-14f, -40f, 14f, 0f, p)
        for (k in 0 until 3) {
            val by = -30f - k * 70f; val bw = 110f - k * 25f
            path.reset(); path.moveTo(-bw, by); path.lineTo(0f, by - 120f); path.lineTo(bw, by); path.close()
            p.color = 0xFF2E7D32.toInt(); c.drawPath(path, p); o.strokeWidth = 6f; o.color = INK; c.drawPath(path, o)
            path.reset(); path.moveTo(-bw * 0.45f, by - 66f); path.lineTo(0f, by - 120f); path.lineTo(bw * 0.45f, by - 66f)
            path.quadTo(0f, by - 50f, -bw * 0.45f, by - 66f); path.close()
            p.color = 0xFFFFFFFF.toInt(); c.drawPath(path, p)
        }
        c.restore()
    }

    private fun rock(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s)
        path.reset(); path.moveTo(-110f, 0f); path.lineTo(-80f, -110f); path.lineTo(-10f, -160f); path.lineTo(70f, -120f); path.lineTo(110f, 0f); path.close()
        p.color = -1; p.shader = LinearGradient(0f, -160f, 0f, 0f, 0xFF4E342E.toInt(), 0xFF1B0F0B.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null; o.strokeWidth = 6f; o.color = 0xFF0D0705.toInt(); c.drawPath(path, o)
        o.strokeWidth = 5f; o.color = 0xFFFF6D00.toInt()
        c.drawLine(-40f, -90f, -10f, -50f, o); c.drawLine(-10f, -50f, 20f, -70f, o); c.drawLine(20f, -70f, 40f, -20f, o)
        c.restore()
    }

    private fun lollipop(c: Canvas, x: Float, y: Float, s: Float, rnd: java.util.Random) {
        c.save(); c.translate(x, y); c.scale(s, s)
        p.color = 0xFFFFFFFF.toInt(); c.drawRect(-8f, -260f, 8f, 0f, p); o.strokeWidth = 5f; o.color = INK; c.drawRect(-8f, -260f, 8f, 0f, o)
        val col = intArrayOf(0xFFE91E63.toInt(), 0xFF7E57C2.toInt(), 0xFF26C6DA.toInt())[rnd.nextInt(3)]
        p.color = col; c.drawCircle(0f, -300f, 80f, p)
        o.strokeWidth = 14f; o.color = 0xFFFFFFFF.toInt()
        r.set(-55f, -355f, 55f, -245f); c.drawArc(r, 0f, 270f, false, o)
        r.set(-30f, -330f, 30f, -270f); c.drawArc(r, 90f, 270f, false, o)
        o.strokeWidth = 7f; o.color = INK; c.drawCircle(0f, -300f, 80f, o)
        c.restore()
    }

    private fun lamp(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s)
        p.color = 0xFF1A1A2E.toInt(); c.drawRect(-8f, -300f, 8f, 0f, p)
        Art.glow(c, 0f, -310f, 140f, 0xFFF72585.toInt(), 0.9f)
        p.color = 0xFFFFB3DA.toInt(); c.drawCircle(0f, -310f, 24f, p)
        o.strokeWidth = 5f; o.color = 0xFFF72585.toInt(); c.drawLine(-9f, -290f, -9f, 0f, o)
        c.restore()
    }

    private fun bush(c: Canvas, x: Float, y: Float, s: Float, col: Int) {
        c.save(); c.translate(x, y); c.scale(s, s)
        p.color = darken(col, 0.2f); c.drawOval(-90f, -40f, 90f, 10f, p)
        p.color = col
        c.drawCircle(-45f, -40f, 42f, p); c.drawCircle(10f, -60f, 52f, p); c.drawCircle(55f, -35f, 38f, p)
        p.color = 0xFFFFEB3B.toInt(); c.drawCircle(-30f, -60f, 8f, p); c.drawCircle(30f, -80f, 8f, p)
        p.color = 0xFFFF5252.toInt(); c.drawCircle(50f, -50f, 8f, p)
        c.restore()
    }

    private fun snowman(c: Canvas, x: Float, y: Float, s: Float) {
        c.save(); c.translate(x, y); c.scale(s, s)
        o.strokeWidth = 6f; o.color = INK
        p.color = 0xFFFFFFFF.toInt()
        c.drawCircle(0f, -60f, 60f, p); c.drawCircle(0f, -60f, 60f, o)
        c.drawCircle(0f, -160f, 44f, p); c.drawCircle(0f, -160f, 44f, o)
        p.color = INK; c.drawCircle(-14f, -170f, 6f, p); c.drawCircle(14f, -170f, 6f, p)
        p.color = 0xFFFF9800.toInt(); path.reset(); path.moveTo(0f, -160f); path.lineTo(40f, -152f); path.lineTo(0f, -148f); path.close(); c.drawPath(path, p)
        p.color = 0xFFD32F2F.toInt(); c.drawRect(-46f, -128f, 46f, -112f, p)
        c.restore()
    }

    // ===================================================================== ambience
    class Ambience(g: Game) {
        val fx = Fx(g)
        var acc = 0f
        val clouds = FloatArray(10) { kotlin.random.Random.nextFloat() }

        fun update(dt: Float, th: Theme, w: Float, h: Float) {
            acc += dt
            val hz = horizon(h)
            val rate = 0.08f
            while (acc > rate) {
                acc -= rate
                when (th.kind) {
                    Themes.JUNGLE -> if (rnd(0f, 1f) < 0.25f) fx.spawn(P.LEAF, rnd(0f, w), -20f, rnd(-40f, 40f), rnd(60f, 140f), 9f, rnd(10f, 18f), if (rnd(0f, 1f) < 0.5f) 0xFF66BB6A.toInt() else 0xFFFFCA28.toInt(), 0f).drag = 1f
                    Themes.SNOW -> fx.spawn(P.SNOW, rnd(-50f, w), -20f, rnd(-30f, 30f), rnd(80f, 200f), 14f, rnd(4f, 10f), 0xFFFFFFFF.toInt(), 0f).drag = 1f
                    Themes.VOLCANO -> fx.spawn(P.EMBER, rnd(0f, w), h + 10f, rnd(-30f, 30f), rnd(-260f, -120f), rnd(4f, 8f), rnd(4f, 9f), if (rnd(0f, 1f) < 0.5f) 0xFFFF6D00.toInt() else 0xFFFFD180.toInt(), 0f).drag = 1f
                    Themes.CANDY -> if (rnd(0f, 1f) < 0.3f) fx.spawn(P.BUBBLE, rnd(0f, w), h + 20f, rnd(-20f, 20f), rnd(-160f, -80f), 12f, rnd(14f, 30f), intArrayOf(0xFFFF80AB.toInt(), 0xFFB388FF.toInt(), 0xFF80D8FF.toInt())[kotlin.random.Random.nextInt(3)], 0f).drag = 1f
                    Themes.DESERT -> if (rnd(0f, 1f) < 0.3f) fx.spawn(P.DUST, -20f, rnd(hz, h), rnd(200f, 400f), rnd(-20f, 20f), 5f, rnd(4f, 9f), 0xFFFFE0B2.toInt(), 0f).drag = 1f
                    Themes.BEACH, Themes.PIRATE -> if (rnd(0f, 1f) < 0.4f) fx.spawn(P.STAR, rnd(0f, w), rnd(hz + 30f, hz + 190f), 0f, 0f, 0.8f, rnd(6f, 14f), 0xFFFFFFFF.toInt(), 0f)
                    Themes.NEON -> if (rnd(0f, 1f) < 0.3f) fx.spawn(P.SPARK, rnd(0f, w), rnd(0f, hz), 0f, 0f, 1.2f, rnd(2f, 5f), if (rnd(0f, 1f) < 0.5f) 0xFF00F5D4.toInt() else 0xFFF72585.toInt(), 0f)
                }
            }
            fx.update(dt)
        }

        fun draw(c: Canvas, th: Theme, w: Float, h: Float, t: Float) {
            if (th.kind != Themes.NEON) {
                val hz = horizon(h)
                val col = when (th.kind) { Themes.VOLCANO -> 0xFF3E2723.toInt(); Themes.CANDY -> 0xFFFFE4F2.toInt(); else -> 0xFFFFFFFF.toInt() }
                for (i in 0 until 4) {
                    val speed = 14f + clouds[i] * 20f
                    val x = ((clouds[i + 4] * (w + 500f) + t * speed) % (w + 500f)) - 250f
                    val y = 80f + i * hz * 0.18f
                    Art.cloud(c, x, y, 0.6f + clouds[i] * 0.5f, col, if (th.kind == Themes.VOLCANO) 180 else 235)
                }
            }
            fx.draw(c)
        }
    }

    // ===================================================================== buildings
    /** Draws building [slot] at [level] with feet at (x, baseY). */
    fun building(c: Canvas, th: Theme, slot: Int, level: Int, dmg: Boolean, x: Float, baseY: Float, sc: Float, t: Float) {
        c.save(); c.translate(x, baseY); c.scale(sc, sc)
        p.shader = null; p.color = 0x40000000; c.drawOval(-160f, -20f, 160f, 22f, p)
        if (level <= 0) plot(c, t)
        else {
            when (slot) {
                0 -> house(c, th, level, t)
                1 -> tower(c, th, level, t)
                2 -> statue(c, th, level, t)
                3 -> market(c, th, level, t)
                else -> if (th.kind == Themes.DESERT) pyramid(c, th, level, t) else temple(c, th, level, t)
            }
            if (level >= MAX_LEVEL) sparkles(c, t, slot)
            if (dmg) damage(c, t)
        }
        c.restore()
    }

    /** Approximate height of a building (for tap targets / labels). */
    fun height(slot: Int, level: Int): Float = when {
        level <= 0 -> 130f
        slot == 1 -> 300f + level * 55f
        slot == 4 -> 260f + level * 40f
        slot == 2 -> 200f + level * 40f
        else -> 210f + level * 26f
    }

    private fun ol(th: Theme, w: Float = 7f) {
        o.shader = null; o.pathEffect = null; o.strokeWidth = w
        o.color = if (th.kind == Themes.NEON) th.roof else INK
    }

    private fun plot(c: Canvas, t: Float) {
        p.color = 0xFF8D6E63.toInt(); c.drawOval(-120f, -28f, 120f, 24f, p)
        p.color = 0xFF6D4C41.toInt(); c.drawOval(-100f, -18f, 100f, 16f, p)
        p.color = 0xFF9E9E9E.toInt(); c.drawCircle(-70f, -6f, 9f, p); c.drawCircle(55f, 4f, 7f, p)
        // sign
        o.strokeWidth = 6f; o.color = INK; o.shader = null
        p.color = 0xFF8D5A2B.toInt(); c.drawRect(-8f, -120f, 8f, 0f, p); c.drawRect(-8f, -120f, 8f, 0f, o)
        val bob = sin(t * 3f) * 4f
        r.set(-62f, -170f + bob, 62f, -100f + bob)
        p.color = 0xFFD7A86E.toInt(); c.drawRoundRect(r, 12f, 12f, p); c.drawRoundRect(r, 12f, 12f, o)
        Art.iconHammer(c, 0f, -135f + bob, 60f)
    }

    private fun wall(c: Canvas, th: Theme, l: Float, t: Float, rr: Float, b: Float, level: Int) {
        r.set(l, t, rr, b)
        p.color = -1; p.shader = LinearGradient(l, 0f, rr, 0f, lighten(th.wall, 0.15f), darken(th.wall, 0.18f), Shader.TileMode.CLAMP)
        c.drawRect(r, p); p.shader = null
        // texture
        o.shader = null; o.pathEffect = null
        when (th.kind) {
            Themes.PIRATE, Themes.JUNGLE -> { o.strokeWidth = 3f; o.color = withAlpha(darken(th.wall, 0.4f), 120); var y = t + 22f; while (y < b) { c.drawLine(l, y, rr, y, o); y += 22f } }
            Themes.SNOW, Themes.VOLCANO -> {
                o.strokeWidth = 3f; o.color = withAlpha(darken(th.wall, 0.45f), 110); var y = t + 26f; var row = 0
                while (y < b) { c.drawLine(l, y, rr, y, o); var x = l + (if (row % 2 == 0) 20f else 45f); while (x < rr) { c.drawLine(x, y - 26f, x, y, o); x += 50f }; y += 26f; row++ }
            }
            Themes.CANDY -> { p.color = 0xFF8D4F2C.toInt(); var k = 0; var y = t + 20f; while (y < b - 10f) { var x = l + 18f + (k % 2) * 20f; while (x < rr - 10f) { c.drawCircle(x, y, 5f, p); x += 44f }; y += 34f; k++ } }
            Themes.NEON -> { o.strokeWidth = 2f; o.color = 0x5500F5D4; var x = l + 16f; while (x < rr) { c.drawLine(x, t, x, b, o); x += 32f } }
        }
        if (th.kind == Themes.VOLCANO) { o.strokeWidth = 4f; o.color = 0xCCFF6D00.toInt(); c.drawLine(l + 20f, b - 10f, l + 40f, b - 50f, o); c.drawLine(l + 40f, b - 50f, l + 30f, b - 80f, o) }
        // trim
        p.color = if (level >= MAX_LEVEL) 0xFFFFC107.toInt() else th.trim
        c.drawRect(l - 6f, b - 14f, rr + 6f, b, p)
        ol(th); c.drawRect(r, o)
        if (th.kind == Themes.NEON) { o.strokeWidth = 16f; o.color = withAlpha(th.roof, 60); c.drawRect(r, o) }
    }

    private fun roof(c: Canvas, th: Theme, l: Float, rr: Float, base: Float, hgt: Float, level: Int) {
        val gold = level >= MAX_LEVEL
        val col = th.roof
        val cx = (l + rr) / 2
        val style = th.roofStyle
        path.reset()
        when (style) {
            1 -> { r.set(l - 6f, base - hgt * 1.4f, rr + 6f, base + hgt * 1.4f); path.arcTo(r, 180f, 180f); path.close() }
            2 -> {
                path.moveTo(l - 14f, base); path.lineTo(l - 14f, base - hgt * 0.5f)
                val n = 5; val seg = (rr - l + 28f) / (n * 2 - 1)
                var x = l - 14f
                for (i in 0 until n * 2 - 1) {
                    val top = if (i % 2 == 0) base - hgt * 0.5f else base - hgt * 0.3f
                    path.lineTo(x, top); path.lineTo(x + seg, top); x += seg
                }
                path.lineTo(rr + 14f, base - hgt * 0.5f); path.lineTo(rr + 14f, base); path.close()
            }
            else -> { path.moveTo(l - 26f, base); path.lineTo(cx, base - hgt); path.lineTo(rr + 26f, base); path.close() }
        }
        p.color = -1; p.shader = LinearGradient(0f, base - hgt, 0f, base, lighten(col, 0.25f), darken(col, 0.2f), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        if (style == 3) { // thatch
            o.strokeWidth = 3f; o.color = withAlpha(darken(col, 0.45f), 160)
            var k = 0f
            while (k < 1f) { c.drawLine(cx, base - hgt, lerp(l - 26f, rr + 26f, k), base, o); k += 0.08f }
        }
        if (th.kind == Themes.CANDY && style == 1) {
            p.color = 0xFFFFFFFF.toInt()
            for (i in 0 until 8) c.drawCircle(lerp(l + 10f, rr - 10f, i / 7f), base - hgt * 0.5f + sin(i * 1.7f) * hgt * 0.3f, 6f, p)
        }
        if (th.kind == Themes.SNOW && style == 0) {
            val sp = Path()
            sp.moveTo(cx, base - hgt); sp.lineTo(cx + (rr + 26f - cx) * 0.55f, base - hgt * 0.45f)
            sp.quadTo(cx + (rr - cx) * 0.3f, base - hgt * 0.32f, cx + (rr - cx) * 0.1f, base - hgt * 0.45f)
            sp.quadTo(cx - (rr - cx) * 0.2f, base - hgt * 0.3f, cx - (cx - l + 26f) * 0.55f, base - hgt * 0.45f); sp.close()
            p.color = 0xFFFFFFFF.toInt(); c.drawPath(sp, p)
        }
        ol(th); c.drawPath(path, o)
        if (gold) { o.strokeWidth = 6f; o.color = 0xFFFFD54F.toInt(); c.drawPath(path, o) }
        if (th.kind == Themes.NEON) { o.strokeWidth = 18f; o.color = withAlpha(th.accent, 70); c.drawPath(path, o); o.strokeWidth = 5f; o.color = th.accent; c.drawPath(path, o) }
    }

    private fun window(c: Canvas, th: Theme, cx: Float, cy: Float, w: Float, h: Float, t: Float) {
        val night = th.kind == Themes.NEON || th.kind == Themes.VOLCANO
        r.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
        p.color = th.trim; c.drawRoundRect(r.left - 6f, r.top - 6f, r.right + 6f, r.bottom + 6f, 8f, 8f, p)
        val lit = if (night) (if (th.kind == Themes.NEON) th.roof else 0xFFFFB74D.toInt()) else 0xFF81D4FA.toInt()
        p.color = -1; p.shader = LinearGradient(0f, r.top, 0f, r.bottom, lighten(lit, 0.4f), lit, Shader.TileMode.CLAMP)
        c.drawRect(r, p); p.shader = null
        if (night) Art.glow(c, cx, cy, w * 1.4f, lit, 0.35f + 0.1f * sin(t * 3f + cx))
        o.strokeWidth = 4f; o.color = th.trim; c.drawLine(cx, r.top, cx, r.bottom, o); c.drawLine(r.left, cy, r.right, cy, o)
        p.color = 0x66FFFFFF; c.drawRect(r.left + 3f, r.top + 3f, cx - 3f, cy - 3f, p)
        ol(th, 5f); c.drawRect(r, o)
    }

    private fun door(c: Canvas, th: Theme, cx: Float, base: Float, w: Float, h: Float) {
        path.reset(); path.moveTo(cx - w / 2, base); path.lineTo(cx - w / 2, base - h + w / 2)
        r.set(cx - w / 2, base - h, cx + w / 2, base - h + w); path.arcTo(r, 180f, 180f); path.lineTo(cx + w / 2, base); path.close()
        p.color = if (th.kind == Themes.NEON) 0xFF0B0B14.toInt() else 0xFF6D4C41.toInt(); c.drawPath(path, p)
        ol(th, 5f); c.drawPath(path, o)
        p.color = 0xFFFFC107.toInt(); c.drawCircle(cx + w * 0.25f, base - h * 0.45f, 5f, p)
    }

    private fun flag(c: Canvas, x: Float, top: Float, col: Int, t: Float) {
        o.strokeWidth = 6f; o.color = INK; c.drawLine(x, top, x, top + 80f, o)
        path.reset(); path.moveTo(x, top)
        path.quadTo(x + 30f, top + sin(t * 6f) * 8f, x + 62f, top + 16f + sin(t * 6f + 1f) * 6f)
        path.quadTo(x + 30f, top + 30f + sin(t * 6f + 2f) * 6f, x, top + 36f); path.close()
        p.color = col; c.drawPath(path, p); o.strokeWidth = 4f; c.drawPath(path, o)
        p.color = 0xFFFFC107.toInt(); c.drawCircle(x, top - 4f, 7f, p)
    }

    private fun house(c: Canvas, th: Theme, lv: Int, t: Float) {
        val w = 170f + lv * 14f; val h = 110f + lv * 16f
        if (lv >= 4) { // wing
            val wl = w / 2 - 20f; val wr = w / 2 + w * 0.38f; val wh = h * 0.7f
            wall(c, th, wl, -wh, wr, 0f, lv); roof(c, th, wl, wr, -wh, 60f, lv)
            window(c, th, (wl + wr) / 2 + 10f, -wh * 0.5f, 34f, 34f, t)
        }
        if (lv >= 3) { // chimney
            p.color = darken(th.wall, 0.25f); r.set(w * 0.18f, -h - 85f - lv * 4f, w * 0.18f + 34f, -h - 10f)
            c.drawRect(r, p); ol(th, 6f); c.drawRect(r, o)
        }
        wall(c, th, -w / 2, -h, w / 2, 0f, lv)
        roof(c, th, -w / 2, w / 2, -h, 80f + lv * 9f, lv)
        door(c, th, 0f, -2f, 46f, 74f)
        if (lv >= 2) { window(c, th, -w * 0.3f, -h * 0.55f, 38f, 38f, t); window(c, th, w * 0.3f, -h * 0.55f, 38f, 38f, t) }
        if (lv >= 3) { // flower boxes
            p.color = 0xFF8D5A2B.toInt(); c.drawRect(-w * 0.3f - 26f, -h * 0.55f + 22f, -w * 0.3f + 26f, -h * 0.55f + 34f, p)
            c.drawRect(w * 0.3f - 26f, -h * 0.55f + 22f, w * 0.3f + 26f, -h * 0.55f + 34f, p)
            for (fx in floatArrayOf(-w * 0.3f - 14f, -w * 0.3f, -w * 0.3f + 14f, w * 0.3f - 14f, w * 0.3f, w * 0.3f + 14f)) {
                p.color = th.accent; c.drawCircle(fx, -h * 0.55f + 18f, 7f, p)
            }
        }
        if (lv >= 5) flag(c, 0f, -h - 80f - lv * 9f - 70f, th.accent, t)
    }

    private fun tower(c: Canvas, th: Theme, lv: Int, t: Float) {
        val w = 92f + lv * 8f; val h = 160f + lv * 46f
        val lighthouse = th.kind == Themes.BEACH
        val obelisk = th.kind == Themes.DESERT
        if (obelisk) {
            path.reset(); path.moveTo(-w / 2, 0f); path.lineTo(-w * 0.32f, -h); path.lineTo(w * 0.32f, -h); path.lineTo(w / 2, 0f); path.close()
            p.color = -1; p.shader = LinearGradient(-w / 2, 0f, w / 2, 0f, lighten(th.wall, 0.15f), darken(th.wall, 0.2f), Shader.TileMode.CLAMP)
            c.drawPath(path, p); p.shader = null; ol(th); c.drawPath(path, o)
            o.strokeWidth = 4f; o.color = withAlpha(darken(th.wall, 0.5f), 150)
            var y = -40f; while (y > -h + 20f) { c.drawLine(-12f, y, 12f, y, o); c.drawCircle(0f, y - 14f, 6f, o); y -= 60f }
            path.reset(); path.moveTo(-w * 0.32f, -h); path.lineTo(0f, -h - 60f); path.lineTo(w * 0.32f, -h); path.close()
            p.color = 0xFFFFC107.toInt(); c.drawPath(path, p); ol(th); c.drawPath(path, o)
            if (lv >= 4) Art.glow(c, 0f, -h - 30f, 120f, 0xFFFFF59D.toInt(), 0.6f + 0.3f * sin(t * 3f))
            return
        }
        wall(c, th, -w / 2, -h, w / 2, 0f, lv)
        if (lighthouse) {
            p.color = 0xFFE53935.toInt()
            var y = -h + 30f; while (y < -20f) { c.drawRect(-w / 2, y, w / 2, y + 30f, p); y += 60f }
            ol(th); c.drawRect(-w / 2, -h, w / 2, 0f, o)
        }
        var wy = -70f
        while (wy > -h + 40f) { window(c, th, 0f, wy, 30f, 40f, t); wy -= 85f }
        door(c, th, 0f, -2f, 40f, 60f)
        if (lv >= 3) { // balcony
            p.color = th.trim; r.set(-w / 2 - 22f, -h + 2f, w / 2 + 22f, -h + 22f); c.drawRect(r, p); ol(th, 6f); c.drawRect(r, o)
        }
        if (lighthouse) {
            r.set(-w * 0.35f, -h - 70f, w * 0.35f, -h); p.color = 0xFFFFF59D.toInt(); c.drawRect(r, p); ol(th); c.drawRect(r, o)
            val a = t * 1.6f
            p.shader = null; p.color = 0x55FFF59D
            path.reset(); path.moveTo(0f, -h - 35f); path.lineTo(cos(a) * 520f, -h - 35f - 90f); path.lineTo(cos(a) * 520f, -h - 35f + 90f); path.close()
            c.drawPath(path, p)
            roof(c, th, -w * 0.4f, w * 0.4f, -h - 70f, 60f, lv)
        } else roof(c, th, -w / 2, w / 2, -h, 110f + lv * 10f, lv)
        val top = if (lighthouse) -h - 130f else -h - 110f - lv * 10f
        if (lv >= 4) flag(c, 0f, top - 80f, th.accent, t)
        if (lv >= 5) {
            Art.glow(c, 0f, top, 120f, th.accent, 0.5f + 0.3f * sin(t * 4f))
        }
    }

    private fun statue(c: Canvas, th: Theme, lv: Int, t: Float) {
        val ph = 46f + lv * 10f
        path.reset(); path.moveTo(-90f, 0f); path.lineTo(-70f, -ph); path.lineTo(70f, -ph); path.lineTo(90f, 0f); path.close()
        val stone = if (th.kind == Themes.NEON) 0xFF2B2D42.toInt() else if (th.kind == Themes.VOLCANO) 0xFF3E2723.toInt() else 0xFFB0A89E.toInt()
        p.color = -1; p.shader = LinearGradient(-90f, 0f, 90f, 0f, lighten(stone, 0.2f), darken(stone, 0.2f), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null; ol(th); c.drawPath(path, o)
        p.color = if (lv >= MAX_LEVEL) 0xFFFFC107.toInt() else th.trim; c.drawRect(-82f, -ph - 14f, 82f, -ph, p); ol(th, 6f); c.drawRect(-82f, -ph - 14f, 82f, -ph, o)
        if (lv == 1) {
            path.reset(); path.moveTo(-50f, -ph - 14f); path.lineTo(-40f, -ph - 120f); path.lineTo(30f, -ph - 140f); path.lineTo(52f, -ph - 14f); path.close()
            p.color = stone; c.drawPath(path, p); ol(th); c.drawPath(path, o)
            Ui.text(c, "?", 0f, -ph - 70f, 60f, 0xFFFFFFFF.toInt())
            return
        }
        val tint = when {
            th.kind == Themes.NEON -> 0xFF00F5D4.toInt()
            th.kind == Themes.SNOW -> 0xFF81D4FA.toInt()
            th.kind == Themes.CANDY -> 0xFFF06292.toInt()
            th.kind == Themes.DESERT && lv < 5 -> 0xFFE0B872.toInt()
            lv >= 5 -> 0xFFFFC107.toInt()
            lv == 4 -> 0xFFCFD8DC.toInt()
            else -> 0xFF9E9E9E.toInt()
        }
        val s = 0.36f + lv * 0.06f
        if (th.kind == Themes.NEON) Art.glow(c, 0f, -ph - 120f * s * 1.5f, 180f, tint, 0.4f + 0.2f * sin(t * 8f))
        Art.capi(c, 0f, -ph - 12f, s, 0f, Art.Mood.HAPPY, if (lv >= 4) 1 else 0, tint, blinkOk = false)
    }

    private fun market(c: Canvas, th: Theme, lv: Int, t: Float) {
        val w = 190f + lv * 12f; val postH = 150f + lv * 8f
        if (lv >= 2) crate(c, -w / 2 - 40f, 0f, th)
        if (lv >= 3) barrel(c, w / 2 + 38f, 0f, th)
        // posts
        p.color = 0xFF8D5A2B.toInt(); ol(th, 6f)
        c.drawRect(-w / 2, -postH, -w / 2 + 14f, 0f, p); c.drawRect(-w / 2, -postH, -w / 2 + 14f, 0f, o)
        c.drawRect(w / 2 - 14f, -postH, w / 2, 0f, p); c.drawRect(w / 2 - 14f, -postH, w / 2, 0f, o)
        // counter
        wall(c, th, -w / 2 + 6f, -66f, w / 2 - 6f, 0f, lv)
        // goods
        val goods = intArrayOf(0xFFFF7043.toInt(), 0xFFFFEB3B.toInt(), 0xFF8BC34A.toInt(), 0xFFE91E63.toInt(), 0xFFAB47BC.toInt())
        val n = lv * 2 + 1
        for (i in 0 until n) {
            val gx = lerp(-w / 2 + 34f, w / 2 - 34f, if (n == 1) 0.5f else i / (n - 1f))
            p.color = goods[i % goods.size]; c.drawCircle(gx, -78f, 15f, p); ol(th, 4f); c.drawCircle(gx, -78f, 15f, o)
        }
        if (lv >= 5) { for (i in 0 until 5) Art.coin(c, -30f + i * 15f, -98f - (i % 2) * 14f, 16f) }
        // awning
        val at = -postH - 10f; val ab = -postH + 44f
        val stripes = 7; val sw = (w + 40f) / stripes
        for (i in 0 until stripes) {
            p.color = if (i % 2 == 0) th.accent else 0xFFFFFFFF.toInt()
            val sx = -w / 2 - 20f + i * sw
            c.drawRect(sx, at, sx + sw, ab, p)
            c.drawCircle(sx + sw / 2, ab, sw / 2, p)
        }
        ol(th, 6f); c.drawRect(-w / 2 - 20f, at, w / 2 + 20f, ab, o)
        if (lv >= 4) { // lantern
            o.strokeWidth = 4f; c.drawLine(w / 2 - 30f, ab, w / 2 - 30f, ab + 34f, o)
            Art.glow(c, w / 2 - 30f, ab + 50f, 70f, 0xFFFFCA28.toInt(), 0.7f + 0.2f * sin(t * 5f))
            p.color = 0xFFFFE082.toInt(); c.drawCircle(w / 2 - 30f, ab + 50f, 15f, p); ol(th, 4f); c.drawCircle(w / 2 - 30f, ab + 50f, 15f, o)
        }
        if (lv >= 5) {
            r.set(-70f, at - 56f, 70f, at - 6f); p.color = 0xFF8D5A2B.toInt(); c.drawRoundRect(r, 10f, 10f, p); ol(th, 5f); c.drawRoundRect(r, 10f, 10f, o)
            Ui.text(c, "$$$", 0f, at - 31f, 38f, 0xFFFFD54F.toInt(), ow = 6f)
        }
    }

    private fun crate(c: Canvas, x: Float, b: Float, th: Theme) {
        r.set(x - 34f, b - 64f, x + 34f, b); p.color = 0xFFC8955A.toInt(); c.drawRect(r, p); ol(th, 5f); c.drawRect(r, o)
        c.drawLine(r.left, r.top, r.right, r.bottom, o); c.drawLine(r.right, r.top, r.left, r.bottom, o)
    }

    private fun barrel(c: Canvas, x: Float, b: Float, th: Theme) {
        r.set(x - 30f, b - 76f, x + 30f, b); p.color = 0xFF8D5A2B.toInt(); c.drawRoundRect(r, 18f, 18f, p); ol(th, 5f); c.drawRoundRect(r, 18f, 18f, o)
        o.color = 0xFF616161.toInt(); c.drawLine(r.left + 3f, b - 20f, r.right - 3f, b - 20f, o); c.drawLine(r.left + 3f, b - 56f, r.right - 3f, b - 56f, o)
    }

    private fun temple(c: Canvas, th: Theme, lv: Int, t: Float) {
        val w = 210f + lv * 14f; val h = 110f + lv * 18f
        // steps
        for (i in 0 until 3) {
            val sw = w / 2 + 40f - i * 18f
            r.set(-sw, -18f * (i + 1), sw, -18f * i)
            p.color = lighten(th.wall, 0.1f + i * 0.05f); c.drawRect(r, p); ol(th, 5f); c.drawRect(r, o)
        }
        val base = -54f
        if (lv >= 3) { // side towers
            for (sx in floatArrayOf(-w / 2 - 30f, w / 2 + 30f)) {
                wall(c, th, sx - 34f, base - h * 1.25f, sx + 34f, base, lv)
                roof(c, th, sx - 34f, sx + 34f, base - h * 1.25f, 70f, lv)
                window(c, th, sx, base - h * 0.8f, 24f, 34f, t)
            }
        }
        wall(c, th, -w / 2, base - h, w / 2, base, lv)
        // columns
        val cols = 2 + lv
        for (i in 0 until cols) {
            val cx = lerp(-w / 2 + 22f, w / 2 - 22f, i / (cols - 1f))
            if (kotlin.math.abs(cx) < 30f) continue
            r.set(cx - 10f, base - h + 10f, cx + 10f, base - 4f)
            p.color = -1; p.shader = LinearGradient(cx - 10f, 0f, cx + 10f, 0f, 0xFFFFFFFF.toInt(), lighten(th.wall, 0.1f), Shader.TileMode.CLAMP)
            c.drawRect(r, p); p.shader = null; ol(th, 4f); c.drawRect(r, o)
        }
        door(c, th, 0f, base - 2f, 54f, 84f)
        roof(c, th, -w / 2, w / 2, base - h, 90f + lv * 10f, lv)
        if (lv >= 4) {
            val top = base - h - 90f - lv * 10f
            if (lv >= 5) { Art.glow(c, 0f, top, 150f, 0xFFFFF59D.toInt(), 0.6f + 0.25f * sin(t * 3f)); Art.coin(c, 0f, top - 10f, 30f) }
            else flag(c, 0f, top - 80f, th.accent, t)
        }
    }

    private fun pyramid(c: Canvas, th: Theme, lv: Int, t: Float) {
        val w = 170f + lv * 32f; val h = 130f + lv * 30f
        path.reset(); path.moveTo(-w / 2, 0f); path.lineTo(0f, -h); path.lineTo(w / 2, 0f); path.close()
        p.color = -1; p.shader = LinearGradient(-w / 2, 0f, w / 2, 0f, 0xFFF3D08C.toInt(), 0xFFC4913F.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p); p.shader = null
        path2.reset(); path2.moveTo(0f, -h); path2.lineTo(w / 2, 0f); path2.lineTo(w * 0.12f, 0f); path2.close()
        p.color = 0x33000000; c.drawPath(path2, p)
        o.strokeWidth = 3f; o.color = 0x668D6E3F
        var k = 1; while (k < 8) { val yy = -h * k / 8f; val half = w / 2 * (1 - k / 8f); c.drawLine(-half, yy, half, yy, o); k++ }
        ol(th); c.drawPath(path, o)
        r.set(-22f, -60f, 22f, 0f); p.color = 0xFF3E2723.toInt(); c.drawRect(r, p); ol(th, 5f); c.drawRect(r, o)
        if (lv >= 5) {
            path.reset(); path.moveTo(-w * 0.12f, -h * 0.88f); path.lineTo(0f, -h); path.lineTo(w * 0.12f, -h * 0.88f); path.close()
            p.color = 0xFFFFD54F.toInt(); c.drawPath(path, p); ol(th); c.drawPath(path, o)
            Art.glow(c, 0f, -h, 140f, 0xFFFFF59D.toInt(), 0.6f + 0.3f * sin(t * 3f))
        }
    }

    private val sparkleP = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun sparkles(c: Canvas, t: Float, seed: Int) {
        sparkleP.color = 0xFFFFFFFF.toInt()
        for (i in 0 until 4) {
            val ph = t * 1.4f + i * 1.7f + seed
            val a = (sin(ph * 2f) * 0.5f + 0.5f)
            sparkleP.alpha = (a * 255).toInt()
            val x = sin(i * 2.3f + seed) * 110f; val y = -60f - ((i * 73 + seed * 31) % 200)
            val rr = 6f + a * 12f
            path.reset(); path.moveTo(x, y - rr); path.quadTo(x, y, x + rr, y); path.quadTo(x, y, x, y + rr); path.quadTo(x, y, x - rr, y); path.quadTo(x, y, x, y - rr); path.close()
            c.drawPath(path, sparkleP)
        }
    }

    private fun damage(c: Canvas, t: Float) {
        o.shader = null; o.pathEffect = null; o.strokeWidth = 7f; o.color = 0xFF1B0E05.toInt()
        path.reset(); path.moveTo(-40f, -150f); path.lineTo(-20f, -110f); path.lineTo(-44f, -80f); path.lineTo(-18f, -40f)
        path.moveTo(30f, -170f); path.lineTo(50f, -130f); path.lineTo(26f, -100f)
        c.drawPath(path, o)
        p.color = 0x55000000; c.drawOval(-70f, -120f, 10f, -60f, p)
        // rubble
        p.color = 0xFF8D8D8D.toInt()
        c.drawCircle(-110f, -6f, 16f, p); c.drawCircle(-86f, 2f, 11f, p); c.drawCircle(100f, -2f, 14f, p)
        // warning sign
        val bob = sin(t * 5f) * 5f
        p.color = 0xFFFFC107.toInt()
        path.reset(); path.moveTo(0f, -260f + bob); path.lineTo(40f, -195f + bob); path.lineTo(-40f, -195f + bob); path.close()
        c.drawPath(path, p); o.strokeWidth = 6f; c.drawPath(path, o)
        Ui.text(c, "!", 0f, -214f + bob, 44f, 0xFF1B0E05.toInt(), ow = 0f)
    }
}
