package com.oateam.capicoin

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout

class GameView(ctx: Context, val game: Game) : View(ctx) {
    private var last = 0L
    private var running = true

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        game.resize(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000.0).toFloat()
        last = now
        try {
            game.update(dt)
            canvas.save()
            canvas.scale(game.scale, game.scale)
            game.draw(canvas)
            canvas.restore()
        } catch (e: Exception) {
            android.util.Log.e("CapiCoin", "frame error", e)
        }
        if (running) postInvalidateOnAnimation()
    }

    fun pause() { running = false }
    fun resume() { running = true; last = 0L; postInvalidateOnAnimation() }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val s = game.scale
        if (s <= 0f) return true
        val type = when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> Game.DOWN
            MotionEvent.ACTION_MOVE -> Game.MOVE
            MotionEvent.ACTION_UP -> Game.UP
            MotionEvent.ACTION_CANCEL -> Game.UP
            else -> return true
        }
        game.touch(type, e.x / s, e.y / s)
        return true
    }
}

class MainActivity : Activity(), Host {
    private lateinit var game: Game
    private lateinit var view: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        Notifs.channel(this)
        game = Game(this, this)
        view = GameView(this, game)
        setContentView(view)
        hideBars()
        handleLink(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLink(intent)
    }

    private fun handleLink(i: Intent?) {
        val data: Uri = i?.data ?: return
        if (data.scheme == "capicoin" && data.host == "login") game.onLoginToken(data.getQueryParameter("token"), data.getQueryParameter("error"))
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideBars() }

    override fun onResume() {
        super.onResume()
        Notifs.cancelLocal(this)
        game.onResume()
        view.resume()
    }

    override fun onPause() {
        game.onPause()
        view.pause()
        if (game.settings.notifs && game.settings.token != null) {
            Notifs.scheduleLocal(this, game.prof)
            Notifs.scheduleJob(this)
        }
        super.onPause()
    }

    override fun onDestroy() { game.audio.release(); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() { if (!game.back()) super.onBackPressed() }

    // ------------------------------------------------------------------ Host
    override fun prompt(title: String, fields: List<Host.Field>, ok: String, extra: String?, cb: (List<String>?, Boolean) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val pad = (20 * resources.displayMetrics.density).toInt()
        box.setPadding(pad, pad / 2, pad, 0)
        val edits = fields.map { f ->
            EditText(this).apply {
                hint = f.label
                setText(f.initial)
                setSingleLine(true)
                inputType = when (f.kind) {
                    Host.Field.EMAIL -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                    Host.Field.PASSWORD -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    else -> InputType.TYPE_CLASS_TEXT
                }
                box.addView(this)
            }
        }
        val b = AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton(ok) { _, _ -> val v = edits.map { it.text.toString().trim() }; game.post { cb(v, false) } }
            .setNegativeButton("Cancelar") { _, _ -> game.post { cb(null, false) } }
        if (extra != null) b.setNeutralButton(extra) { _, _ -> game.post { cb(null, true) } }
        val d = b.create()
        d.setOnDismissListener { hideBars() }
        d.show()
    }

    override fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { game.post { game.toast(Game.T_INFO, "Ops", "Não encontrei um navegador.") } }
    }

    override fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Capi Coin", text))
    }

    override fun share(text: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        try { startActivity(Intent.createChooser(i, "Compartilhar")) } catch (e: Exception) {}
    }

    override fun decodeImage(bytes: ByteArray): Bitmap? = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)

    @SuppressLint("HardwareIds")
    override fun deviceId(): String {
        val sp = getSharedPreferences("capicoin", Context.MODE_PRIVATE)
        sp.getString("deviceId", null)?.let { return it }
        val aid = android.provider.Settings.Secure.getString(contentResolver, android.provider.Settings.Secure.ANDROID_ID)
        val id = "and-" + (if (!aid.isNullOrEmpty() && aid.length >= 8) aid else java.util.UUID.randomUUID().toString())
        sp.edit().putString("deviceId", id).apply()
        return id
    }

    override fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7)
        }
    }
}
