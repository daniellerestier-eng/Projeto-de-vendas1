package com.oateam.capicoin

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface

fun darken(c: Int, f: Float): Int = Color.argb(Color.alpha(c), (Color.red(c) * (1 - f)).toInt(), (Color.green(c) * (1 - f)).toInt(), (Color.blue(c) * (1 - f)).toInt())
fun lighten(c: Int, f: Float): Int = Color.argb(Color.alpha(c), (Color.red(c) + (255 - Color.red(c)) * f).toInt(), (Color.green(c) + (255 - Color.green(c)) * f).toInt(), (Color.blue(c) + (255 - Color.blue(c)) * f).toInt())
fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
fun mixColor(a: Int, b: Int, t: Float): Int = Color.argb(
    (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
    (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
    (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
    (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
)

object Ui {
    val font: Typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = font }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = font; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND
    }
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    const val OUTLINE = 0xFF3A1A06.toInt()
    const val GOLD1 = 0xFFFFF59D.toInt()
    const val GOLD2 = 0xFFFFB300.toInt()

    fun measure(s: String, size: Float): Float { fill.textSize = size; return fill.measureText(s) }

    /** Cartoon text with dark outline + drop shadow. y is the vertical CENTER. */
    fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = Color.WHITE,
        align: Paint.Align = Paint.Align.CENTER, outline: Int = OUTLINE, ow: Float = size * 0.17f,
        alpha: Float = 1f, gold: Boolean = false, maxW: Float = 0f
    ) {
        var sz = size
        if (maxW > 0f) { fill.textSize = sz; val w = fill.measureText(s); if (w > maxW) sz *= maxW / w }
        val a = (255 * clamp01(alpha)).toInt()
        val by = y + sz * 0.36f
        fill.textSize = sz; stroke.textSize = sz
        fill.textAlign = align; stroke.textAlign = align
        stroke.strokeWidth = ow * (sz / size)
        if (ow > 0f) {
            stroke.color = withAlpha(0xFF000000.toInt(), (a * 0.35f).toInt())
            c.drawText(s, x, by + sz * 0.08f, stroke)
            stroke.color = withAlpha(outline, a)
            c.drawText(s, x, by, stroke)
        }
        if (gold) {
            fill.color = -1; fill.shader = LinearGradient(0f, by - sz * 0.8f, 0f, by, GOLD1, GOLD2, Shader.TileMode.CLAMP)
            fill.color = Color.WHITE
        } else {
            fill.shader = null; fill.color = color
        }
        fill.alpha = a
        c.drawText(s, x, by, fill)
        fill.shader = null
    }

    /** Glossy rounded panel. */
    fun panel(c: Canvas, l: Float, t: Float, rr: Float, b: Float, color: Int, radius: Float = 40f, border: Int = OUTLINE, bw: Float = 8f, gloss: Boolean = true) {
        p.shader = null; p.style = Paint.Style.FILL
        p.color = 0x55000000
        r.set(l, t + 12f, rr, b + 12f); c.drawRoundRect(r, radius, radius, p)
        r.set(l, t, rr, b)
        p.color = -1; p.shader = LinearGradient(0f, t, 0f, b, lighten(color, 0.18f), darken(color, 0.12f), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, radius, radius, p)
        p.shader = null
        if (gloss) {
            p.color = 0x33FFFFFF
            r.set(l + bw, t + bw, rr - bw, t + (b - t) * 0.42f)
            c.drawRoundRect(r, radius * 0.8f, radius * 0.8f, p)
        }
        if (bw > 0f) {
            p.style = Paint.Style.STROKE; p.strokeWidth = bw; p.color = border
            r.set(l, t, rr, b); c.drawRoundRect(r, radius, radius, p)
            p.style = Paint.Style.FILL
        }
    }

    fun pill(c: Canvas, l: Float, t: Float, rr: Float, b: Float, color: Int) {
        val h = b - t
        p.shader = null; p.style = Paint.Style.FILL; p.color = color
        r.set(l, t, rr, b); c.drawRoundRect(r, h / 2, h / 2, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = 0xAA000000.toInt()
        c.drawRoundRect(r, h / 2, h / 2, p)
        p.style = Paint.Style.FILL
    }

    fun bar(c: Canvas, l: Float, t: Float, rr: Float, b: Float, frac: Float, c1: Int, c2: Int) {
        val h = b - t
        p.shader = null; p.style = Paint.Style.FILL; p.color = 0xCC1B0E05.toInt()
        r.set(l, t, rr, b); c.drawRoundRect(r, h / 2, h / 2, p)
        val f = clamp01(frac)
        if (f > 0.01f) {
            val inner = 6f
            r.set(l + inner, t + inner, l + inner + (rr - l - 2 * inner) * f, b - inner)
            if (r.width() < r.height()) r.right = r.left + r.height()
            p.color = -1; p.shader = LinearGradient(0f, t, 0f, b, c1, c2, Shader.TileMode.CLAMP)
            c.drawRoundRect(r, (h - 2 * inner) / 2, (h - 2 * inner) / 2, p)
            p.shader = null
            p.color = 0x44FFFFFF
            r.bottom = r.top + (r.height() * 0.45f)
            c.drawRoundRect(r, r.height() / 2, r.height() / 2, p)
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = OUTLINE
        r.set(l, t, rr, b); c.drawRoundRect(r, h / 2, h / 2, p)
        p.style = Paint.Style.FILL
    }

    fun dim(c: Canvas, w: Float, h: Float, a: Float) {
        p.shader = null; p.style = Paint.Style.FILL
        p.color = withAlpha(0xFF0A0614.toInt(), (a * 255).toInt())
        c.drawRect(0f, 0f, w, h, p)
    }

    fun badge(c: Canvas, x: Float, y: Float, s: String, t: Float) {
        val sc = 1f + 0.12f * kotlin.math.sin(t * 6f)
        p.shader = null; p.style = Paint.Style.FILL
        p.color = 0xFFE53935.toInt(); c.drawCircle(x, y, 30f * sc, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Color.WHITE; c.drawCircle(x, y, 30f * sc, p)
        p.style = Paint.Style.FILL
        text(c, s, x, y, 38f * sc, ow = 5f)
    }
}

/** Chunky 3D button with press animation. */
class Button(
    var x: Float, var y: Float, var w: Float, var h: Float,
    var label: String, var color: Int,
    val onClick: () -> Unit
) {
    var enabled = true
    var visible = true
    var pressed = false
    var textSize = 0f
    var sub: String? = null
    var icon: ((Canvas, Float, Float, Float) -> Unit)? = null
    var badge: String? = null
    var pulse = false
    var textColor = 0xFFFFFFFF.toInt()
    var textOutline = Ui.OUTLINE
    var labelDx = 0f
    private var pressAnim = 0f
    private val rect = RectF()

    fun set(nx: Float, ny: Float, nw: Float, nh: Float): Button { x = nx; y = ny; w = nw; h = nh; return this }
    fun contains(px: Float, py: Float) = visible && px >= x && px <= x + w && py >= y - 10 && py <= y + h + 14

    /** returns true if consumed */
    fun touch(type: Int, px: Float, py: Float, g: Game): Boolean {
        if (!visible) return false
        when (type) {
            Game.DOWN -> if (contains(px, py)) { pressed = true; return true }
            Game.MOVE -> if (pressed) { if (!contains(px, py)) pressed = false; return true }
            Game.UP -> if (pressed) {
                pressed = false
                if (contains(px, py)) {
                    if (enabled) { g.audio.play("click"); g.audio.vibrate(12, 60); onClick() }
                    else g.audio.play("tick", 0.6f)
                }
                return true
            }
        }
        return false
    }

    fun draw(c: Canvas, t: Float) {
        if (!visible) return
        pressAnim += ((if (pressed) 1f else 0f) - pressAnim) * 0.45f
        val depth = 14f
        val off = depth * pressAnim
        var sc = 1f
        if (pulse && enabled) sc = 1f + 0.04f * kotlin.math.sin(t * 5f)
        c.save()
        c.scale(sc, sc, x + w / 2, y + h / 2)
        val base = if (enabled) color else 0xFF8A8A8A.toInt()
        val p = Ui.p
        p.shader = null; p.style = Paint.Style.FILL
        val rad = minOf(h * 0.36f, 46f)
        // shadow + 3D side
        p.color = 0x44000000; rect.set(x, y + depth + 8f, x + w, y + h + depth + 8f); c.drawRoundRect(rect, rad, rad, p)
        p.color = darken(base, 0.42f); rect.set(x, y + depth, x + w, y + h + depth); c.drawRoundRect(rect, rad, rad, p)
        // face
        rect.set(x, y + off, x + w, y + h + off)
        p.color = -1; p.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, lighten(base, 0.25f), darken(base, 0.08f), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, rad, rad, p)
        p.shader = null
        p.color = 0x40FFFFFF
        rect.set(x + 12f, y + off + 8f, x + w - 12f, y + off + h * 0.45f)
        c.drawRoundRect(rect, rad * 0.7f, rad * 0.7f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = Ui.OUTLINE
        rect.set(x, y + off, x + w, y + h + off + depth * (1 - pressAnim)); c.drawRoundRect(rect, rad, rad, p)
        p.style = Paint.Style.FILL
        val ts = if (textSize > 0f) textSize else h * 0.36f
        val cy = y + off + h / 2
        val ic = icon
        if (ic != null) {
            if (label.isEmpty()) ic(c, x + w / 2, cy, h * 0.62f)
            else {
                ic(c, x + w / 2, cy - h * 0.16f, h * 0.48f)
                Ui.text(c, label, x + w / 2, cy + h * 0.3f, ts * 0.72f, maxW = w - 16f)
            }
        } else if (sub != null) {
            Ui.text(c, label, x + w / 2, cy - h * 0.14f, ts, maxW = w - 24f)
            Ui.text(c, sub!!, x + w / 2, cy + h * 0.24f, ts * 0.62f, color = 0xFFFFF3C4.toInt(), maxW = w - 24f)
        } else {
            Ui.text(c, label, x + w / 2 + labelDx, cy, ts, textColor, outline = textOutline, maxW = w - 24f - kotlin.math.abs(labelDx) * 2)
        }
        c.restore()
        badge?.let { Ui.badge(c, x + w - 10f, y + 6f, it, t) }
    }
}

/** Small helpers shared by many screens. */
object UiX {
    private val r = RectF()
    fun spinner(c: Canvas, x: Float, y: Float, rad: Float, t: Float) {
        val p = Ui.p; p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = rad * 0.22f; p.strokeCap = Paint.Cap.ROUND
        r.set(x - rad, y - rad, x + rad, y + rad)
        p.color = 0x55FFFFFF; c.drawCircle(x, y, rad, p)
        p.color = 0xFFFFD54F.toInt(); c.drawArc(r, t * 360f, 100f + 60f * kotlin.math.sin(t * 3f), false, p)
        p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT
    }

    /** Pill-shaped tab bar. Returns nothing; hit testing via tabAt. */
    fun tabs(c: Canvas, l: Float, t: Float, rr: Float, h: Float, labels: List<String>, sel: Int, badges: List<Int>? = null) {
        val w = (rr - l) / labels.size
        Ui.pill(c, l, t, rr, t + h, 0x66000000)
        for (i in labels.indices) {
            val x0 = l + i * w
            if (i == sel) Ui.panel(c, x0 + 4f, t + 4f, x0 + w - 4f, t + h - 4f, 0xFFFFA000.toInt(), (h - 8f) / 2, bw = 5f)
            Ui.text(c, labels[i], x0 + w / 2, t + h / 2, h * 0.38f, if (i == sel) 0xFFFFFFFF.toInt() else 0xFFE0E0E0.toInt(), maxW = w - 16f, ow = 5f)
            val b = badges?.getOrNull(i) ?: 0
            if (b > 0) Ui.badge(c, x0 + w - 18f, t + 10f, b.toString(), 0f)
        }
    }

    fun tabAt(x: Float, y: Float, l: Float, t: Float, rr: Float, h: Float, n: Int): Int {
        if (y < t || y > t + h || x < l || x > rr) return -1
        return ((x - l) / ((rr - l) / n)).toInt().coerceIn(0, n - 1)
    }

    /** Reward chips like "⚡ 25  💎 5" drawn with icons. Returns width used. */
    fun rewards(c: Canvas, give: J, cx: Float, y: Float, size: Float, color: Int = 0xFFFFFFFF.toInt()) {
        val parts = ArrayList<Pair<Int, String>>()
        if (give["coins"].long() > 0) parts.add(0 to Fmt.n(give["coins"].long()))
        if (give["spins"].int() > 0) parts.add(1 to give["spins"].int().toString())
        if (give["gems"].int() > 0) parts.add(2 to give["gems"].int().toString())
        if (give["petiscos"].int() > 0) parts.add(3 to give["petiscos"].int().toString())
        if (give["shields"].int() > 0) parts.add(4 to give["shields"].int().toString())
        val gap = size * 0.4f
        val widths = parts.map { size * 1.05f + Ui.measure(it.second, size) + gap }
        var x = cx - widths.sum() / 2 + gap / 2
        for ((i, pr) in parts.withIndex()) {
            val ix = x + size * 0.45f
            when (pr.first) {
                0 -> Art.coin(c, ix, y, size * 0.45f)
                1 -> Art.iconEnergy(c, ix, y, size * 1.0f)
                2 -> Art.iconGem(c, ix, y, size * 0.95f)
                3 -> Art.iconPetisco(c, ix, y, size * 1.0f)
                else -> Art.iconShield(c, ix, y, size * 0.95f, true)
            }
            Ui.text(c, pr.second, x + size * 1.0f, y, size, color, align = Paint.Align.LEFT, ow = size * 0.14f)
            x += widths[i]
        }
    }
}
