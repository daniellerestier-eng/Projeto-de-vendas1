package com.oateam.capicoin

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.sin

/** Friends, requests and ranking. */
class FriendsPopup(g: Game, private var tab: Int = 0) : Popup(g), HudOnTop {
    private var top = 0f
    private var data: J? = null
    private var board: J? = null
    private val tabs = listOf("AMIGOS", "PEDIDOS", "RANKING")
    private val xBtn = CloseBtn { close() }
    private val add = Button(0f, 0f, 0f, 0f, "ADICIONAR", 0xFF43A047.toInt()) {
        g.host.prompt("Adicionar amigo", listOf(Host.Field("Código do amigo (CAPI-XXXXXX)")), "ENVIAR") { v, _ ->
            if (v != null && v[0].isNotBlank()) g.net.call("POST", "/api/friends/add", mapOf("code" to v[0])) { r ->
                if (r.ok) { g.toast(Game.T_FRIEND, if (r.j["result"]["status"].str() == "accepted") "Agora são amigos!" else "Pedido enviado!", r.j["result"]["name"].str()); load() } else g.error(r)
            }
        }
    }
    private val share = Button(0f, 0f, 0f, 0f, "CONVIDAR", 0xFF1E88E5.toInt()) {
        val code = g.prof?.friendCode ?: ""
        g.host.share("Bora jogar Capi Coin comigo! Me adiciona como amigo com o código $code e a gente troca giros todo dia 🪙")
    }
    private val collect = Button(0f, 0f, 0f, 0f, "COLETAR", 0xFFFB8C00.toInt()) {
        g.net.call("POST", "/api/gifts/collect") { r ->
            if (r.ok) { val n = r.j["result"]["spins"].int(); if (n > 0) { g.spinsFly(n, g.W / 2, top + 380f); g.audio.play("win"); g.toast(Game.T_GIFT, "+$n giros!", "Presentes coletados") } else if (r.j["result"]["limit"].bool()) g.toast(Game.T_INFO, "Limite diário", "Você já coletou 50 presentes hoje."); load() } else g.error(r)
        }
    }
    private val giftAll = Button(0f, 0f, 0f, 0f, "ENVIAR P/ TODOS", 0xFF7B1FA2.toInt()) {
        g.net.call("POST", "/api/friends/giftAll") { r -> if (r.ok) { g.toast(Game.T_GIFT, "Presentes enviados!", "${r.j["result"]["sent"].int()} amigo(s) vão ganhar giros"); load() } else g.error(r) }
    }
    private val rows = ArrayList<Triple<RectF, Int, Long>>() // rect, action(0 gift,1 accept,2 decline), id
    private var scroll = 0f; private var dragY = -1f; private var dragStart = 0f; private var moved = false; private var maxScroll = 0f

    init { load() }
    private var tipped = false
    override fun update(dt: Float) { super.update(dt); if (!tipped && t > 0.4f) { tipped = true; Tips.show(g, "friends") } }

    private fun load() {
        g.net.call("GET", "/api/friends") { r -> if (r.ok) data = r.j["friends"] else g.error(r) }
        if (tab == 2) loadBoard()
    }
    private fun loadBoard() { g.net.call("GET", "/api/leaderboard") { r -> if (r.ok) board = r.j["leaderboard"] } }

    override fun layout() {
        top = (g.H - 1640f) / 2 + 60f
        add.set(g.W - 360f, top + 70f, 290f, 90f); add.textSize = 34f
        share.set(g.W - 360f, top + 175f, 290f, 80f); share.textSize = 32f
        collect.set(g.W - 330f, top + 345f, 250f, 90f); collect.textSize = 34f
        giftAll.set(70f, top + 345f, 380f, 90f); giftAll.textSize = 32f
        xBtn.x = g.W - 80f; xBtn.y = top - 20f
    }

    override fun draw(c: Canvas) {
        val pr = g.prof ?: return
        val sc = begin(c, 24f, top - 70f, g.W - 24f, top + 1580f, 0xFF4A148C.toInt())
        ribbon(c, g.W / 2, top - 40f, 460f, "AMIGOS", 0xFF7B1FA2.toInt())
        Ui.panel(c, 60f, top + 60f, g.W - 60f, top + 270f, 0xFF311B92.toInt(), 30f, bw = 5f)
        Ui.text(c, "Seu código", 100f, top + 100f, 30f, 0xFFD1C4E9.toInt(), align = Paint.Align.LEFT, ow = 4f)
        Ui.text(c, pr.friendCode, 100f, top + 160f, 62f, 0xFFFFEB3B.toInt(), align = Paint.Align.LEFT, maxW = 560f)
        Ui.text(c, "Troquem giros todo dia!", 100f, top + 225f, 30f, align = Paint.Align.LEFT, ow = 4f)
        add.draw(c, g.time); share.draw(c, g.time)
        val d = data
        val reqs = d?.get("requests")?.size ?: 0
        UiX.tabs(c, 60f, top + 285f, g.W - 60f, 80f, tabs, tab, listOf(0, reqs, 0))
        val listTop = if (tab == 0) top + 460f else top + 385f
        if (tab == 0) {
            val gifts = d?.get("gifts")?.size ?: 0
            giftAll.set(70f, top + 375f, 380f, 74f); collect.set(g.W - 330f, top + 375f, 260f, 74f)
            collect.visible = gifts > 0; collect.label = "COLETAR $gifts"; collect.pulse = gifts > 0
            giftAll.visible = (d?.get("friends")?.list?.any { it["canGift"].bool() } == true)
            giftAll.draw(c, g.time); collect.draw(c, g.time)
        } else { collect.visible = false; giftAll.visible = false }
        val save = c.save()
        c.clipRect(40f, listTop, g.W - 40f, top + 1550f)
        rows.clear()
        var y = listTop + 10f - scroll
        when {
            d == null -> UiX.spinner(c, g.W / 2, top + 800f, 50f, g.time)
            tab == 0 -> {
                val list = d["friends"].list
                if (list.isEmpty()) {
                    Art.iconFriends(c, g.W / 2, top + 700f, 300f)
                    Ui.text(c, "Nenhum amigo ainda", g.W / 2, top + 900f, 46f)
                    Ui.text(c, "Toque em CONVIDAR e mande seu código!", g.W / 2, top + 960f, 34f, 0xFFD1C4E9.toInt(), ow = 4f)
                }
                val now = System.currentTimeMillis()
                for (f in list) {
                    row(c, y, f["avatar"].int(), f["name"].str(), "Vila ${f["village"].int()} · " + (if (f["online"].bool()) "online agora" else "visto há ${Fmt.ago(now - f["lastSeen"].long())}"), if (f["online"].bool()) 0xFF69F0AE.toInt() else 0)
                    val rb = RectF(g.W - 270f, y + 26f, g.W - 80f, y + 106f)
                    if (f["canGift"].bool()) { Ui.panel(c, rb.left, rb.top, rb.right, rb.bottom, 0xFFE91E63.toInt(), 36f, bw = 5f); Art.iconGift(c, rb.left + 46f, rb.centerY(), 50f); Ui.text(c, "+2", rb.left + 120f, rb.centerY(), 38f) ; rows.add(Triple(rb, 0, f["id"].long())) }
                    else Ui.text(c, "Enviado ✔", rb.centerX(), rb.centerY(), 32f, 0xFFB9F6CA.toInt(), ow = 4f)
                    y += 148f
                }
            }
            tab == 1 -> {
                val req = d["requests"].list; val sent = d["sent"].list
                if (req.isEmpty() && sent.isEmpty()) Ui.text(c, "Nenhum pedido pendente", g.W / 2, top + 700f, 44f)
                for (f in req) {
                    row(c, y, f["avatar"].int(), f["name"].str(), "Vila ${f["village"].int()} · quer ser seu amigo", 0)
                    val ra = RectF(g.W - 330f, y + 26f, g.W - 210f, y + 106f); val rd = RectF(g.W - 196f, y + 26f, g.W - 80f, y + 106f)
                    Ui.panel(c, ra.left, ra.top, ra.right, ra.bottom, 0xFF43A047.toInt(), 30f, bw = 5f); Ui.text(c, "✔", ra.centerX(), ra.centerY(), 50f)
                    Ui.panel(c, rd.left, rd.top, rd.right, rd.bottom, 0xFFC62828.toInt(), 30f, bw = 5f); Ui.text(c, "✖", rd.centerX(), rd.centerY(), 46f)
                    rows.add(Triple(ra, 1, f["id"].long())); rows.add(Triple(rd, 2, f["id"].long()))
                    y += 148f
                }
                for (f in sent) { row(c, y, f["avatar"].int(), f["name"].str(), "aguardando resposta...", 0); y += 148f }
            }
            else -> {
                val b = board
                if (b == null) UiX.spinner(c, g.W / 2, top + 800f, 50f, g.time)
                else {
                    for ((i, f) in b["top"].list.withIndex()) {
                        val me = f["id"].long() == pr.id
                        Ui.panel(c, 60f, y, g.W - 60f, y + 130f, if (me) 0xFFF57F17.toInt() else if (i < 3) 0xFF6A1B9A.toInt() else 0xFF311B92.toInt(), 30f, bw = 5f, gloss = false)
                        if (i < 3) Art.crown(c, 120f, y + 65f, 0.45f)
                        Ui.text(c, "${i + 1}", 120f, y + (if (i < 3) 80f else 65f), 44f, if (i < 3) 0xFF4E342E.toInt() else 0xFFFFFFFF.toInt(), outline = if (i < 3) 0xFFFFF59D.toInt() else Ui.OUTLINE)
                        Art.avatar(c, 230f, y + 65f, 46f, f["avatar"].int())
                        Ui.text(c, f["name"].str(), 300f, y + 46f, 40f, align = Paint.Align.LEFT, maxW = 480f)
                        Ui.text(c, "Vila ${f["village"].int()} · ${f["progress"].int() * 4}%", 300f, y + 94f, 30f, 0xFFD1C4E9.toInt(), align = Paint.Align.LEFT, ow = 4f)
                        y += 144f
                    }
                }
            }
        }
        maxScroll = maxOf(0f, y + scroll - (top + 1540f))
        c.restoreToCount(save)
        if (tab == 2 && board != null) Ui.text(c, "Sua posição: #${board!!["myRank"].int()}", g.W / 2, top + 1560f, 40f, 0xFFFFEB3B.toInt())
        xBtn.draw(c)
        c.restoreToCount(sc)
    }

    private fun row(c: Canvas, y: Float, avatar: Int, name: String, sub: String, dot: Int) {
        Ui.panel(c, 60f, y, g.W - 60f, y + 132f, 0xFF311B92.toInt(), 30f, bw = 5f, gloss = false)
        Art.avatar(c, 140f, y + 66f, 48f, avatar)
        if (dot != 0) { Ui.p.shader = null; Ui.p.color = dot; c.drawCircle(176f, y + 104f, 14f, Ui.p) }
        Ui.text(c, name, 210f, y + 46f, 40f, align = Paint.Align.LEFT, maxW = 480f)
        Ui.text(c, sub, 210f, y + 96f, 28f, 0xFFD1C4E9.toInt(), align = Paint.Align.LEFT, maxW = 480f, ow = 4f)
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (xBtn.touch(type, x, y, g)) return
        if (add.touch(type, x, y, g) || share.touch(type, x, y, g) || collect.touch(type, x, y, g) || giftAll.touch(type, x, y, g)) return
        if (type == Game.UP) {
            val tb = UiX.tabAt(x, y, 60f, top + 285f, g.W - 60f, 80f, tabs.size)
            if (tb >= 0) { if (tb != tab) { tab = tb; scroll = 0f; g.audio.play("click"); if (tab == 2 && board == null) loadBoard() }; return }
        }
        when (type) {
            Game.DOWN -> { dragY = y; dragStart = scroll; moved = false }
            Game.MOVE -> if (dragY >= 0) { if (Math.abs(y - dragY) > 20f) moved = true; if (moved) scroll = (dragStart - (y - dragY)).coerceIn(0f, maxScroll) }
            Game.UP -> {
                dragY = -1f
                if (moved) return
                val hit = rows.firstOrNull { it.first.contains(x, y) } ?: return
                g.audio.play("click")
                when (hit.second) {
                    0 -> g.net.call("POST", "/api/friends/gift", mapOf("id" to hit.third)) { r -> if (r.ok) { g.audio.play("pop"); g.toast(Game.T_GIFT, "Presente enviado!", "Seu amigo vai ganhar 2 giros"); load() } else g.error(r) }
                    1, 2 -> g.net.call("POST", "/api/friends/respond", mapOf("id" to hit.third, "accept" to (hit.second == 1))) { r -> if (r.ok) load() else g.error(r) }
                }
            }
        }
    }
}

/** Daily missions + streak. */
class MissionsPopup(g: Game) : Popup(g), HudOnTop {
    private var top = 0f
    private val xBtn = CloseBtn { close() }
    private val claimRects = ArrayList<Pair<RectF, Any>>()
    private var busy = false
    override fun layout() { top = (g.H - 1500f) / 2 + 40f; xBtn.x = g.W - 80f; xBtn.y = top - 20f }

    private fun claim(id: Any, x: Float, y: Float) {
        if (busy) return
        busy = true
        g.net.call("POST", "/api/missions/claim", mapOf("id" to id)) { r ->
            busy = false
            if (r.ok) { g.celebrate(r.j["result"]["got"], x, y); g.audio.play("win") } else g.error(r)
        }
    }

    override fun draw(c: Canvas) {
        val pr = g.prof ?: return
        val sc = begin(c, 30f, top - 70f, g.W - 30f, top + 1440f, 0xFF00695C.toInt())
        ribbon(c, g.W / 2, top - 40f, 500f, "MISSÕES", 0xFF00897B.toInt())
        Ui.text(c, "Sequência de ${pr.streak} dia(s) seguidos", g.W / 2, top + 60f, 44f, 0xFFFFCC80.toInt())
        Ui.text(c, "Novas missões em " + Fmt.clock(pr.missionsResetMs - (System.currentTimeMillis() - pr.receivedAt)), g.W / 2, top + 115f, 32f, 0xFFB2DFDB.toInt(), ow = 4f)
        claimRects.clear()
        for ((i, m) in pr.missions.withIndex()) {
            val y = top + 170f + i * 300f
            Ui.panel(c, 70f, y, g.W - 70f, y + 270f, if (m.claimed) 0xFF2E7D32.toInt() else 0xFF004D40.toInt(), 34f, bw = 6f)
            Art.iconScroll(c, 160f, y + 100f, 110f)
            Ui.text(c, m.label, 240f, y + 60f, 40f, align = Paint.Align.LEFT, maxW = g.W - 340f)
            Ui.bar(c, 240f, y + 100f, g.W - 120f, y + 150f, m.progress.toFloat() / m.target, 0xFF69F0AE.toInt(), 0xFF00C853.toInt())
            Ui.text(c, "${m.progress}/${m.target}", (240f + g.W - 120f) / 2, y + 125f, 32f)
            UiX.rewards(c, m.reward, 380f, y + 215f, 40f)
            val rb = RectF(g.W - 380f, y + 175f, g.W - 100f, y + 250f)
            when {
                m.claimed -> Ui.text(c, "COLETADO ✔", rb.centerX(), rb.centerY(), 36f, 0xFFB9F6CA.toInt())
                m.done -> { Ui.panel(c, rb.left, rb.top, rb.right, rb.bottom, 0xFFFB8C00.toInt(), 36f, bw = 5f); Ui.text(c, "COLETAR", rb.centerX(), rb.centerY(), 38f); claimRects.add(rb to m.id) }
                else -> Ui.text(c, "em andamento", rb.centerX(), rb.centerY(), 30f, 0xFFB2DFDB.toInt(), ow = 4f)
            }
        }
        // bonus chest
        val y = top + 1090f
        val allDone = pr.missions.isNotEmpty() && pr.missions.all { it.claimed }
        Ui.panel(c, 70f, y, g.W - 70f, y + 300f, if (pr.missionsBonusClaimed) 0xFF2E7D32.toInt() else 0xFF6A1B9A.toInt(), 34f, bw = 6f)
        Art.chest(c, 200f, y + 170f, 0.75f, if (allDone && !pr.missionsBonusClaimed) 0.4f + 0.2f * sin(g.time * 5f) else 0f, 2)
        Ui.text(c, "Baú das 3 missões", 330f, y + 70f, 42f, align = Paint.Align.LEFT, gold = true)
        UiX.rewards(c, g.prof?.j?.get("allMissionsBonus") ?: J(null), 520f, y + 150f, 44f)
        val rb = RectF(330f, y + 200f, g.W - 110f, y + 275f)
        when {
            pr.missionsBonusClaimed -> Ui.text(c, "COLETADO ✔", rb.centerX(), rb.centerY(), 36f, 0xFFB9F6CA.toInt())
            allDone -> { Ui.panel(c, rb.left, rb.top, rb.right, rb.bottom, 0xFFFB8C00.toInt(), 36f, bw = 5f); Ui.text(c, "ABRIR BAÚ!", rb.centerX(), rb.centerY(), 40f); claimRects.add(rb to "all") }
            else -> Ui.text(c, "Complete e colete as 3 missões", rb.centerX(), rb.centerY(), 30f, 0xFFE1BEE7.toInt(), ow = 4f)
        }
        xBtn.draw(c)
        c.restoreToCount(sc)
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (xBtn.touch(type, x, y, g)) return
        if (type != Game.UP) return
        claimRects.firstOrNull { it.first.contains(x, y) }?.let { g.audio.play("click"); claim(it.second, it.first.centerX(), it.first.centerY()) }
    }
}

/** Pets: unlock, feed with treats, choose the active one. */
class PetsPopup(g: Game) : Popup(g), HudOnTop {
    private var top = 0f
    private val xBtn = CloseBtn { close() }
    private val keys = listOf("quati", "onca", "tucano")
    private val btnRects = ArrayList<Triple<RectF, Int, String>>() // 0 unlock, 1 feed, 2 select, 3 buy treats
    private var busy = false
    private var happy = -1f; private var happyKey = ""
    private var tipped = false
    override fun layout() { top = (g.H - 1560f) / 2 + 40f; xBtn.x = g.W - 80f; xBtn.y = top - 20f }
    override fun update(dt: Float) { super.update(dt); if (happy >= 0f) happy += dt; if (!tipped && t > 0.4f) { tipped = true; Tips.show(g, "pets") } }

    override fun draw(c: Canvas) {
        val pr = g.prof ?: return
        val sc = begin(c, 30f, top - 70f, g.W - 30f, top + 1500f, 0xFF5D4037.toInt())
        ribbon(c, g.W / 2, top - 40f, 420f, "PETS", 0xFFF57C00.toInt())
        btnRects.clear()
        Ui.pill(c, 80f, top + 30f, 560f, top + 110f, 0x66000000)
        Art.iconPetisco(c, 140f, top + 70f, 90f)
        Ui.text(c, "${pr.petiscos} petisco(s)", 200f, top + 70f, 40f, align = Paint.Align.LEFT)
        val bt = RectF(600f, top + 30f, g.W - 80f, top + 110f)
        Ui.panel(c, bt.left, bt.top, bt.right, bt.bottom, 0xFF00897B.toInt(), 40f, bw = 5f); Ui.text(c, "+ PETISCOS", bt.centerX(), bt.centerY(), 36f)
        btnRects.add(Triple(bt, 3, ""))
        for ((i, k) in keys.withIndex()) {
            val pet = pr.pets[k] ?: continue
            val y = top + 140f + i * 450f
            val active = pr.activePet == k
            val awake = active && pr.petAwake()
            Ui.panel(c, 60f, y, g.W - 60f, y + 425f, if (awake) 0xFF2E7D32.toInt() else if (pet.unlocked) 0xFF4E342E.toInt() else 0xFF424242.toInt(), 36f, bw = 6f)
            Art.glow(c, 210f, y + 230f, 170f, if (awake) 0xFFB9F6CA.toInt() else 0xFFFFE0B2.toInt(), 0.5f)
            val bob = if (happy >= 0f && happyKey == k && happy < 1.2f) -kotlin.math.abs(sin(happy * 12f)) * 30f else 0f
            if (pet.unlocked) Chars.pet(c, k, 210f, y + 360f + bob, 0.85f, g.time, awake)
            else { Chars.pet(c, k, 210f, y + 360f, 0.85f, 0f, false); Art.lock(c, 210f, y + 230f, 1.1f) }
            Ui.text(c, pet.name, 370f, y + 60f, 46f, align = Paint.Align.LEFT, gold = true, maxW = g.W - 460f)
            if (pet.unlocked) {
                Ui.text(c, "Nível ${pet.level}", 370f, y + 115f, 34f, align = Paint.Align.LEFT, ow = 5f)
                Ui.bar(c, 540f, y + 98f, g.W - 100f, y + 132f, pet.xp.toFloat() / maxOf(1, pet.xpNext), 0xFFFFD54F.toInt(), 0xFFFF8F00.toInt())
            }
            val bonusTxt = when (pet.role) { "attack" -> "+${(pet.bonus * 100).toInt()}% moedas nos ataques"; "raid" -> "+1 buraco e +${(pet.bonus * 100).toInt()}% nos saques"; else -> "${(pet.bonus * 100).toInt()}% de chance de bloquear ataques" }
            Ui.text(c, bonusTxt, 370f, y + 170f, 30f, 0xFFFFE0B2.toInt(), align = Paint.Align.LEFT, maxW = g.W - 450f, ow = 4f)
            val status = when { !pet.unlocked -> "Desbloqueia na vila ${pet.unlockVillage}"; awake -> "Acordado: " + Fmt.clock(pr.petAwakeLeft()); active -> "Dormindo... dê um petisco!"; else -> "Descansando" }
            Ui.text(c, status, 370f, y + 222f, 34f, if (awake) 0xFFB9F6CA.toInt() else 0xFFFFFFFF.toInt(), align = Paint.Align.LEFT, maxW = g.W - 450f, ow = 5f)
            if (!pet.unlocked) {
                val r = RectF(370f, y + 290f, g.W - 100f, y + 380f)
                Ui.panel(c, r.left, r.top, r.right, r.bottom, 0xFF00838F.toInt(), 40f, bw = 5f)
                Art.iconGem(c, r.left + 60f, r.centerY(), 60f); Ui.text(c, "DESBLOQUEAR ${pet.gemCost}", r.centerX() + 30f, r.centerY(), 36f, maxW = r.width() - 120f)
                btnRects.add(Triple(r, 0, k))
            } else {
                val rf = RectF(370f, y + 290f, if (active) g.W - 100f else 680f, y + 380f)
                Ui.panel(c, rf.left, rf.top, rf.right, rf.bottom, 0xFFFB8C00.toInt(), 40f, bw = 5f)
                Art.iconPetisco(c, rf.left + 50f, rf.centerY(), 58f); Ui.text(c, "ALIMENTAR", rf.centerX() + 34f, rf.centerY(), 32f, maxW = rf.width() - 116f)
                btnRects.add(Triple(rf, 1, k))
                if (!active) {
                    val rs = RectF(700f, y + 290f, g.W - 100f, y + 380f)
                    Ui.panel(c, rs.left, rs.top, rs.right, rs.bottom, 0xFF1E88E5.toInt(), 40f, bw = 5f); Ui.text(c, "ESCOLHER", rs.centerX(), rs.centerY(), 34f)
                    btnRects.add(Triple(rs, 2, k))
                }
            }
        }
        xBtn.draw(c)
        c.restoreToCount(sc)
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (xBtn.touch(type, x, y, g)) return
        if (type != Game.UP || busy) return
        val hit = btnRects.firstOrNull { it.first.contains(x, y) } ?: return
        g.audio.play("click")
        val pr = g.prof ?: return
        when (hit.second) {
            3 -> { close(); onClosed = { g.show(ShopPopup(g, ShopPopup.TAB_ITEMS)) } }
            0 -> { busy = true; g.net.call("POST", "/api/pets/unlock", mapOf("pet" to hit.third)) { r -> busy = false; if (r.ok) { g.audio.play("pet"); g.fx.confetti(60); happy = 0f; happyKey = hit.third } else g.error(r) } }
            1 -> {
                if (pr.petiscos < 1) { g.toast(Game.T_PET, "Sem petiscos", "Ganhe na roda, nos baús ou compre na loja!"); return }
                busy = true
                g.net.call("POST", "/api/pets/feed", mapOf("pet" to hit.third)) { r -> busy = false; if (r.ok) { g.audio.play("pet"); happy = 0f; happyKey = hit.third; g.fx.burst(210f, top + 300f, 20, P.STAR, intArrayOf(0xFFFFF59D.toInt(), -1), 700f, 18f, 0.8f, 400f) } else g.error(r) }
            }
            2 -> { busy = true; g.net.call("POST", "/api/pets/select", mapOf("pet" to hit.third)) { r -> busy = false; if (!r.ok) g.error(r) else g.audio.play("pet") } }
        }
    }
}
