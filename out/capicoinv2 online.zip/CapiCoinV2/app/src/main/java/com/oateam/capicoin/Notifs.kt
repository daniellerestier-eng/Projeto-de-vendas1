package com.oateam.capicoin

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Local notifications (spins refilled, wheel ready, pet asleep) + background check for attacks. */
object Notifs {
    const val CHANNEL = "capi_main"
    private const val REQ_SPINS = 101; private const val REQ_WHEEL = 102; private const val REQ_PET = 103

    fun channel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Capi Coin", NotificationManager.IMPORTANCE_DEFAULT)
        ch.description = "Giros cheios, ataques e presentes"
        nm.createNotificationChannel(ch)
    }

    fun show(ctx: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return
        channel(ctx)
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
    }

    private fun pending(ctx: Context, req: Int, title: String, text: String): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).putExtra("title", title).putExtra("text", text).putExtra("id", req)
        return PendingIntent.getBroadcast(ctx, req, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun scheduleLocal(ctx: Context, p: Profile?) {
        p ?: return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val have = p.spinsNow(now)
        if (have < p.maxSpins) {
            val full = now + p.msToNextSpin(now) + (p.maxSpins - have - 1).toLong() * p.regenMs
            am.set(AlarmManager.RTC_WAKEUP, full, pending(ctx, REQ_SPINS, "Giros cheios! ⚡", "Seus ${p.maxSpins} giros estão prontos. Volte e conquiste moedas!"))
        }
        if (!p.wheelReadyNow(now)) {
            val at = p.receivedAt + p.wheelResetMs + 60_000
            am.set(AlarmManager.RTC_WAKEUP, at, pending(ctx, REQ_WHEEL, "Roda da Sorte liberada! 🎡", "Gire grátis e ganhe até 150 giros!"))
        }
        if (p.petAwake(now)) {
            am.set(AlarmManager.RTC_WAKEUP, now + p.petAwakeLeft(now), pending(ctx, REQ_PET, "Seu pet dormiu 💤", "Dê um petisco para ele voltar a te ajudar!"))
        }
    }

    fun cancelLocal(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (r in intArrayOf(REQ_SPINS, REQ_WHEEL, REQ_PET)) am.cancel(pending(ctx, r, "", ""))
    }

    fun scheduleJob(ctx: Context) {
        val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        val info = JobInfo.Builder(4242, ComponentName(ctx, PollJob::class.java))
            .setPeriodic(30 * 60 * 1000L)
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .build()
        try { js.schedule(info) } catch (e: Exception) {}
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (!Settings(ctx).notifs) return
        Notifs.show(ctx, intent.getIntExtra("id", 100), intent.getStringExtra("title") ?: "Capi Coin", intent.getStringExtra("text") ?: "")
    }
}

/** Runs ~every 30 min in background: tells the player when someone attacked/raided/gifted. */
class PollJob : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val ctx = applicationContext
        val s = Settings(ctx)
        val token = s.token
        if (token == null || !s.notifs) return false
        Thread {
            val after = maxOf(s.lastNotifiedEvent, s.lastToastEvent)
            val r = Net.request("GET", s.serverUrl.trimEnd('/') + "/api/events/poll?after=$after", null, token)
            if (r.ok) {
                var maxId = after
                val attacks = ArrayList<String>()
                var gifts = 0; var friends = 0; var paid = false
                for (e in r.j["events"].list) {
                    maxId = maxOf(maxId, e["id"].long())
                    val who = e["actor"].str("Alguém")
                    when (e["type"].str()) {
                        "attack" -> attacks.add("$who atacou sua vila!")
                        "raid" -> attacks.add("$who saqueou ${Fmt.n(e["data"]["amount"].long())} moedas!")
                        "gift" -> gifts++
                        "friend_req", "friend_ok" -> friends++
                        "payment" -> paid = true
                    }
                }
                if (attacks.isNotEmpty()) Notifs.show(ctx, 201, if (attacks.size == 1) "Sua ilha foi atacada! 🔨" else "${attacks.size} ataques na sua ilha! 🔨", attacks.take(3).joinToString("\n") + "\nVolte para se vingar!")
                if (gifts > 0) Notifs.show(ctx, 202, "Você ganhou presentes! 🎁", "$gifts amigo(s) te mandaram giros.")
                if (friends > 0) Notifs.show(ctx, 203, "Novidades de amizade", "Você tem novos pedidos ou amigos no Capi Coin.")
                if (paid) Notifs.show(ctx, 204, "Pagamento aprovado! ✅", "Seus itens já estão na sua conta.")
                s.lastNotifiedEvent = maxId
            }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}
