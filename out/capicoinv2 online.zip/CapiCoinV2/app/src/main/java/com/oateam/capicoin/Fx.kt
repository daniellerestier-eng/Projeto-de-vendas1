package com.oateam.capicoin

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

object Ease {
    fun outBack(t: Float): Float { val c1 = 1.70158f; val c3 = c1 + 1; val x = t - 1; return 1 + c3 * x * x * x + c1 * x * x }
    fun outCubic(t: Float) = 1 - (1 - t).pow(3)
    fun inCubic(t: Float) = t * t * t
    fun inOutQuad(t: Float) = if (t < .5f) 2 * t * t else 1 - (-2 * t + 2).pow(2) / 2
    fun outElastic(t: Float): Float {
        if (t <= 0f) return 0f; if (t >= 1f) return 1f
        val c4 = (2 * PI / 3).toFloat()
        return 2f.pow(-10 * t) * sin((t * 10 - 0.75f) * c4) + 1
    }
    fun outBounce(t0: Float): Float {
        var t = t0; val n1 = 7.5625f; val d1 = 2.75f
        return if (t < 1 / d1) n1 * t * t
        else if (t < 2 / d1) { t -= 1.5f / d1; n1 * t * t + 0.75f }
        else if (t < 2.5 / d1) { t -= 2.25f / d1; n1 * t * t + 0.9375f }
        else { t -= 2.625f / d1; n1 * t * t + 0.984375f }
    }
}

fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x
fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
fun rnd(a: Float, b: Float) = a + Random.nextFloat() * (b - a)

object P {   // particle types
    const val SPARK = 0; const val COIN = 1; const val DUST = 2; const val STAR = 3; const val CONFETTI = 4
    const val DEBRIS = 5; const val SMOKE = 6; const val EMBER = 7; const val SNOW = 8; const val BUBBLE = 9; const val LEAF = 10
}

class Particle {
    var x = 0f; var y = 0f; var vx = 0f; var vy = 0f
    var life = 0f; var max = 1f; var size = 10f; var color = -1
    var type = 0; var rot = 0f; var vrot = 0f; var grav = 0f; var drag = 0.98f; var grow = 0f
}

class FlyCoin(val x0: Float, val y0: Float, val cx: Float, val cy: Float, val x1: Float, val y1: Float, var delay: Float, val dur: Float, val onArrive: (() -> Unit)?) {
    var t = 0f; var done = false
}

class FText(val text: String, var x: Float, var y: Float, val color: Int, val size: Float, val life: Float) {
    var t = 0f
}

class Fx(private val g: Game) {
    val parts = ArrayList<Particle>()
    private val pool = ArrayList<Particle>()
    val coins = ArrayList<FlyCoin>()
    val texts = ArrayList<FText>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    fun spawn(type: Int, x: Float, y: Float, vx: Float, vy: Float, life: Float, size: Float, color: Int, grav: Float = 0f): Particle {
        val q = if (pool.isEmpty()) Particle() else pool.removeAt(pool.size - 1)
        q.type = type; q.x = x; q.y = y; q.vx = vx; q.vy = vy; q.life = life; q.max = life
        q.size = size; q.color = color; q.grav = grav; q.rot = rnd(0f, 360f); q.vrot = rnd(-360f, 360f)
        q.drag = 0.985f; q.grow = 0f
        if (parts.size < 900) parts.add(q)
        return q
    }

    fun burst(x: Float, y: Float, n: Int, type: Int, colors: IntArray, speed: Float = 900f, size: Float = 14f, life: Float = 1f, grav: Float = 1400f) {
        for (i in 0 until n) {
            val a = rnd(0f, (2 * PI).toFloat())
            val s = rnd(0.25f, 1f) * speed
            spawn(type, x, y, cos(a) * s, sin(a) * s - speed * 0.3f, rnd(0.6f, 1f) * life, rnd(0.6f, 1.3f) * size, colors[Random.nextInt(colors.size)], grav)
        }
    }

    fun confetti(n: Int) {
        val cols = intArrayOf(0xFFFF5252.toInt(), 0xFFFFD740.toInt(), 0xFF69F0AE.toInt(), 0xFF40C4FF.toInt(), 0xFFE040FB.toInt(), 0xFFFFAB40.toInt())
        for (i in 0 until n) {
            val q = spawn(P.CONFETTI, rnd(0f, g.W), rnd(-300f, -20f), rnd(-120f, 120f), rnd(200f, 600f), rnd(2.5f, 4.5f), rnd(14f, 26f), cols[Random.nextInt(cols.size)], 260f)
            q.drag = 0.995f
        }
    }

    fun dust(x: Float, y: Float, n: Int, color: Int = 0xFFD7CCC8.toInt(), spread: Float = 160f) {
        for (i in 0 until n) {
            val q = spawn(P.SMOKE, x + rnd(-spread, spread), y + rnd(-30f, 10f), rnd(-160f, 160f), rnd(-260f, -60f), rnd(0.7f, 1.3f), rnd(30f, 60f), color, 0f)
            q.grow = 60f; q.drag = 0.95f
        }
    }

    /** Coins flying from (x0,y0) to (x1,y1) along curved paths. */
    fun coinRain(x0: Float, y0: Float, x1: Float, y1: Float, n: Int, onEach: (() -> Unit)? = null) {
        for (i in 0 until n) {
            val sx = x0 + rnd(-60f, 60f); val sy = y0 + rnd(-40f, 40f)
            val cx = lerp(sx, x1, 0.3f) + rnd(-380f, 380f)
            val cy = minOf(sy, y1) - rnd(100f, 500f)
            coins.add(FlyCoin(sx, sy, cx, cy, x1, y1, i * 0.035f + rnd(0f, 0.05f), rnd(0.55f, 0.8f), onEach))
        }
    }

    fun text(s: String, x: Float, y: Float, color: Int = 0xFFFFEB3B.toInt(), size: Float = 72f, life: Float = 1.3f) {
        texts.add(FText(s, x, y, color, size, life))
    }

    fun clear() { parts.clear(); coins.clear(); texts.clear() }

    fun update(dt: Float) {
        var i = parts.size - 1
        while (i >= 0) {
            val q = parts[i]
            q.life -= dt
            if (q.life <= 0f) { parts.removeAt(i); pool.add(q); i--; continue }
            q.vy += q.grav * dt
            q.vx *= q.drag; q.vy *= q.drag
            q.x += q.vx * dt; q.y += q.vy * dt
            q.rot += q.vrot * dt
            q.size += q.grow * dt
            if (q.type == P.CONFETTI || q.type == P.LEAF || q.type == P.SNOW) q.x += sin(q.life * 4f + q.rot * 0.01f) * 60f * dt
            i--
        }
        var j = coins.size - 1
        while (j >= 0) {
            val c = coins[j]
            if (c.delay > 0f) c.delay -= dt else {
                c.t += dt / c.dur
                if (c.t >= 1f) {
                    c.done = true; coins.removeAt(j)
                    c.onArrive?.invoke()
                }
            }
            j--
        }
        var k = texts.size - 1
        while (k >= 0) {
            val t = texts[k]
            t.t += dt; t.y -= 90f * dt
            if (t.t >= t.life) texts.removeAt(k)
            k--
        }
    }

    fun draw(c: Canvas) {
        for (q in parts) drawParticle(c, q)
        for (fc in coins) {
            if (fc.delay > 0f) continue
            val t = Ease.inOutQuad(clamp01(fc.t))
            val u = 1 - t
            val x = u * u * fc.x0 + 2 * u * t * fc.cx + t * t * fc.x1
            val y = u * u * fc.y0 + 2 * u * t * fc.cy + t * t * fc.y1
            val s = 34f * (1.15f - 0.45f * t)
            Art.coinSpin(c, x, y, s, g.time * 9f + fc.x0)
        }
        for (t in texts) {
            val a = clamp01((t.life - t.t) / 0.35f)
            val sc = if (t.t < 0.25f) Ease.outBack(t.t / 0.25f) else 1f
            Ui.text(c, t.text, t.x, t.y, t.size * sc, t.color, alpha = a)
        }
    }

    private fun drawParticle(c: Canvas, q: Particle) {
        val a = clamp01(q.life / q.max)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = q.color
        when (q.type) {
            P.SPARK, P.EMBER -> {
                p.alpha = (255 * a).toInt()
                c.drawCircle(q.x, q.y, q.size * (0.4f + 0.6f * a), p)
                p.alpha = (70 * a).toInt()
                c.drawCircle(q.x, q.y, q.size * 2f * a, p)
            }
            P.STAR -> {
                p.alpha = (255 * a).toInt()
                star4(c, q.x, q.y, q.size * (0.5f + a), q.rot)
            }
            P.COIN -> Art.coinSpin(c, q.x, q.y, q.size, q.rot * 0.05f)
            P.CONFETTI -> {
                p.alpha = (255 * clamp01(q.life)).toInt()
                c.save(); c.translate(q.x, q.y); c.rotate(q.rot)
                val w = q.size * (0.3f + 0.7f * kotlin.math.abs(sin(q.rot * 0.05f)))
                c.drawRect(-w / 2, -q.size * 0.3f, w / 2, q.size * 0.3f, p)
                c.restore()
            }
            P.DEBRIS -> {
                p.alpha = (255 * clamp01(a * 2)).toInt()
                c.save(); c.translate(q.x, q.y); c.rotate(q.rot)
                c.drawRect(-q.size / 2, -q.size / 3, q.size / 2, q.size / 3, p)
                c.restore()
            }
            P.SMOKE, P.DUST -> {
                p.alpha = (150 * a * a).toInt()
                c.drawCircle(q.x, q.y, q.size, p)
            }
            P.SNOW -> {
                p.alpha = (230 * clamp01(q.life)).toInt()
                c.drawCircle(q.x, q.y, q.size, p)
            }
            P.BUBBLE -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f
                p.alpha = (200 * clamp01(q.life)).toInt()
                c.drawCircle(q.x, q.y, q.size, p)
                p.style = Paint.Style.FILL; p.color = -1; p.alpha = (160 * clamp01(q.life)).toInt()
                c.drawCircle(q.x - q.size * 0.35f, q.y - q.size * 0.35f, q.size * 0.2f, p)
            }
            P.LEAF -> {
                p.alpha = (255 * clamp01(q.life)).toInt()
                c.save(); c.translate(q.x, q.y); c.rotate(q.rot)
                c.drawOval(-q.size, -q.size * 0.45f, q.size, q.size * 0.45f, p)
                c.restore()
            }
        }
        p.alpha = 255
    }

    fun star4(c: Canvas, x: Float, y: Float, r: Float, rot: Float) {
        c.save(); c.translate(x, y); c.rotate(rot)
        path.reset()
        path.moveTo(0f, -r); path.quadTo(0f, 0f, r, 0f); path.quadTo(0f, 0f, 0f, r)
        path.quadTo(0f, 0f, -r, 0f); path.quadTo(0f, 0f, 0f, -r); path.close()
        c.drawPath(path, p)
        c.restore()
    }
}
