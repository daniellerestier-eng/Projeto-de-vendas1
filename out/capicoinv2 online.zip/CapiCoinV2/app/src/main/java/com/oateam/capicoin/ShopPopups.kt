package com.oateam.capicoin

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.sin

/** Shop with real-money (PIX), gem and coin items. */
class ShopPopup(g: Game, private var tab: Int = TAB_OFFERS) : Popup(g), HudOnTop {
    companion object { const val TAB_OFFERS = 0; const val TAB_SPINS = 1; const val TAB_GEMS = 2; const val TAB_COINS = 3; const val TAB_ITEMS = 4 }
    private class Item(val kind: Int, val j: J) { // kind 0 = R$ (PIX), 1 = gems, 2 = coins chest
        val id: String get() = j["id"].str()
        override fun equals(other: Any?) = other is Item && other.kind == kind && other.id == id
        override fun hashCode() = kind * 31 + id.hashCode()
    }
    private var top = 0f
    private var paid: List<J>? = null
    private var busy = false
    private val xBtn = CloseBtn { close() }
    private val tabs = listOf("OFERTAS", "GIROS", "GEMAS", "MOEDAS", "ITENS")
    private var scroll = 0f; private var dragY = -1f; private var dragStart = 0f; private var moved = false
    private val rects = ArrayList<Pair<RectF, Item>>()
    private var pressed: Item? = null

    init {
        g.net.call("GET", "/api/shop") { r -> paid = if (r.ok) r.j["items"].list else emptyList(); if (r.ok) g.paymentsOn = r.j["payments"].bool() else g.error(r) }
    }
    private var tipped = false
    override fun update(dt: Float) { super.update(dt); if (!tipped && t > 0.4f) { tipped = true; Tips.show(g, "shop") } }

    override fun layout() { top = (g.H - 1620f) / 2 + 60f; xBtn.x = g.W - 80f; xBtn.y = top - 20f }

    private fun items(): List<Item> {
        val p = paid ?: emptyList()
        val gem = g.gemShop.list
        val ch = g.chests.list
        fun paidTab(t: String) = p.filter { it["tab"].str() == t }.map { Item(0, it) }
        return when (tab) {
            TAB_OFFERS -> paidTab("ofertas") + ch.map { Item(2, it) }
            TAB_SPINS -> paidTab("giros") + gem.filter { it["icon"].str() == "spins" }.map { Item(1, it) }
            TAB_GEMS -> paidTab("gemas")
            TAB_COINS -> paidTab("moedas") + gem.filter { it["icon"].str() == "coins" }.map { Item(1, it) }
            else -> gem.filter { it["icon"].str() !in listOf("spins", "coins") }.map { Item(1, it) } + ch.map { Item(2, it) }
        }
    }

    private fun buy(it: Item) {
        if (busy) return
        when (it.kind) {
            0 -> {
                if (!g.paymentsOn) { g.toast(Game.T_INFO, "Pagamentos desligados", "Configure o MP_ACCESS_TOKEN no servidor."); return }
                busy = true
                g.net.call("POST", "/api/pay/pix", mapOf("itemId" to it.id)) { r ->
                    busy = false
                    if (r.ok) g.show(PixPopup(g, r.j["order"], it.j)) else g.error(r)
                }
            }
            1 -> {
                val pr = g.prof ?: return
                if (pr.gems < it.j["gems"].int()) { g.audio.play("tick"); g.toast(Game.T_INFO, "Gemas insuficientes", "Compre gemas na aba GEMAS."); tab = TAB_GEMS; scroll = 0f; return }
                busy = true
                g.net.call("POST", "/api/gems/buy", mapOf("id" to it.id)) { r ->
                    busy = false
                    if (r.ok) { g.audio.play("chest"); g.show(ChestOpenPopup(g, if (it.j["icon"].str() == "chest") 2 else 1, r.j["result"]["got"])) } else g.error(r)
                }
            }
            else -> {
                val pr = g.prof ?: return
                if (pr.coins < it.j["price"].long()) { g.audio.play("tick"); g.toast(Game.T_INFO, "Moedas insuficientes", "Gire mais ou compre moedas!"); return }
                busy = true
                g.net.call("POST", "/api/chest/buy", mapOf("kind" to it.j["id"].int())) { r ->
                    busy = false
                    if (r.ok) g.show(ChestOpenPopup(g, it.j["id"].int(), r.j["result"]["got"])) else g.error(r)
                }
            }
        }
    }

    override fun draw(c: Canvas) {
        val sc = begin(c, 24f, top - 70f, g.W - 24f, top + 1560f, 0xFF4A148C.toInt())
        ribbon(c, g.W / 2, top - 40f, 420f, "LOJA", 0xFFE53935.toInt())
        UiX.tabs(c, 50f, top + 40f, g.W - 50f, 90f, tabs, tab)
        val list = items()
        val save = c.save()
        val clipTop = top + 150f; val clipBot = top + 1530f
        c.clipRect(40f, clipTop, g.W - 40f, clipBot)
        rects.clear()
        if (paid == null) UiX.spinner(c, g.W / 2, top + 600f, 50f, g.time)
        val colW = (g.W - 120f) / 2
        var y = clipTop + 14f - scroll
        var col = 0
        for (it in list) {
            val wide = it.kind == 0 && tab == TAB_OFFERS
            if (wide && col == 1) { col = 0; y += 384f }
            val l = if (wide) 50f else 50f + col * (colW + 20f)
            val w = if (wide) g.W - 100f else colW
            val h = if (wide) 360f else 430f
            val rc = RectF(l, y, l + w, y + h)
            rects.add(rc to it)
            if (y + h > clipTop && y < clipBot) card(c, rc, it, wide)
            if (wide) { y += h + 24f; col = 0 } else { col++; if (col == 2) { col = 0; y += h + 24f } }
        }
        if (col == 1) y += 454f
        maxScroll = maxOf(0f, y + scroll - clipBot)
        if (list.isEmpty() && paid != null) Ui.text(c, if (tab == TAB_GEMS && !g.paymentsOn) "Pagamentos ainda não ativados no servidor" else "Nada por aqui agora", g.W / 2, top + 600f, 40f, maxW = g.W - 200f)
        c.restoreToCount(save)
        Ui.text(c, "Pagamento seguro via PIX · crédito na hora", g.W / 2, top + 1546f, 28f, 0xFFB2DFDB.toInt(), ow = 4f)
        xBtn.draw(c)
        c.restoreToCount(sc)
    }
    private var maxScroll = 0f

    private fun card(c: Canvas, rc: RectF, it: Item, wide: Boolean) {
        val j = it.j
        val pr = pressed == it
        val base = when (it.kind) { 0 -> if (wide) 0xFFD81B60.toInt() else 0xFF283593.toInt(); 1 -> 0xFF00695C.toInt(); else -> 0xFF5D4037.toInt() }
        c.save(); if (pr) c.scale(0.96f, 0.96f, rc.centerX(), rc.centerY())
        Ui.panel(c, rc.left, rc.top, rc.right, rc.bottom, base, 34f, bw = 6f)
        val icon = j["icon"].str()
        val ix = if (wide) rc.left + 170f else rc.centerX()
        val iy = if (wide) rc.centerY() - 10f else rc.top + 130f
        Art.glow(c, ix, iy, 140f, 0xFFFFF59D.toInt(), 0.5f + 0.15f * sin(g.time * 3f))
        val give = j["give"]
        when (icon) {
            "spins" -> { val n = minOf(4, 1 + give["spins"].int() / 150); for (k in 0 until n) Art.capsule(c, ix - (n - 1) * 26f + k * 52f, iy, 0.55f) }
            "gems" -> { val n = minOf(5, 1 + give["gems"].int() / 300); for (k in 0 until n) Art.iconGem(c, ix - (n - 1) * 24f + k * 48f, iy + (if (k % 2 == 0) 10f else -14f), 110f) }
            "coins" -> { if (give["coins"].long() > 1_000_000 || it.kind == 0) Art.chest(c, ix, iy + 20f, 0.7f, 0.7f, 1) else Art.symbol(c, Sym.BAG, ix, iy, 180f); Art.coin(c, ix - 70f, iy + 50f, 30f); Art.coin(c, ix + 74f, iy + 46f, 28f) }
            "petisco" -> Art.iconPetisco(c, ix, iy, 190f)
            "shield" -> Art.shield(c, ix, iy, 0.75f, 0xFF1E88E5.toInt(), true)
            "starter" -> { Art.chest(c, ix, iy + 30f, 0.75f, 0.8f, 2); Art.capsule(c, ix - 90f, iy - 50f, 0.45f); Art.iconGem(c, ix + 90f, iy - 50f, 90f) }
            "chest" -> Art.chest(c, ix, iy + 24f, 0.8f, 0.5f + 0.2f * sin(g.time * 3f), 2)
            else -> Art.chest(c, ix, iy + 24f, 0.8f, 0f, j["id"].int())
        }
        val title = j["title"].str(j["name"].str())
        if (wide) {
            Ui.text(c, title, rc.left + 340f, rc.top + 70f, 52f, align = Paint.Align.LEFT, gold = true, maxW = rc.width() - 380f)
            j["desc"].strOrNull()?.let { d -> for ((n, line) in wrapText(d, 34f, rc.width() - 380f).take(2).withIndex()) Ui.text(c, line, rc.left + 340f, rc.top + 135f + n * 44f, 34f, align = Paint.Align.LEFT, ow = 5f) }
        } else {
            Ui.text(c, title, rc.centerX(), rc.top + 248f, 40f, maxW = rc.width() - 30f)
            if (it.kind != 0) UiX.rewards(c, give, rc.centerX(), rc.top + 296f, 32f)
        }
        // price button
        val bh = 80f
        val bl = if (wide) rc.left + 340f else rc.left + 26f
        val br = rc.right - 26f
        val bt = rc.bottom - bh - 22f
        when (it.kind) {
            0 -> { Ui.panel(c, bl, bt, br, bt + bh, 0xFF2E7D32.toInt(), 40f, bw = 5f); Art.iconPix(c, bl + 50f, bt + bh / 2, 46f, -1); Ui.text(c, Fmt.brl(j["price"].int()), (bl + br) / 2 + 24f, bt + bh / 2, 44f, maxW = br - bl - 110f) }
            1 -> { Ui.panel(c, bl, bt, br, bt + bh, 0xFF00838F.toInt(), 40f, bw = 5f); Art.iconGem(c, bl + 50f, bt + bh / 2, 60f); Ui.text(c, j["gems"].int().toString(), (bl + br) / 2 + 24f, bt + bh / 2, 44f) }
            else -> { Ui.panel(c, bl, bt, br, bt + bh, 0xFFF9A825.toInt(), 40f, bw = 5f); Art.coin(c, bl + 50f, bt + bh / 2, 24f); Ui.text(c, Fmt.n(j["price"].long()), (bl + br) / 2 + 24f, bt + bh / 2, 42f, maxW = br - bl - 110f) }
        }
        j["tag"].strOrNull()?.let { tag ->
            c.save(); c.rotate(-8f, rc.left + 90f, rc.top + 20f)
            Ui.panel(c, rc.left - 6f, rc.top - 14f, rc.left + Ui.measure(tag, 30f) + 46f, rc.top + 46f, 0xFFFFC107.toInt(), 20f, bw = 5f)
            Ui.text(c, tag, rc.left + 20f, rc.top + 16f, 30f, 0xFF4E342E.toInt(), align = Paint.Align.LEFT, outline = 0xFFFFF59D.toInt(), ow = 3f)
            c.restore()
        }
        c.restore()
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (xBtn.touch(type, x, y, g)) return
        if (type == Game.UP) {
            val tb = UiX.tabAt(x, y, 50f, top + 40f, g.W - 50f, 90f, tabs.size)
            if (tb >= 0) { if (tb != tab) { tab = tb; scroll = 0f; g.audio.play("click") }; return }
        }
        when (type) {
            Game.DOWN -> { dragY = y; dragStart = scroll; moved = false; pressed = rects.firstOrNull { it.first.contains(x, y) && y > top + 150f }?.second }
            Game.MOVE -> if (dragY >= 0) { if (Math.abs(y - dragY) > 20f) { moved = true; pressed = null }; if (moved) scroll = (dragStart - (y - dragY)).coerceIn(0f, maxScroll) }
            Game.UP -> {
                val p = pressed
                if (!moved && p != null && rects.any { it.second == p && it.first.contains(x, y) }) { g.audio.play("click"); buy(p) }
                pressed = null; dragY = -1f
            }
        }
    }
}

/** Opening animation for chests / gem purchases. */
class ChestOpenPopup(g: Game, private val kind: Int, private val got: J) : Popup(g), HudOnTop {
    private var top = 0f
    private var rewarded = false
    private val ok = Button(0f, 0f, 0f, 0f, "OBA!", 0xFF43A047.toInt()) { close() }
    init { onClosed = null; g.audio.play("chest") }
    override fun layout() { top = (g.H - 1100f) / 2; ok.set(g.W / 2 - 200f, top + 880f, 400f, 140f) }
    override fun update(dt: Float) {
        super.update(dt)
        if (t >= 1f && !rewarded) {
            rewarded = true
            g.celebrate(got, g.W / 2, top + 400f)
            g.audio.play("win"); g.audio.vibrate(100, 180)
            g.fx.burst(g.W / 2, top + 400f, 40, P.STAR, intArrayOf(0xFFFFF59D.toInt(), 0xFFE1BEE7.toInt(), -1), 1200f, 24f, 1.2f, 700f)
        }
    }
    override fun draw(c: Canvas) {
        Ui.dim(c, g.W, g.H, dimAlpha())
        val k = k()
        c.save(); c.scale(k, k, g.W / 2, top + 500f)
        val cx = g.W / 2; val cy = top + 480f
        val shakeA = if (t < 0.8f) sin(t * 70f) * 10f * (t / 0.8f) else 0f
        val open = clamp01((t - 0.8f) / 0.3f)
        if (open > 0f) Art.rays(c, cx, cy - 80f, 750f, g.time * 2f, if (kind == 2) 0xFFE1BEE7.toInt() else 0xFFFFF59D.toInt(), 18, open)
        c.save(); c.rotate(shakeA, cx, cy); Art.chest(c, cx, cy, 2f, open, kind); c.restore()
        if (rewarded) {
            val rk = Ease.outBack(clamp01((t - 1f) / 0.4f))
            c.save(); c.scale(rk, rk, cx, cy - 330f)
            UiX.rewards(c, got, cx, cy - 330f, 80f)
            c.restore()
            ok.draw(c, g.time)
        }
        c.restore()
    }
    override fun touch(type: Int, x: Float, y: Float) { if (rewarded) ok.touch(type, x, y, g) }
    override fun back(): Boolean { if (rewarded) close(); return true }
}

/** PIX payment: QR code + copia e cola, polls the server until credited. */
class PixPopup(g: Game, private var order: J, private val item: J) : Popup(g), HudOnTop {
    private var top = 0f
    private var qr: Bitmap? = null
    private var pollT = 2f
    private var polling = false
    private var credited = false
    private var creditedT = 0f
    private var status = order["status"].str("pending")
    private val dst = RectF()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val xBtn = CloseBtn { close() }
    private val copy = Button(0f, 0f, 0f, 0f, "COPIAR CÓDIGO PIX", 0xFF00897B.toInt()) {
        val code = order["qr"].str()
        if (code.isNotEmpty()) { g.host.copy(code); g.toast(Game.T_PAY, "Código copiado!", "Cole no app do seu banco: PIX > Copia e Cola") }
    }
    private val share = Button(0f, 0f, 0f, 0f, "ABRIR NO BANCO", 0xFF1E88E5.toInt()) { g.host.share(order["qr"].str()) }
    private val ok = Button(0f, 0f, 0f, 0f, "OBA!", 0xFF43A047.toInt()) { g.celebrate(item["give"], g.W / 2, top + 600f); close() }
    private val created = System.currentTimeMillis()

    init {
        dismissible = true
        try {
            val b64 = order["qrBase64"].str()
            if (b64.isNotEmpty()) qr = g.host.decodeImage(java.util.Base64.getMimeDecoder().decode(b64))
        } catch (e: Exception) { qr = null }
    }

    override fun layout() {
        top = (g.H - 1640f) / 2 + 30f
        copy.set(110f, top + 1110f, g.W - 220f, 120f); copy.textSize = 44f; copy.pulse = true
        share.set(110f, top + 1250f, g.W - 220f, 100f); share.textSize = 38f
        ok.set(g.W / 2 - 220f, top + 1250f, 440f, 140f); ok.pulse = true
        xBtn.x = g.W - 80f; xBtn.y = top - 20f
    }

    override fun update(dt: Float) {
        super.update(dt)
        if (credited) { creditedT += dt; return }
        if (status != "pending" && status != "in_process") return
        pollT -= dt
        if (pollT <= 0f && !polling) {
            polling = true; pollT = 3f
            g.net.call("GET", "/api/pay/status/" + order["orderId"].str()) { r ->
                polling = false
                if (!r.ok) return@call
                order = r.j["order"]
                status = order["status"].str("pending")
                if (order["credited"].bool()) {
                    credited = true; creditedT = 0f
                    g.audio.play("cash"); g.audio.play("jackpot", 0.7f); g.audio.vibrate(250, 255)
                    g.fx.confetti(160); g.flash = 0.6f
                }
            }
        }
    }

    override fun draw(c: Canvas) {
        val sc = begin(c, 40f, top - 70f, g.W - 40f, top + 1600f, if (credited) 0xFF1B5E20.toInt() else 0xFF004D40.toInt())
        ribbon(c, g.W / 2, top - 40f, 560f, if (credited) "APROVADO!" else "PAGAR COM PIX", if (credited) 0xFFFB8C00.toInt() else 0xFF00897B.toInt())
        val title = item["title"].str(order["title"].str())
        Ui.text(c, title, g.W / 2, top + 70f, 50f, gold = true, maxW = g.W - 160f)
        Ui.text(c, Fmt.brl(order["amount"].int()), g.W / 2, top + 150f, 80f)
        if (credited) {
            val k = Ease.outBack(clamp01(creditedT / 0.5f))
            Art.rays(c, g.W / 2, top + 600f, 700f, g.time * 2f, 0xFFFFF59D.toInt(), 18, 0.9f)
            c.save(); c.scale(k, k, g.W / 2, top + 600f)
            Art.chest(c, g.W / 2, top + 640f, 1.6f, 1f, 2)
            c.restore()
            UiX.rewards(c, item["give"], g.W / 2, top + 920f, 70f)
            Ui.text(c, "Pagamento confirmado! Obrigado!", g.W / 2, top + 1060f, 46f, 0xFFB9F6CA.toInt(), maxW = g.W - 160f)
            ok.draw(c, g.time)
        } else {
            // QR card
            val qs = 560f
            val ql = g.W / 2 - qs / 2; val qt = top + 230f
            Ui.panel(c, ql - 30f, qt - 30f, ql + qs + 30f, qt + qs + 30f, 0xFFFFFFFF.toInt(), 30f, bw = 6f, gloss = false)
            val b = qr
            if (b != null) { dst.set(ql, qt, ql + qs, qt + qs); c.drawBitmap(b, null, dst, bmpPaint) }
            else Ui.text(c, "Use o código copia e cola", g.W / 2, qt + qs / 2, 38f, 0xFF37474F.toInt(), outline = -1, ow = 0f, maxW = qs - 40f)
            val left = order["expiresAt"].long() - (System.currentTimeMillis())
            val st = when (status) { "pending", "in_process" -> null; "rejected" -> "Pagamento recusado."; "cancelled", "expired" -> "Este PIX expirou."; else -> "Status: $status" }
            if (st == null) {
                UiX.spinner(c, 170f, top + 870f, 26f, g.time)
                val dots = ".".repeat(1 + ((g.time * 2).toInt() % 3))
                Ui.text(c, "Aguardando pagamento$dots", 220f, top + 870f, 40f, align = Paint.Align.LEFT)
                if (left > 0) Ui.text(c, "Expira em " + Fmt.clock(left), g.W / 2, top + 940f, 34f, 0xFFB2DFDB.toInt(), ow = 4f)
            } else Ui.text(c, st, g.W / 2, top + 880f, 44f, 0xFFFFCDD2.toInt())
            Ui.text(c, "1. Abra o app do seu banco  2. PIX > Ler QR ou Copia e Cola", g.W / 2, top + 1010f, 30f, 0xFFE0F2F1.toInt(), maxW = g.W - 140f, ow = 4f)
            Ui.text(c, "3. Pague e volte aqui: o crédito cai na hora!", g.W / 2, top + 1055f, 30f, 0xFFE0F2F1.toInt(), maxW = g.W - 140f, ow = 4f)
            copy.draw(c, g.time)
            share.draw(c, g.time)
            xBtn.draw(c)
        }
        c.restoreToCount(sc)
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (credited) { if (creditedT > 0.6f) ok.touch(type, x, y, g); return }
        if (xBtn.touch(type, x, y, g)) return
        if (copy.touch(type, x, y, g)) return
        share.touch(type, x, y, g)
    }

    override fun back(): Boolean { if (credited) { g.celebrate(item["give"], g.W / 2, top + 600f) }; close(); return true }
}
