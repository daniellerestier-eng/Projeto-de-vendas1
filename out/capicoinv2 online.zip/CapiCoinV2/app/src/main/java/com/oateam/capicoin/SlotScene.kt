package com.oateam.capicoin

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.floor
import kotlin.math.sin
import kotlin.random.Random

/** Round side button with icon, label and badge. */
class SideBtn(var label: String, val icon: (Canvas, Float, Float, Float) -> Unit, val onClick: () -> Unit) {
    var x = 0f; var y = 0f; var r = 62f
    var visible = true; var badge: String? = null; var pulse = false; var sub: String? = null
    var color = 0xFF3949AB.toInt()
    private var pressed = false
    fun draw(c: Canvas, t: Float) {
        if (!visible) return
        val k = (if (pressed) 0.9f else 1f) * (if (pulse) 1f + 0.06f * sin(t * 5f) else 1f)
        c.save(); c.scale(k, k, x, y)
        val p = Ui.p
        p.shader = null; p.color = 0x55000000; c.drawCircle(x, y + 8f, r, p)
        p.color = -1; p.shader = RadialGradient(x - r * 0.3f, y - r * 0.4f, r * 1.5f, lighten(color, 0.35f), darken(color, 0.3f), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = 0xFFFFD54F.toInt(); c.drawCircle(x, y, r, p)
        p.strokeWidth = 4f; p.color = Ui.OUTLINE; c.drawCircle(x, y, r + 5f, p); p.style = Paint.Style.FILL
        icon(c, x, y - 4f, r * 1.25f)
        c.restore()
        Ui.text(c, label, x, y + r + 16f, 30f, ow = 6f)
        sub?.let { Ui.text(c, it, x, y + r + 50f, 26f, 0xFFFFEB3B.toInt(), ow = 5f) }
        badge?.let { Ui.badge(c, x + r * 0.75f, y - r * 0.75f, it, t) }
    }
    fun touch(type: Int, px: Float, py: Float, g: Game): Boolean {
        if (!visible) return false
        val inside = (px - x) * (px - x) + (py - y) * (py - y) < (r + 16f) * (r + 16f)
        when (type) {
            Game.DOWN -> if (inside) { pressed = true; return true }
            Game.MOVE -> if (pressed) { if (!inside) pressed = false; return true }
            Game.UP -> if (pressed) { pressed = false; if (inside) { g.audio.play("click"); g.audio.vibrate(12, 60); onClick() }; return true }
        }
        return false
    }
}

class SlotScene(g: Game) : Scene(g) {
    private val amb = Scenery.Ambience(g)
    private val r = RectF()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    // layout
    private var mTop = 0f; private var mBottom = 0f
    private var reelTop = 0f; private val cell = 150f
    private val reelW = 258f; private val reelGap = 22f
    private var reelX0 = 0f
    private var spinCx = 540f; private var spinCy = 0f; private val spinR = 120f
    private var navTop = 0f; private var energyY = 0f

    private inner class Reel(val idx: Int) {
        val strip = IntArray(30) { randomSym() }
        var pos = Random.nextInt(30).toFloat()
        var spinning = false; var stopping = false
        var from = 0f; var to = 0f; var st = 0f; var speed = 0f; var bounce = 0f
        fun sym(i: Int): Int = strip[((i % strip.size) + strip.size) % strip.size]
        fun start() { spinning = true; stopping = false; speed = 4f }
        fun stopAt(s: Int) {
            stopping = true; from = pos
            val target = floor(pos).toInt() + 3
            val n = strip.size
            strip[((target % n) + n) % n] = s
            strip[(((target - 1) % n) + n) % n] = randomSym()
            strip[(((target + 1) % n) + n) % n] = randomSym()
            to = target.toFloat(); st = 0f
        }
        fun update(dt: Float) {
            bounce = (bounce - dt * 4f).coerceAtLeast(0f)
            if (!spinning) return
            val turbo = g.settings.turbo
            if (!stopping) { speed = (speed + (if (turbo) 140f else 70f) * dt).coerceAtMost(if (turbo) 30f else 24f); pos += speed * dt }
            else {
                st += dt / (if (turbo) 0.24f else 0.42f)
                pos = lerp(from, to, Ease.outBack(clamp01(st)))
                if (st >= 1f) { pos = to; spinning = false; stopping = false; bounce = 1f; onReelStopped(idx) }
            }
            if (pos > 1e5f) { pos -= 30000f; from -= 30000f; to -= 30000f }
        }
    }

    private val reels = Array(3) { Reel(it) }
    private var spinning = false
    private var spinTime = 0f
    private val stopTimes = FloatArray(3) { 999f }
    private var outcome = IntArray(3)
    private var tension = false
    private var curBet = 1
    private var result: J? = null
    private var resProfile: J? = null
    private var failed = false
    private var localSpins = -1

    private var winFlash = 0f
    private var winRow = false
    private var lastWin = 0L
    private var mood = Art.Mood.IDLE
    private var moodT = 0f
    private var prop = 0
    private var jump = 0f
    private var auto = false
    private var autoDelay = 0f
    private var pressing = false
    private var holdT = 0f
    private var spinPress = 0f
    private var pendingAction = 0
    private var actionT = 0f
    private var spinsThisSession = 0

    private val betBtn = Button(0f, 0f, 0f, 0f, "APOSTA", 0xFF8E24AA.toInt()) { cycleBet() }
    private val autoBtn = Button(0f, 0f, 0f, 0f, "AUTO", 0xFF00897B.toInt()) { toggleAuto() }
    private val turboBtn = Button(0f, 0f, 0f, 0f, "TURBO", 0xFF455A64.toInt()) { toggleTurbo() }
    private val navVila = Button(0f, 0f, 0f, 0f, "VILA", 0xFF43A047.toInt()) { stopAuto(); g.goto(g.village) }
    private val navLoja = Button(0f, 0f, 0f, 0f, "LOJA", 0xFFE53935.toInt()) { stopAuto(); g.show(ShopPopup(g, ShopPopup.TAB_OFFERS)) }
    private val navAmigos = Button(0f, 0f, 0f, 0f, "AMIGOS", 0xFF7B1FA2.toInt()) { stopAuto(); g.show(FriendsPopup(g)) }
    private val navRank = Button(0f, 0f, 0f, 0f, "RANKING", 0xFFFB8C00.toInt()) { stopAuto(); g.show(FriendsPopup(g, 2)) }
    private val navCfg = Button(0f, 0f, 0f, 0f, "AJUSTES", 0xFF546E7A.toInt()) { stopAuto(); g.show(SettingsPopup(g)) }
    private val buttons = listOf(betBtn, autoBtn, turboBtn, navVila, navLoja, navAmigos, navRank, navCfg)

    private val sOffer = SideBtn("OFERTA", { c, x, y, s -> Art.iconGift(c, x, y, s * 0.8f) }) { stopAuto(); g.show(ShopPopup(g, ShopPopup.TAB_OFFERS)) }
    private val sWheel = SideBtn("RODA", { c, x, y, s -> Art.iconWheel(c, x, y, s * 0.8f, g.time) }) { stopAuto(); g.show(WheelPopup(g)) }
    private val sMissions = SideBtn("MISSÕES", { c, x, y, s -> Art.iconScroll(c, x, y, s * 0.8f) }) { stopAuto(); g.show(MissionsPopup(g)) }
    private val sPets = SideBtn("PETS", { c, x, y, s -> petIcon(c, x, y, s) }) { stopAuto(); g.show(PetsPopup(g)) }
    private val sides = listOf(sOffer, sWheel, sMissions, sPets)

    init {
        navVila.icon = { c, x, y, s -> Art.iconHouse(c, x, y, s) }
        navLoja.icon = { c, x, y, s -> Art.iconShop(c, x, y, s) }
        navAmigos.icon = { c, x, y, s -> Art.iconFriends(c, x, y, s) }
        navRank.icon = { c, x, y, s -> Art.iconTrophy(c, x, y, s) }
        navCfg.icon = { c, x, y, s -> Art.iconGear(c, x, y, s) }
        sOffer.color = 0xFFD81B60.toInt(); sWheel.color = 0xFFF57C00.toInt(); sMissions.color = 0xFF00897B.toInt(); sPets.color = 0xFF6D4C41.toInt()
        curBet = g.prof?.bet ?: 1
    }

    private fun petIcon(c: Canvas, x: Float, y: Float, s: Float) {
        val pr = g.prof
        val key = pr?.activePet
        if (key != null && pr.pets[key]?.unlocked == true) Chars.pet(c, key, x, y + s * 0.38f, s / 330f, g.time, pr.petAwake())
        else Art.iconPaw(c, x, y, s * 0.75f)
    }

    override fun layout() {
        val H = g.H
        mTop = maxOf(610f, H * 0.31f)
        reelTop = mTop + 62f
        mBottom = reelTop + cell * 3 + 74f
        reelX0 = (g.W - (reelW * 3 + reelGap * 2)) / 2
        navTop = H - 200f
        energyY = mBottom + 64f
        spinCy = (energyY + 50f + navTop) / 2 + 6f
        betBtn.set(40f, spinCy - 65f, 240f, 130f)
        autoBtn.set(g.W - 280f, spinCy - 65f, 240f, 130f)
        turboBtn.set(g.W - 270f, energyY - 46f, 240f, 92f); turboBtn.textSize = 36f; turboBtn.labelDx = 26f
        val nw = 196f; val gap = (g.W - nw * 5) / 6
        listOf(navVila, navLoja, navAmigos, navRank, navCfg).forEachIndexed { i, b -> b.set(gap + i * (nw + gap), navTop + 18f, nw, 150f) }
        val sy0 = 300f
        for (s in sides) s.r = 54f
        sOffer.x = 74f; sOffer.y = sy0; sWheel.x = 74f; sWheel.y = sy0 + 200f
        sMissions.x = g.W - 74f; sMissions.y = sy0; sPets.x = g.W - 74f; sPets.y = sy0 + 200f
    }

    override fun enter() {
        g.audio.startMusic()
        val p = g.prof ?: return
        curBet = p.bet
        if (!Tips.show(g, "spin")) {
            if (p.pendingAttack) { g.banner("ATAQUE PENDENTE!", "Termine seu ataque", 0xFFFF8A65.toInt()); pendingAction = 1; actionT = 1.2f }
            else if (p.pendingRaid) { g.banner("SAQUE PENDENTE!", "Termine seu saque", 0xFFFFD54F.toInt()); pendingAction = 2; actionT = 1.2f }
            else if (p.complete) g.show(VillageCompletePopup(g))
        }
    }

    private fun randomSym(): Int {
        val w = intArrayOf(30, 14, 10, 14, 10, 10, 4, 5)
        var x = Random.nextInt(w.sum())
        for (i in w.indices) { x -= w[i]; if (x < 0) return i }
        return 0
    }

    // ------------------------------------------------------------ actions
    private fun bets() = g.prof?.bets ?: listOf(1, 2, 3, 5, 10, 20, 50, 100)

    private fun cycleBet() {
        val list = bets()
        val have = g.prof?.spinsNow() ?: 1
        val i = list.indexOf(curBet)
        var n = list[(i + 1) % list.size]
        if (n > have) n = 1
        curBet = n
        g.fx.text("x$n", betBtn.x + betBtn.w / 2, betBtn.y - 30f, 0xFFE1BEE7.toInt(), 70f, 0.8f)
    }

    private fun toggleAuto() { if (auto) stopAuto() else { auto = true; autoDelay = 0f; if (!spinning) trySpin() } }
    private fun stopAuto() { auto = false }
    private fun toggleTurbo() {
        g.settings.turbo = !g.settings.turbo
        if (g.settings.turbo) { g.audio.play("turbo"); g.banner("TURBO!", "Giros super rápidos", 0xFF80DEEA.toInt(), 1.1f) }
    }

    private fun trySpin() {
        val p = g.prof ?: return
        if (spinning || pendingAction != 0) return
        if (p.pendingAttack) { pendingAction = 1; actionT = 0.2f; return }
        if (p.pendingRaid) { pendingAction = 2; actionT = 0.2f; return }
        val have = p.spinsNow()
        if (have < 1) { stopAuto(); g.show(NoSpinsPopup(g)); return }
        if (curBet > have) { var b = 1; for (x in bets()) if (x <= have) b = x; curBet = b }
        localSpins = have - curBet
        spinning = true; spinTime = 0f; result = null; resProfile = null; failed = false
        for (i in 0..2) stopTimes[i] = 999f
        tension = false
        g.profileLocked = true
        for (rl in reels) rl.start()
        winFlash = 0f; winRow = false; mood = Art.Mood.IDLE; prop = 0
        g.audio.startSpinLoop(); g.audio.vibrate(15, 80)
        spinPress = 1f
        spinsThisSession++
        if (spinsThisSession == 15) Tips.show(g, "turbo")
        g.net.call("POST", "/api/spin", mapOf("bet" to curBet), applyProfile = false) { res ->
            if (res.ok) {
                val rj = res.j["result"]
                result = rj; resProfile = res.j["profile"]
                outcome = IntArray(3) { rj["reels"][it].int() }
                curBet = rj["bet"].int(curBet)
                tension = outcome[0] == outcome[1] && outcome[0] in intArrayOf(Sym.HAMMER, Sym.RAID, Sym.CAPI, Sym.BAG, Sym.GEM)
                val turbo = g.settings.turbo
                val base = maxOf(spinTime, if (turbo) 0.22f else 0.6f)
                val step = if (turbo) 0.11f else 0.32f
                stopTimes[0] = base; stopTimes[1] = base + step; stopTimes[2] = base + step * 2 + (if (tension) (if (turbo) 0.35f else 0.9f) else 0f)
            } else {
                failed = true
                outcome = intArrayOf(Sym.COIN, Sym.SHIELD, Sym.BAG)
                stopTimes[0] = spinTime; stopTimes[1] = spinTime + 0.1f; stopTimes[2] = spinTime + 0.2f
                stopAuto(); g.error(res)
            }
        }
    }

    private fun fastStop() {
        if (result == null) return
        for (i in 0 until 3) if (!reels[i].stopping && reels[i].spinning) stopTimes[i] = minOf(stopTimes[i], spinTime + 0.05f + i * 0.08f)
    }

    private fun onReelStopped(i: Int) {
        g.audio.play("stop", 0.9f, 1f + i * 0.06f)
        g.audio.vibrate(14, 80)
        if (i == 1 && tension) { mood = Art.Mood.WOW; moodT = 2f; g.audio.play("alarm", 0.35f, 1.4f) }
        if (reels.none { it.spinning }) {
            spinning = false; g.audio.stopSpinLoop()
            g.profileLocked = false
            resProfile?.let { g.applyProfile(it) }
            if (failed) g.refreshProfile() else result?.let { evaluate(it) }
            localSpins = -1
        }
    }

    private fun evaluate(res: J) {
        val cx = g.W / 2; val cy = reelTop + cell * 1.5f
        val coins = res["coins"].long(); val spins = res["spins"].int(); val gems = res["gems"].int()
        val bet = res["bet"].int(1); val vm = res["vm"].dbl(1.0)
        val turbo = g.settings.turbo
        lastWin = coins
        if (res["triple"].bool()) {
            winRow = true; winFlash = if (turbo) 1.2f else 2f; mood = Art.Mood.HAPPY; moodT = 2.2f; jump = 1f
            when (res["sym"].int()) {
                Sym.CAPI -> {
                    g.coinsFly(coins, cx, cy, 40); g.gemsFly(gems, cx, cy)
                    g.banner("JACKPOT!", "+" + Fmt.n(coins) + " moedas", 0xFFFFEB3B.toInt(), 2.6f)
                    g.audio.play("jackpot"); g.fx.confetti(150); g.flash = 0.8f; g.shake(16f, 0.6f); g.audio.vibrate(300, 255)
                }
                Sym.ENERGY -> { g.spinsFly(spins, cx, cy); g.banner("+$spins GIROS!", "Energia extra!", 0xFFE1BEE7.toInt()); g.audio.play("win") }
                Sym.GEM -> { g.gemsFly(gems, cx, cy); g.banner("+$gems GEMAS!", "Brilhou!", 0xFF80DEEA.toInt()); g.audio.play("win"); g.fx.confetti(40) }
                Sym.SHIELD -> {
                    if (res["shield"].int() > 0) { g.shieldPulse = 1f; g.banner("ESCUDO!", "Protege sua vila de ataques", 0xFF90CAF9.toInt()); g.audio.play("shield") }
                    else bigWin(coins, bet, vm, cx, cy, "ESCUDOS CHEIOS!")
                }
                Sym.HAMMER -> {
                    pendingAction = 1; actionT = if (turbo) 0.9f else 1.5f; prop = 1
                    g.banner("ATAQUE!", "Destrua uma vila rival!", 0xFFFF8A65.toInt())
                    g.audio.play("hammer", 0.6f); g.shake(10f); g.audio.vibrate(120, 200)
                }
                Sym.RAID -> {
                    pendingAction = 2; actionT = if (turbo) 0.9f else 1.5f; prop = 2
                    g.banner("SAQUE!", "Cave o tesouro de um rival!", 0xFFFFD54F.toInt())
                    g.audio.play("dig"); g.audio.vibrate(80, 150)
                }
                else -> bigWin(coins, bet, vm, cx, cy, if (res["sym"].int() == Sym.BAG) "SACO CHEIO!" else "MOEDAS!")
            }
        } else {
            if (coins > 0) {
                g.coinsFly(coins, cx, cy, (4 + (coins / (150 * bet * vm)).toInt()).coerceIn(4, 14))
                g.fx.text("+" + Fmt.n(coins), cx, cy - 130f, 0xFFFFEB3B.toInt(), 84f)
                if (outcome.count { it == Sym.BAG } >= 2) { mood = Art.Mood.HAPPY; moodT = 1.2f }
            }
            if (spins > 0) { g.spinsFly(spins, cx, cy); g.fx.text("+$spins giros", cx, cy + 70f, 0xFFE1BEE7.toInt(), 64f) }
            if (tension) { mood = Art.Mood.SAD; moodT = 1.4f }
            else if (coins == 0L && Random.nextFloat() < 0.3f) { mood = Art.Mood.SAD; moodT = 0.8f }
        }
        autoDelay = if (pendingAction != 0) 0f else if (winRow) (if (turbo) 0.6f else 1.4f) else (if (turbo) 0.08f else 0.45f)
    }

    private fun bigWin(coins: Long, bet: Int, vm: Double, x: Float, y: Float, title: String) {
        val ratio = coins / (bet * vm * 1000.0)
        g.coinsFly(coins, x, y, if (ratio >= 8) 30 else 18)
        when {
            ratio >= 8 -> { g.banner("MEGA GANHO!", "+" + Fmt.n(coins), 0xFFFFEB3B.toInt(), 2.2f); g.audio.play("bigwin"); g.fx.confetti(110); g.shake(10f, 0.5f); g.audio.vibrate(200, 220) }
            else -> { g.banner(title, "+" + Fmt.n(coins), 0xFFFFD54F.toInt()); g.audio.play("win"); g.audio.play("coins_big", 0.7f); g.audio.vibrate(90, 180) }
        }
    }

    // ------------------------------------------------------------ loop
    override fun update(dt: Float) {
        val pr = g.prof ?: return
        amb.update(dt, pr.theme, g.W, g.H)
        if (spinning) {
            spinTime += dt
            if (result != null || failed) for (i in 0 until 3) if (reels[i].spinning && !reels[i].stopping && spinTime >= stopTimes[i]) reels[i].stopAt(outcome[i])
        }
        for (rl in reels) rl.update(dt)
        winFlash = (winFlash - dt).coerceAtLeast(0f)
        jump = (jump - dt * 1.6f).coerceAtLeast(0f)
        spinPress = (spinPress - dt * 4f).coerceAtLeast(0f)
        if (moodT > 0f) { moodT -= dt; if (moodT <= 0f) mood = Art.Mood.IDLE }
        if (pressing) {
            holdT += dt
            if (holdT > 0.6f && !auto) { auto = true; autoDelay = 0f; g.audio.play("pop"); g.audio.vibrate(40, 160); pressing = false; if (!spinning) trySpin() }
        }
        if (pendingAction != 0) {
            actionT -= dt
            if (actionT <= 0f && !g.hasPopup()) {
                val a = pendingAction; pendingAction = 0; prop = 0
                g.goto(if (a == 1) AttackScene(g) else RaidScene(g))
            }
        } else if (auto && !spinning && !g.hasPopup()) {
            autoDelay -= dt
            if (autoDelay <= 0f) trySpin()
        }
        navVila.badge = if (pr.canAffordBuild() || pr.damaged.any { it }) "!" else null; navVila.pulse = navVila.badge != null
        val social = pr.friendRequests + pr.giftsPending
        navAmigos.badge = if (social > 0) social.toString() else null
        sOffer.visible = pr.starterAvailable && g.paymentsOn
        sOffer.sub = "R$ 2,90"; sOffer.pulse = true
        sWheel.badge = if (pr.wheelReadyNow()) "!" else null; sWheel.pulse = sWheel.badge != null
        val mc = pr.missionsClaimable(); sMissions.badge = if (mc > 0) mc.toString() else null; sMissions.pulse = mc > 0
        sPets.sub = if (pr.petAwake()) Fmt.clock(pr.petAwakeLeft()) else null
        autoBtn.label = if (auto) "PARAR" else "AUTO"
        autoBtn.color = if (auto) 0xFFE53935.toInt() else 0xFF00897B.toInt()
        turboBtn.color = if (g.settings.turbo) 0xFF00ACC1.toInt() else 0xFF455A64.toInt()
        betBtn.sub = "x$curBet"
    }

    override fun draw(c: Canvas) {
        val pr = g.prof ?: return
        val th = pr.theme
        Scenery.background(c, th, g.W, g.H, g.scale)
        amb.draw(c, th, g.W, g.H, g.time)
        p.color = -1; p.shader = LinearGradient(0f, mTop - 240f, 0f, g.H, 0x00000000, 0xAA100818.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, g.W, g.H, p); p.shader = null

        val jy = -Ease.outCubic(sin(jump * Math.PI.toFloat()).coerceAtLeast(0f)) * 90f
        val swing = if (prop != 0) sin(g.time * 10f) * 25f else 0f
        Art.capi(c, g.W / 2, mTop - 66f + jy, 0.62f, g.time, mood, prop, 0, swing = swing)
        // active pet watching the machine
        val ap = pr.activePet
        if (ap != null && pr.pets[ap]?.unlocked == true) Chars.pet(c, ap, g.W / 2 + 250f, mTop - 92f, 0.42f, g.time, pr.petAwake())

        drawMachine(c, pr)
        drawEnergy(c, pr)
        drawSpinButton(c, pr)
        for (b in buttons) b.draw(c, g.time)
        Art.iconTurbo(c, turboBtn.x + 46f, turboBtn.y + turboBtn.h / 2 + (if (turboBtn.pressed) 14f else 0f), 64f, g.settings.turbo, g.time)
        for (s in sides) s.draw(c, g.time)
        // village label + progress
        Ui.pill(c, 380f, 150f, g.W - 30f, 214f, 0xAA1B0E05.toInt())
        Ui.text(c, "Vila ${pr.village} · ${th.name}", (380f + g.W - 30f) / 2, 172f, 32f, maxW = g.W - 460f, ow = 5f)
        Ui.bar(c, 410f, 194f, g.W - 60f, 208f, pr.progress, 0xFF9CCC65.toInt(), 0xFF33691E.toInt())
        g.drawHud(c)
        if (pr.stats["spins"].int() < 3 && !spinning && !g.hasPopup()) {
            val press = if (sin(g.time * 5f) > 0.4f) 1f else 0f
            Art.ripple(c, spinCx + 40f, spinCy + 30f, g.time)
            Art.hand(c, spinCx + 40f, spinCy + 30f + press * 10f, 0.9f, -28f, press)
            bubble(c, spinCx, spinCy - spinR - 70f, "Toque para girar!")
        } else if (pr.stats["spins"].int() in 3..60 && pr.canAffordBuild() && !spinning && !g.hasPopup() && !auto) {
            val press = if (sin(g.time * 5f) > 0.4f) 1f else 0f
            Art.hand(c, navVila.x + navVila.w * 0.5f, navVila.y - 8f - press * 10f, 0.66f, 195f, press)
        }
    }

    private fun bubble(c: Canvas, x: Float, y: Float, s: String) {
        val w = Ui.measure(s, 46f) + 80f
        val b = sin(g.time * 4f) * 6f
        Ui.panel(c, x - w / 2, y - 48f + b, x + w / 2, y + 48f + b, 0xFFFFFFFF.toInt(), 48f, bw = 6f, gloss = false)
        path.reset(); path.moveTo(x - 24f, y + 44f + b); path.lineTo(x + 24f, y + 44f + b); path.lineTo(x, y + 80f + b); path.close()
        p.shader = null; p.color = -1; c.drawPath(path, p)
        Ui.text(c, s, x, y + b, 46f, 0xFF4E342E.toInt(), outline = 0xFFFFFFFF.toInt(), ow = 0f)
    }

    private fun drawMachine(c: Canvas, pr: Profile) {
        val l = reelX0 - 50f; val rr = g.W - reelX0 + 50f
        val t = mTop; val b = mBottom
        val turbo = g.settings.turbo
        // pillars
        for (px in floatArrayOf(l - 6f, rr + 6f)) {
            r.set(px - 24f, t + 30f, px + 24f, b - 10f)
            p.color = -1; p.shader = LinearGradient(px - 24f, 0f, px + 24f, 0f, intArrayOf(0xFFB8860B.toInt(), 0xFFFFF59D.toInt(), 0xFFB8860B.toInt()), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            c.drawRoundRect(r, 20f, 20f, p); p.shader = null
            p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Ui.OUTLINE; c.drawRoundRect(r, 20f, 20f, p); p.style = Paint.Style.FILL
            for (k in 1..4) { p.color = 0xFF8D6E00.toInt(); c.drawRect(px - 24f, t + 30f + k * (b - t - 40f) / 5f - 4f, px + 24f, t + 30f + k * (b - t - 40f) / 5f + 4f, p) }
            Art.gem(c, px, t + 18f, 0.26f, if (px < g.W / 2) 0xFFE53935.toInt() else 0xFF1E88E5.toInt())
        }
        // body
        p.shader = null; p.color = 0x77000000; r.set(l, t + 24f, rr, b + 26f); c.drawRoundRect(r, 60f, 60f, p)
        r.set(l, t, rr, b)
        p.color = -1; p.shader = LinearGradient(0f, t, 0f, b, intArrayOf(0xFF8E24AA.toInt(), 0xFFC62828.toInt(), 0xFF4A0000.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 60f, 60f, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 18f
        p.color = -1; p.shader = LinearGradient(0f, t, 0f, b, 0xFFFFF59D.toInt(), 0xFFFF8F00.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 60f, 60f, p); p.shader = null
        p.strokeWidth = 6f; p.color = Ui.OUTLINE; r.set(l - 9f, t - 9f, rr + 9f, b + 9f); c.drawRoundRect(r, 68f, 68f, p)
        p.style = Paint.Style.FILL
        // marquee
        val mw = 560f; val ml = g.W / 2 - mw / 2; val mr = g.W / 2 + mw / 2; val mt = t - 92f
        path.reset(); path.moveTo(ml, t + 14f); path.lineTo(ml, mt + 46f); path.quadTo(g.W / 2, mt - 48f, mr, mt + 46f); path.lineTo(mr, t + 14f); path.close()
        p.color = -1; p.shader = LinearGradient(0f, mt, 0f, t + 14f, 0xFFE53935.toInt(), 0xFF7F0000.toInt(), Shader.TileMode.CLAMP); c.drawPath(path, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 12f; p.color = -1; p.shader = LinearGradient(0f, mt, 0f, t, 0xFFFFF59D.toInt(), 0xFFFF8F00.toInt(), Shader.TileMode.CLAMP); c.drawPath(path, p); p.shader = null
        p.strokeWidth = 4f; p.color = Ui.OUTLINE; c.drawPath(path, p); p.style = Paint.Style.FILL
        Ui.text(c, "CAPI COIN", g.W / 2, mt + 52f, 62f, gold = true, ow = 10f)
        val chase = floor(g.time * (if (winFlash > 0f) 14f else if (turbo) 12f else 6f)).toInt()
        for (k in 0 until 11) {
            val u = k / 10f
            val bx = lerp(ml + 18f, mr - 18f, u)
            val by = (1 - u) * (1 - u) * (mt + 46f) + 2 * u * (1 - u) * (mt - 48f) + u * u * (mt + 46f) + 10f
            val on = (k + chase) % 2 == 0
            val col = if (turbo) 0xFF84FFFF.toInt() else 0xFFFFF176.toInt()
            if (on) Art.glow(c, bx, by, 26f, col, 0.9f)
            p.color = if (on) lighten(col, 0.6f) else darken(col, 0.5f); c.drawCircle(bx, by, 8f, p)
        }
        // perimeter bulbs
        val per = 2 * ((rr - l) + (b - t)); val nb = 34
        for (i in 0 until nb) {
            var d = i * per / nb
            val bx: Float; val by: Float
            if (d < rr - l) { bx = l + d; by = t } else { d -= rr - l
                if (d < b - t) { bx = rr; by = t + d } else { d -= b - t
                    if (d < rr - l) { bx = rr - d; by = b } else { d -= rr - l; bx = l; by = b - d } } }
            if (by < t + 2f && bx > ml - 10f && bx < mr + 10f) continue
            val on = if (winFlash > 0f) (chase % 2 == 0) else ((i + chase) % 3 == 0)
            val col = if (turbo) (if (i % 2 == 0) 0xFF84FFFF.toInt() else 0xFFB388FF.toInt()) else (if (i % 2 == 0) 0xFFFFF176.toInt() else 0xFFFF8A80.toInt())
            if (on) Art.glow(c, bx, by, 32f, col, 0.9f)
            p.color = if (on) lighten(col, 0.5f) else darken(col, 0.45f)
            c.drawCircle(bx, by, 10f, p)
        }
        // reel housing
        r.set(reelX0 - 18f, reelTop - 18f, g.W - reelX0 + 18f, reelTop + cell * 3 + 18f)
        p.color = 0xFF2B0A12.toInt(); c.drawRoundRect(r, 36f, 36f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = 0xFFFFC107.toInt(); c.drawRoundRect(r, 36f, 36f, p); p.style = Paint.Style.FILL
        for (i in 0 until 3) {
            val x0 = reelX0 + i * (reelW + reelGap)
            val rl = reels[i]
            r.set(x0, reelTop, x0 + reelW, reelTop + cell * 3)
            p.color = -1; p.shader = LinearGradient(0f, r.top, 0f, r.bottom, intArrayOf(0xFFCFC3BC.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFCFC3BC.toInt()), floatArrayOf(0f, 0.3f, 0.7f, 1f), Shader.TileMode.CLAMP)
            c.drawRoundRect(r, 26f, 26f, p); p.shader = null
            val sc = c.save()
            c.clipRect(r)
            val base = floor(rl.pos).toInt()
            val fast = rl.spinning && !rl.stopping && rl.speed > 10f
            for (k in base - 2..base + 2) {
                val y = reelTop + cell * 1.5f + (rl.pos - k) * cell
                if (y < reelTop - cell || y > reelTop + cell * 4) continue
                val s = rl.sym(k)
                if (fast) Art.symbol(c, s, x0 + reelW / 2, y, 132f, 150, 1.4f)
                else {
                    val center = !rl.spinning && Math.round(rl.pos) == k
                    var size = if (center) 140f * (1f + 0.12f * sin(rl.bounce * Math.PI.toFloat())) else 116f
                    if (center && winRow && winFlash > 0f) { size *= 1f + 0.08f * sin(g.time * 14f); Art.glow(c, x0 + reelW / 2, y, 125f, Sym.glowColor[s], 0.6f + 0.4f * sin(g.time * 12f)) }
                    Art.symbol(c, s, x0 + reelW / 2, y, size, if (center || rl.spinning) 255 else 160)
                }
            }
            if (fast && turbo) { p.color = 0x5584FFFF; for (k in 0..3) c.drawRect(x0 + 20f + k * 60f, reelTop, x0 + 24f + k * 60f, reelTop + cell * 3, p) }
            c.restoreToCount(sc)
            p.color = -1; p.shader = LinearGradient(0f, r.top, 0f, r.top + 110f, 0x99000000.toInt(), 0x00000000, Shader.TileMode.CLAMP)
            c.drawRect(r.left, r.top, r.right, r.top + 110f, p)
            p.shader = LinearGradient(0f, r.bottom - 110f, 0f, r.bottom, 0x00000000, 0x99000000.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(r.left, r.bottom - 110f, r.right, r.bottom, p); p.shader = null
            // glass streak
            p.color = 0x22FFFFFF
            path.reset(); path.moveTo(x0 + 20f, reelTop); path.lineTo(x0 + 80f, reelTop); path.lineTo(x0 + 40f, reelTop + cell * 3); path.lineTo(x0 - 20f, reelTop + cell * 3); path.close()
            val sc2 = c.save(); c.clipRect(r); c.drawPath(path, p); c.restoreToCount(sc2)
            if (i == 2 && tension && rl.spinning) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 12f
                p.color = withAlpha(0xFFFFEB3B.toInt(), (150 + 100 * sin(g.time * 20f)).toInt())
                c.drawRoundRect(r, 26f, 26f, p); p.style = Paint.Style.FILL
            }
            p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = Ui.OUTLINE
            c.drawRoundRect(r, 26f, 26f, p); p.style = Paint.Style.FILL
        }
        // payline
        val py = reelTop + cell * 1.5f
        if (winRow && winFlash > 0f) {
            val a = (0.6f + 0.4f * sin(g.time * 16f))
            p.color = withAlpha(0xFFFFEB3B.toInt(), (120 * a).toInt()); c.drawRect(reelX0 - 10f, py - 8f, g.W - reelX0 + 10f, py + 8f, p)
            p.color = withAlpha(0xFFFFFFFF.toInt(), (200 * a).toInt()); c.drawRect(reelX0 - 10f, py - 2f, g.W - reelX0 + 10f, py + 2f, p)
        }
        for (side in 0..1) {
            val x = if (side == 0) reelX0 - 26f else g.W - reelX0 + 26f
            val dir = if (side == 0) 1f else -1f
            path.reset(); path.moveTo(x - dir * 30f, py - 30f); path.lineTo(x + dir * 14f, py); path.lineTo(x - dir * 30f, py + 30f); path.close()
            p.color = if (winRow && winFlash > 0f) 0xFFFFEB3B.toInt() else 0xFFFFC107.toInt(); c.drawPath(path, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Ui.OUTLINE; c.drawPath(path, p); p.style = Paint.Style.FILL
        }
        // tray
        Ui.panel(c, g.W / 2 - 230f, b - 58f, g.W / 2 + 230f, b + 8f, 0xFF4A0000.toInt(), 30f, bw = 5f)
        val label = when { spinning -> "BOA SORTE!"; lastWin > 0 && winFlash > 0f -> "GANHOU " + Fmt.n(lastWin); else -> "APOSTA x$curBet" }
        Ui.text(c, label, g.W / 2, b - 25f, 38f, 0xFFFFE082.toInt(), maxW = 420f)
    }

    private fun drawEnergy(c: Canvas, pr: Profile) {
        val y = energyY
        val have = if (localSpins >= 0) localSpins else pr.spinsNow()
        val frac = have.toFloat() / pr.maxSpins
        val sp = 1f + 0.12f * g.spinPulse
        Ui.bar(c, 120f, y - 32f, g.W - 300f, y + 32f, frac, 0xFFCE93D8.toInt(), 0xFF6A1B9A.toInt())
        c.save(); c.scale(sp, sp, 120f, y); Art.capsule(c, 116f, y, 0.42f); c.restore()
        val ms = pr.msToNextSpin()
        val txt = if (have >= pr.maxSpins || ms <= 0) "$have/${pr.maxSpins}" else "$have/${pr.maxSpins} · +1 em ${Fmt.clock(ms)}"
        Ui.text(c, txt, (120f + g.W - 300f) / 2 + 20f, y, 38f, maxW = g.W - 520f)
    }

    private fun drawSpinButton(c: Canvas, pr: Profile) {
        val press = if (pressing) 1f else spinPress
        val ready = !spinning && pr.spinsNow() >= 1
        val k = 1f - 0.07f * press + (if (ready) 0.025f * sin(g.time * 5f) else 0f)
        c.save(); c.scale(k, k, spinCx, spinCy)
        Art.glow(c, spinCx, spinCy, spinR * 1.7f, if (auto) 0xFF69F0AE.toInt() else if (g.settings.turbo) 0xFF84FFFF.toInt() else 0xFFFFAB40.toInt(), 0.55f)
        p.shader = null; p.color = 0x66000000; c.drawCircle(spinCx, spinCy + 16f, spinR, p)
        p.color = 0xFF7F0000.toInt(); c.drawCircle(spinCx, spinCy + 12f * (1 - press), spinR, p)
        val col = when { pr.spinsNow() < 1 -> 0xFF9E9E9E.toInt(); auto -> 0xFF2E7D32.toInt(); else -> 0xFFE53935.toInt() }
        p.color = -1; p.shader = RadialGradient(spinCx - 30f, spinCy - 50f, spinR * 1.4f, lighten(col, 0.45f), darken(col, 0.2f), Shader.TileMode.CLAMP)
        c.drawCircle(spinCx, spinCy, spinR, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 16f
        p.color = -1; p.shader = LinearGradient(0f, spinCy - spinR, 0f, spinCy + spinR, 0xFFFFF59D.toInt(), 0xFFFF8F00.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(spinCx, spinCy, spinR, p); p.shader = null
        p.strokeWidth = 6f; p.color = Ui.OUTLINE; c.drawCircle(spinCx, spinCy, spinR + 9f, p); p.style = Paint.Style.FILL
        p.color = 0x44FFFFFF; c.drawOval(spinCx - spinR * 0.65f, spinCy - spinR * 0.85f, spinCx + spinR * 0.65f, spinCy - spinR * 0.15f, p)
        val label = when { spinning -> "PARAR"; auto -> "AUTO"; else -> "GIRAR" }
        Ui.text(c, label, spinCx, spinCy - 8f, 62f)
        if (!spinning) Ui.text(c, if (auto) "toque p/ parar" else "segure: auto", spinCx, spinCy + 50f, 25f, 0xFFFFF3C4.toInt(), ow = 4f)
        if (pressing && !auto) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 14f; p.color = 0xFF69F0AE.toInt()
            r.set(spinCx - spinR - 24f, spinCy - spinR - 24f, spinCx + spinR + 24f, spinCy + spinR + 24f)
            c.drawArc(r, -90f, 360f * clamp01(holdT / 0.6f), false, p); p.style = Paint.Style.FILL
        }
        c.restore()
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if (g.hudTouch(type, x, y)) return
        for (b in buttons) if (b.touch(type, x, y, g)) return
        for (s in sides) if (s.touch(type, x, y, g)) return
        val dx = x - spinCx; val dy = y - spinCy
        val inside = dx * dx + dy * dy <= (spinR + 30f) * (spinR + 30f)
        when (type) {
            Game.DOWN -> if (inside) { pressing = !spinning && !auto; holdT = 0f; if (spinning) { fastStop(); g.audio.play("click") } else if (auto) { stopAuto(); g.audio.play("click") } }
            Game.UP -> if (pressing) { pressing = false; if (inside && holdT < 0.6f) { g.audio.play("click"); trySpin() } }
        }
        if (type == Game.DOWN && spinning && y in reelTop..(reelTop + cell * 3)) fastStop()
    }

    override fun back(): Boolean { if (auto) { stopAuto(); return true }; return false }
}
