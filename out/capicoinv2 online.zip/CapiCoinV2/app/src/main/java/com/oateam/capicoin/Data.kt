package com.oateam.capicoin

import android.content.Context

const val MAX_LEVEL = 5
const val MAX_SHIELDS = 3

/** Village theme: palette + scenery kind + building names. */
class Theme(
    val name: String,
    val kind: Int,
    val sky1: Int, val sky2: Int,
    val far: Int, val ground1: Int, val ground2: Int,
    val wall: Int, val roof: Int, val trim: Int, val accent: Int,
    val roofStyle: Int,          // 0 triangle, 1 dome, 2 flat/crenel, 3 thatch
    val buildings: Array<String>
)

object Themes {
    const val JUNGLE = 0; const val BEACH = 1; const val DESERT = 2; const val SNOW = 3
    const val VOLCANO = 4; const val CANDY = 5; const val NEON = 6; const val PIRATE = 7

    val all = arrayOf(
        Theme("Selva Amazônica", JUNGLE, 0xFF4FC3F7.toInt(), 0xFFB3E5FC.toInt(), 0xFF2E7D32.toInt(),
            0xFF66BB6A.toInt(), 0xFF2E7D32.toInt(), 0xFFD7A86E.toInt(), 0xFFC9A04A.toInt(), 0xFF6D4C2F.toInt(), 0xFFFF7043.toInt(), 3,
            arrayOf("Cabana da Capi", "Torre do Tucano", "Estátua da Capi", "Feira de Frutas", "Templo Perdido")),
        Theme("Praia Dourada", BEACH, 0xFF29B6F6.toInt(), 0xFFFFF59D.toInt(), 0xFF26C6DA.toInt(),
            0xFFFFE0A3.toInt(), 0xFFF4C27A.toInt(), 0xFFFFFFFF.toInt(), 0xFF42A5F5.toInt(), 0xFF1E88E5.toInt(), 0xFFFF5252.toInt(), 0,
            arrayOf("Casa de Praia", "Farol", "Estátua da Capi", "Quiosque de Coco", "Castelo de Areia")),
        Theme("Deserto dos Faraós", DESERT, 0xFFFFA726.toInt(), 0xFFFFE0B2.toInt(), 0xFFE0A15A.toInt(),
            0xFFF6C77E.toInt(), 0xFFD9963F.toInt(), 0xFFEFD3A0.toInt(), 0xFF26A69A.toInt(), 0xFF8D6E3F.toInt(), 0xFF00897B.toInt(), 1,
            arrayOf("Casa de Barro", "Obelisco", "Esfinge da Capi", "Bazar", "Pirâmide Dourada")),
        Theme("Montanha Nevada", SNOW, 0xFF5C6BC0.toInt(), 0xFFE3F2FD.toInt(), 0xFFB0BEC5.toInt(),
            0xFFFFFFFF.toInt(), 0xFFCFD8DC.toInt(), 0xFF8D6E63.toInt(), 0xFFD32F2F.toInt(), 0xFF4E342E.toInt(), 0xFF4FC3F7.toInt(), 0,
            arrayOf("Chalé Quentinho", "Torre de Gelo", "Estátua de Gelo", "Loja de Chocolate", "Palácio de Cristal")),
        Theme("Vulcão Ardente", VOLCANO, 0xFF1A0A2E.toInt(), 0xFFBF360C.toInt(), 0xFF3E2723.toInt(),
            0xFF5D4037.toInt(), 0xFF2B1A14.toInt(), 0xFF4E4A52.toInt(), 0xFF8E1F1F.toInt(), 0xFF1C1418.toInt(), 0xFFFF6D00.toInt(), 2,
            arrayOf("Forja", "Torre de Obsidiana", "Estátua de Magma", "Mercado de Rubis", "Fortaleza do Dragão")),
        Theme("Reino dos Doces", CANDY, 0xFFF48FB1.toInt(), 0xFFFFF0F6.toInt(), 0xFFCE93D8.toInt(),
            0xFFB2FF59.toInt(), 0xFF7CB342.toInt(), 0xFFFFE0B2.toInt(), 0xFFEC407A.toInt(), 0xFF8D4F2C.toInt(), 0xFF7E57C2.toInt(), 1,
            arrayOf("Casa de Biscoito", "Torre Pirulito", "Estátua de Chiclete", "Sorveteria", "Castelo de Bolo")),
        Theme("Cidade Neon", NEON, 0xFF0D0221.toInt(), 0xFF3A0CA3.toInt(), 0xFF240046.toInt(),
            0xFF2B2D42.toInt(), 0xFF10101A.toInt(), 0xFF22223B.toInt(), 0xFF00F5D4.toInt(), 0xFF0B0B14.toInt(), 0xFFF72585.toInt(), 2,
            arrayOf("Apartamento Neon", "Arranha-céu", "Holo-Capi", "Fliperama", "Mega Cassino")),
        Theme("Ilha Pirata", PIRATE, 0xFF0277BD.toInt(), 0xFF81D4FA.toInt(), 0xFF0288D1.toInt(),
            0xFFE6C88F.toInt(), 0xFF9E7B4F.toInt(), 0xFF8D6E4A.toInt(), 0xFF3E2723.toInt(), 0xFF2B1B10.toInt(), 0xFFFFD54F.toInt(), 0,
            arrayOf("Taverna", "Mastro Vigia", "Estátua do Capitão", "Banca do Tesouro", "Fortaleza Pirata"))
    )

    fun forVillage(v: Int) = all[(v - 1) % all.size]
}


/** Local, per-device settings (the game progress itself lives on the server). */
class Settings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("capicoin", Context.MODE_PRIVATE)
    var music = sp.getBoolean("music", true)
        set(v) { field = v; sp.edit().putBoolean("music", v).apply() }
    var sfx = sp.getBoolean("sfx", true)
        set(v) { field = v; sp.edit().putBoolean("sfx", v).apply() }
    var vibe = sp.getBoolean("vibe", true)
        set(v) { field = v; sp.edit().putBoolean("vibe", v).apply() }
    var turbo = sp.getBoolean("turbo", false)
        set(v) { field = v; sp.edit().putBoolean("turbo", v).apply() }
    var notifs = sp.getBoolean("notifs", true)
        set(v) { field = v; sp.edit().putBoolean("notifs", v).apply() }
    var serverUrl: String = (sp.getString("server", null) ?: DEFAULT_SERVER).let { if (it.startsWith("http://") && it.contains(".railway.app")) "https://" + it.removePrefix("http://") else it }
        set(v) { field = v; sp.edit().putString("server", v).apply() }
    var token: String? = sp.getString("token", null)
        set(v) { field = v; sp.edit().putString("token", v).apply() }
    var seenIntro = sp.getBoolean("seenIntro", false)
        set(v) { field = v; sp.edit().putBoolean("seenIntro", v).apply() }
    var lastNotifiedEvent = sp.getLong("lastNotified", 0L)
        set(v) { field = v; sp.edit().putLong("lastNotified", v).apply() }
    var lastToastEvent = sp.getLong("lastToast", 0L)
        set(v) { field = v; sp.edit().putLong("lastToast", v).apply() }
    var cachedProfile: String? = sp.getString("profile", null)
        set(v) { field = v; sp.edit().putString("profile", v).apply() }
    private val tips = HashSet(sp.getString("tips", "")!!.split(',').filter { it.isNotEmpty() })

    fun seen(tip: String) = tips.contains(tip)
    fun markSeen(tip: String) { tips.add(tip); sp.edit().putString("tips", tips.joinToString(",")).apply() }

    companion object {
        /** Sem http/https na frente: usa http só para IP/localhost, https para o resto. */
        fun fixUrl(u: String): String =
            if (u.startsWith("http")) u
            else if (u.startsWith("localhost") || u.startsWith("127.") || u.startsWith("192.168.") || u.startsWith("10.")) "http://$u" else "https://$u"
        /** Servidor padrão. Troque pela URL pública do seu servidor (ou mude dentro do app em Ajustes > Servidor). */
        const val DEFAULT_SERVER = "https://projeto-de-vendas1-production.up.railway.app"
    }
}

class PetInfo(val key: String, j: J) {
    val name = j["name"].str(key)
    val desc = j["desc"].str()
    val role = j["role"].str()
    val unlocked = j["unlocked"].bool()
    val level = j["level"].int(1)
    val xp = j["xp"].int()
    val xpNext = j["xpNext"].int(5)
    val unlockVillage = j["unlockVillage"].int()
    val gemCost = j["gemCost"].int(300)
    val bonus = j["bonus"].dbl()
}

class Mission(j: J) {
    val id = j["id"].int()
    val label = j["label"].str()
    val target = j["target"].int(1)
    val progress = j["progress"].int()
    val claimed = j["claimed"].bool()
    val reward = j["reward"]
    val done get() = progress >= target
}

/** Snapshot of the player sent by the server. */
class Profile(val j: J) {
    val receivedAt = System.currentTimeMillis()
    val id = j["id"].long()
    val name = j["name"].str("Capi")
    val avatar = j["avatar"].int()
    val email = j["email"].strOrNull()
    val guest = j["guest"].bool()
    val google = j["google"].bool()
    val friendCode = j["friendCode"].str()
    var coins = j["coins"].long()
    var gems = j["gems"].int()
    var spins = j["spins"].int()
    val maxSpins = j["maxSpins"].int(80)
    val regenMs = j["regenMs"].long(180000)
    val nextSpinMs = j["nextSpinMs"].long()
    var shields = j["shields"].int()
    val maxShields = j["maxShields"].int(3)
    val village = j["village"].int(1)
    val themeName = j["themeName"].str()
    val levels = IntArray(5) { j["levels"][it].int() }
    val damaged = BooleanArray(5) { j["damaged"][it].bool() }
    val costs = LongArray(5) { j["costs"][it].long() }
    val complete = j["complete"].bool()
    val bet = j["bet"].int(1)
    val bets = j["bets"].list.map { it.int() }.ifEmpty { listOf(1, 2, 3, 5, 10, 20, 50, 100) }
    var petiscos = j["petiscos"].int()
    val activePet = j["activePet"].strOrNull()
    val petAwakeMs = j["petAwakeMs"].long()
    val pets: Map<String, PetInfo> = j["pets"].keys.associateWith { PetInfo(it, j["pets"][it]) }
    val wheelReady = j["wheelReady"].bool()
    val wheelResetMs = j["wheelResetMs"].long()
    val missions = j["missions"]["list"].list.map { Mission(it) }
    val missionsBonusClaimed = j["missions"]["bonusClaimed"].bool()
    val missionsResetMs = j["missionsResetMs"].long()
    val streak = j["streak"].int()
    val pendingAttack = j["pending"]["attack"].has("bet")
    val pendingRaid = j["pending"]["raid"].has("bet")
    val stats = j["stats"]
    val starterAvailable = j["starterAvailable"].bool()
    val rewardMult = j["rewardMult"].dbl(1.0)
    val unread = j["unread"].int()
    val giftsPending = j["giftsPending"].int()
    val friendRequests = j["friendRequests"].int()
    val lastEventId = j["lastEventId"].long()

    val theme: Theme get() = Themes.forVillage(village)
    val progress: Float get() = levels.sum() / (5f * MAX_LEVEL)
    fun petAwake(now: Long = System.currentTimeMillis()) = activePet != null && receivedAt + petAwakeMs > now
    fun petAwakeLeft(now: Long = System.currentTimeMillis()) = (receivedAt + petAwakeMs - now).coerceAtLeast(0)
    fun missionsClaimable() = missions.count { it.done && !it.claimed } + (if (!missionsBonusClaimed && missions.isNotEmpty() && missions.all { it.claimed }) 1 else 0)
    fun canAffordBuild(): Boolean { for (i in 0 until 5) if (costs[i] > 0 && coins >= costs[i]) return true; return false }

    /** Spins predicted locally between server syncs (regen keeps going while you look at the screen). */
    fun spinsNow(now: Long = System.currentTimeMillis()): Int {
        if (spins >= maxSpins || nextSpinMs <= 0) return spins
        val t = now - receivedAt
        if (t < nextSpinMs) return spins
        return minOf(maxSpins, spins + 1 + ((t - nextSpinMs) / regenMs).toInt())
    }
    fun msToNextSpin(now: Long = System.currentTimeMillis()): Long {
        val s = spinsNow(now)
        if (s >= maxSpins) return 0
        val t = now - receivedAt
        return if (t < nextSpinMs) nextSpinMs - t else regenMs - ((t - nextSpinMs) % regenMs)
    }
    fun wheelReadyNow(now: Long = System.currentTimeMillis()) = wheelReady || now - receivedAt > wheelResetMs
}

object Fmt {
    private val br = java.util.Locale.forLanguageTag("pt-BR")
    fun n(v: Long): String {
        val a = Math.abs(v)
        return when {
            a < 10_000 -> String.format(br, "%,d", v)
            a < 1_000_000 -> t(v / 1_000.0) + "K"
            a < 1_000_000_000 -> t(v / 1_000_000.0) + "M"
            a < 1_000_000_000_000 -> t(v / 1_000_000_000.0) + "B"
            else -> t(v / 1_000_000_000_000.0) + "T"
        }
    }
    private fun t(d: Double): String {
        var s = if (d >= 100) String.format(java.util.Locale.US, "%.0f", d) else if (d >= 10) String.format(java.util.Locale.US, "%.1f", d) else String.format(java.util.Locale.US, "%.2f", d)
        if (s.contains('.')) s = s.trimEnd('0').trimEnd('.')
        return s.replace('.', ',')
    }
    fun brl(cents: Int): String = "R$ " + String.format(br, "%,.2f", cents / 100.0)
    fun clock(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return if (s >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
    }
    fun ago(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return when { s < 60 -> "agora"; s < 3600 -> "${s / 60} min"; s < 86400 -> "${s / 3600} h"; else -> "${s / 86400} d" }
    }
}
