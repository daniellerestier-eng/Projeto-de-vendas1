package com.oateam.capicoin

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.roundToLong

abstract class Scene(val g: Game) {
    open fun layout() {}
    open fun enter() {}
    abstract fun update(dt: Float)
    abstract fun draw(c: Canvas)
    open fun touch(type: Int, x: Float, y: Float) {}
    /** return true if handled */
    open fun back(): Boolean = false
    /** In-game scenes show the HUD and receive live events. */
    open val inGame: Boolean get() = true
}

abstract class Popup(g: Game) : Scene(g) {
    var t = 0f
    var closing = false
    private var closeT = 0f
    var dismissible = true
    var onClosed: (() -> Unit)? = null
    val alive: Boolean get() = !(closing && closeT > 0.22f)

    fun close() { if (!closing) { closing = true; closeT = 0f } }

    override fun update(dt: Float) {
        t += dt
        if (closing) { closeT += dt; if (closeT > 0.22f) { val cb = onClosed; onClosed = null; cb?.invoke() } }
    }

    fun k(): Float = if (closing) 1f - Ease.inCubic(clamp01(closeT / 0.22f)) else Ease.outBack(clamp01(t / 0.38f))
    fun dimAlpha(): Float = if (closing) 0.66f * (1f - clamp01(closeT / 0.22f)) else 0.66f * clamp01(t / 0.2f)

    fun begin(c: Canvas, l: Float, top: Float, r: Float, b: Float, color: Int = 0xFF5E35B1.toInt()): Int {
        Ui.dim(c, g.W, g.H, dimAlpha())
        val sc = c.save()
        val kk = k()
        c.scale(kk, kk, (l + r) / 2, (top + b) / 2)
        Ui.panel(c, l, top, r, b, color, 56f)
        // decorative inner border
        Ui.p.style = Paint.Style.STROKE; Ui.p.strokeWidth = 4f; Ui.p.color = 0x55FFFFFF
        c.drawRoundRect(l + 16f, top + 16f, r - 16f, b - 16f, 44f, 44f, Ui.p); Ui.p.style = Paint.Style.FILL
        return sc
    }

    /** Title ribbon across the top of a panel. */
    fun ribbon(c: Canvas, cx: Float, y: Float, w: Float, text: String, color: Int = 0xFFE53935.toInt()) {
        val p = Ui.p; p.shader = null
        val path = android.graphics.Path()
        path.moveTo(cx - w / 2 - 40f, y - 30f); path.lineTo(cx - w / 2, y - 30f); path.lineTo(cx - w / 2, y + 40f); path.lineTo(cx - w / 2 - 40f, y + 40f); path.lineTo(cx - w / 2 - 20f, y + 5f); path.close()
        p.color = darken(color, 0.35f); c.drawPath(path, p)
        val path2 = android.graphics.Path()
        path2.moveTo(cx + w / 2 + 40f, y - 30f); path2.lineTo(cx + w / 2, y - 30f); path2.lineTo(cx + w / 2, y + 40f); path2.lineTo(cx + w / 2 + 40f, y + 40f); path2.lineTo(cx + w / 2 + 20f, y + 5f); path2.close()
        c.drawPath(path2, p)
        Ui.panel(c, cx - w / 2, y - 46f, cx + w / 2, y + 46f, color, 20f, bw = 6f)
        Ui.text(c, text, cx, y, 58f, gold = true, maxW = w - 40f, ow = 10f)
    }

    override fun back(): Boolean { if (dismissible) close(); return true }
    override val inGame: Boolean get() = false
}

class Banner(val text: String, val sub: String?, val color: Int, val life: Float = 1.7f) { var t = 0f }
class Toast(val icon: Int, val title: String, val text: String, val life: Float = 3.4f) { var t = 0f }

/** Marker: popups that want the HUD visible above their dim layer. */
interface HudOnTop

class Game(val ctx: Context, val host: Host) {
    companion object {
        const val DOWN = 0; const val MOVE = 1; const val UP = 2
        // toast icons
        const val T_INFO = 0; const val T_ATTACK = 1; const val T_RAID = 2; const val T_GIFT = 3; const val T_FRIEND = 4; const val T_PAY = 5; const val T_PET = 6; const val T_SHIELD = 7; const val T_MISSION = 8
    }

    val W = 1080f
    var H = 1920f
    var scale = 1f
    val settings = Settings(ctx)
    val audio = Audio(ctx, settings)
    val fx = Fx(this)
    val net = Net(this)
    var time = 0f

    // server data
    var prof: Profile? = null
        private set
    var wheelInfo: J = J(null)
    var chests: J = J(null)
    var gemShop: J = J(null)
    var paymentsOn = false
    var googleOn = false
    private var deferredProfile: J? = null
    /** Daily bonus waits until the player is actually in the game (not during login/cutscenes). */
    var pendingBonus: J? = null
    var profileLocked = false
        set(v) { field = v; if (!v) deferredProfile?.let { deferredProfile = null; applyProfile(it) } }

    val slot: SlotScene by lazy { SlotScene(this) }
    val village: VillageScene by lazy { VillageScene(this) }
    var scene: Scene
    val popups = ArrayList<Popup>()
    private val banners = ArrayList<Banner>()
    private val toasts = ArrayList<Toast>()
    private val posted = ConcurrentLinkedQueue<() -> Unit>()

    private var nextScene: Scene? = null
    private var transT = -1f
    private var shakeT = 0f
    private var shakeAmp = 0f
    var flash = 0f
    var displayCoins = 0.0
    var displayGems = 0.0
    var coinHold = 0f
    var hudPulse = 0f
    var gemPulse = 0f
    var shieldPulse = 0f
    var spinPulse = 0f
    private var sized = false
    private var pollT = 6f
    private var profT = 60f
    val coinTarget get() = floatArrayOf(180f, 92f)
    val gemTarget get() = floatArrayOf(612f, 92f)

    init {
        settings.cachedProfile?.let { val j = J.parse(it); if (!j.isNull) { prof = Profile(j); displayCoins = prof!!.coins.toDouble(); displayGems = prof!!.gems.toDouble() } }
        scene = LoginScene(this)
    }

    fun post(r: () -> Unit) { posted.add(r) }

    fun resize(pw: Int, ph: Int) {
        if (pw <= 0 || ph <= 0) return
        scale = pw / W
        H = ph / scale
        Art.init(scale)
        if (prof != null) { slot.layout(); village.layout() }
        scene.layout()
        for (p in popups) p.layout()
        if (!sized) { sized = true; scene.enter() }
    }

    // ------------------------------------------------------------ server state
    fun applyProfile(j: J) {
        if (j.isNull) return
        if (profileLocked) { deferredProfile = j; return }
        val old = prof
        val np = Profile(j)
        prof = np
        settings.cachedProfile = j.toString()
        if (old == null) { displayCoins = np.coins.toDouble(); displayGems = np.gems.toDouble() }
        if (old != null && np.shields > old.shields) shieldPulse = 1f
        if (old != null && np.gems > old.gems) gemPulse = 1f
    }

    /** Full refresh (also returns the daily login bonus once per day). */
    fun refreshProfile(cb: ((Res) -> Unit)? = null) {
        net.call("GET", "/api/profile") { r ->
            if (r.ok) {
                wheelInfo = r.j["wheel"]; chests = r.j["chests"]; gemShop = r.j["gemShop"]
                paymentsOn = r.j["payments"].bool(); googleOn = r.j["google"].bool()
                val bonus = r.j["dailyBonus"]
                if (!bonus.isNull) pendingBonus = bonus
            }
            cb?.invoke(r)
        }
    }

    fun onAuthLost() {
        if (settings.token == null && scene is LoginScene) return
        settings.token = null
        popups.clear()
        toast(T_INFO, "Sessão expirada", "Entre novamente na sua conta.")
        goto(LoginScene(this))
    }

    fun logout() {
        net.call("POST", "/auth/logout")
        settings.token = null
        settings.cachedProfile = null
        prof = null
        popups.clear()
        goto(LoginScene(this))
    }

    /** Shows a server error nicely. */
    fun error(r: Res) {
        audio.play("tick", 0.8f, 0.7f)
        toast(T_INFO, if (r.status == 0) "Sem conexão" else "Ops!", r.message)
    }

    // ------------------------------------------------------------ navigation
    fun goto(s: Scene) {
        if (transT >= 0f) { nextScene = s; return }
        nextScene = s; transT = 0f
        audio.play("whoosh", 0.6f)
    }

    fun show(p: Popup) { p.layout(); popups.add(p); audio.play("pop", 0.7f) }
    fun hasPopup() = popups.isNotEmpty()
    fun topPopup(): Popup? = popups.lastOrNull()

    fun banner(text: String, sub: String? = null, color: Int = 0xFFFFD54F.toInt(), life: Float = 1.7f) {
        while (banners.size > 1) banners.removeAt(banners.size - 1)
        banners.add(Banner(text, sub, color, if (settings.turbo) life * 0.7f else life))
    }

    fun toast(icon: Int, title: String, text: String) {
        if (toasts.size >= 3) toasts.removeAt(1)
        toasts.add(Toast(icon, title, text))
        audio.play("notify", 0.6f)
    }

    fun shake(amp: Float, dur: Float = 0.4f) { shakeAmp = maxOf(shakeAmp, amp); shakeT = maxOf(shakeT, dur) }

    /** Visual coin rain towards the HUD (the value itself already came from the server). */
    fun coinsFly(amount: Long, fromX: Float, fromY: Float, n: Int = -1) {
        if (amount <= 0) return
        val count = if (n > 0) n else (6 + (Math.log10(amount.toDouble()) * 3).toInt()).coerceIn(6, 28)
        coinHold = 0.45f
        fx.coinRain(fromX, fromY, coinTarget[0], coinTarget[1], count) {
            audio.play("coin", 0.5f, rnd(0.9f, 1.2f), 45)
            hudPulse = 1f
        }
    }

    fun gemsFly(n: Int, fromX: Float, fromY: Float) {
        if (n <= 0) return
        audio.play("gem")
        for (i in 0 until minOf(14, 3 + n / 5)) {
            val q = fx.spawn(P.STAR, fromX + rnd(-50f, 50f), fromY + rnd(-40f, 40f), rnd(-400f, 400f), rnd(-700f, -200f), 1.0f, 26f, 0xFF80DEEA.toInt(), 900f)
            q.drag = 0.97f
        }
        gemPulse = 1f
    }

    fun spinsFly(n: Int, fromX: Float, fromY: Float) {
        if (n <= 0) return
        for (i in 0 until minOf(n, 14)) {
            val q = fx.spawn(P.STAR, fromX + rnd(-60f, 60f), fromY + rnd(-40f, 40f), rnd(-300f, 300f), rnd(-600f, -200f), 0.9f, 22f, 0xFFE1BEE7.toInt(), 900f)
            q.drag = 0.97f
        }
        spinPulse = 1f
    }

    /** Celebrates a reward object {coins, spins, gems, petiscos, shields}. */
    fun celebrate(give: J, x: Float, y: Float) {
        coinsFly(give["coins"].long(), x, y)
        gemsFly(give["gems"].int(), x, y)
        spinsFly(give["spins"].int(), x, y)
        if (give["shields"].int() > 0) shieldPulse = 1f
    }

    // ------------------------------------------------------------ loop
    fun update(dt0: Float) {
        val dt = dt0.coerceAtMost(0.05f)
        time += dt
        while (true) { val r = posted.poll() ?: break; try { r() } catch (e: Exception) { android.util.Log.e("CapiCoin", "callback", e) } }
        prof?.let { p ->
            coinHold = (coinHold - dt).coerceAtLeast(0f)
            if (coinHold <= 0f) {
                val diff = p.coins - displayCoins
                displayCoins = if (Math.abs(diff) < 1.0) p.coins.toDouble() else displayCoins + diff * (1 - Math.exp(-dt * 5.0))
            }
            val gd = p.gems - displayGems
            displayGems = if (Math.abs(gd) < 0.5) p.gems.toDouble() else displayGems + gd * (1 - Math.exp(-dt * 6.0))
        }
        hudPulse = (hudPulse - dt * 3f).coerceAtLeast(0f)
        gemPulse = (gemPulse - dt * 2f).coerceAtLeast(0f)
        shieldPulse = (shieldPulse - dt * 2f).coerceAtLeast(0f)
        spinPulse = (spinPulse - dt * 2f).coerceAtLeast(0f)
        flash = (flash - dt * 3f).coerceAtLeast(0f)
        if (shakeT > 0f) { shakeT -= dt; if (shakeT <= 0f) shakeAmp = 0f }

        if (transT >= 0f) {
            val prev = transT
            transT += dt / 0.6f
            if (prev < 0.5f && transT >= 0.5f) {
                nextScene?.let { scene = it; fx.clear(); it.layout(); it.enter() }
                nextScene = null
            }
            if (transT >= 1f) { transT = -1f; nextScene?.let { n -> nextScene = null; goto(n) } }
        }
        scene.update(dt)
        val it = popups.iterator()
        while (it.hasNext()) { val p = it.next(); if (!p.alive) it.remove() }
        for (i in popups.indices.reversed()) { if (i < popups.size) popups[i].update(dt) }
        if (banners.isNotEmpty()) { val b = banners[0]; b.t += dt; if (b.t >= b.life) banners.removeAt(0) }
        if (toasts.isNotEmpty()) { val tt = toasts[0]; tt.t += dt; if (tt.t >= tt.life) toasts.removeAt(0) }
        fx.update(dt)
        pendingBonus?.let { b -> if (scene.inGame && popups.isEmpty() && transT < 0f) { pendingBonus = null; show(DailyBonusPopup(this, b)) } }
        // live sync with the server
        if (settings.token != null && prof != null && scene.inGame) {
            pollT -= dt; profT -= dt
            if (pollT <= 0f) { pollT = 20f; pollEvents() }
            if (profT <= 0f && !profileLocked && net.inFlight == 0) { profT = 75f; net.call("GET", "/api/profile") }
        }
    }

    private fun pollEvents() {
        val after = maxOf(settings.lastToastEvent, 0L)
        net.call("GET", "/api/events/poll?after=$after") { r ->
            if (!r.ok) return@call
            var refresh = false
            for (e in r.j["events"].list) {
                val id = e["id"].long()
                if (id <= settings.lastToastEvent) continue
                settings.lastToastEvent = id
                if (after == 0L) continue // first sync: don't spam old events
                val who = e["actor"].str("Alguém")
                when (e["type"].str()) {
                    "attack" -> { toast(T_ATTACK, "Sua vila foi atacada!", "$who quebrou: ${e["data"]["building"].str("um prédio")}"); audio.play("alarm", 0.6f); refresh = true }
                    "block" -> { toast(T_SHIELD, "Ataque bloqueado!", "$who tentou atacar, mas você se defendeu."); refresh = true }
                    "raid" -> { toast(T_RAID, "Você foi saqueado!", "$who levou ${Fmt.n(e["data"]["amount"].long())} moedas"); refresh = true }
                    "gift" -> toast(T_GIFT, "Presente recebido!", "$who te mandou giros. Colete em Amigos.")
                    "friend_req" -> toast(T_FRIEND, "Pedido de amizade", "$who quer ser seu amigo!")
                    "friend_ok" -> toast(T_FRIEND, "Nova amizade!", "$who aceitou seu pedido.")
                    "payment" -> { toast(T_PAY, "Pagamento aprovado!", "${e["data"]["item"].str()} creditado."); audio.play("cash"); refresh = true }
                    "pet_unlock" -> toast(T_PET, "Novo pet!", "${e["data"]["name"].str()} desbloqueado!")
                }
            }
            if (refresh && !profileLocked) net.call("GET", "/api/profile")
        }
    }

    fun draw(c: Canvas) {
        c.save()
        if (shakeT > 0f) c.translate(rnd(-shakeAmp, shakeAmp), rnd(-shakeAmp, shakeAmp))
        scene.draw(c)
        fx.draw(c)
        c.restore()
        for (p in popups) p.draw(c)
        val tp = popups.lastOrNull()
        if (tp is HudOnTop && prof != null) { drawHud(c); fx.draw(c) }
        if (banners.isNotEmpty()) drawBanner(c, banners[0])
        if (toasts.isNotEmpty()) drawToast(c, toasts[0])
        if (flash > 0f) { Ui.p.shader = null; Ui.p.color = withAlpha(0xFFFFFFFF.toInt(), (flash * 200).toInt()); c.drawRect(0f, 0f, W, H, Ui.p) }
        if (transT >= 0f) {
            val a = if (transT < 0.5f) transT * 2f else (1f - transT) * 2f
            // iris wipe
            Ui.p.shader = null; Ui.p.color = withAlpha(0xFF1A0B2E.toInt(), (clamp01(a * 1.4f) * 255).toInt())
            c.drawRect(0f, 0f, W, H, Ui.p)
            if (a > 0.5f) Art.coinSpin(c, W / 2, H / 2, 70f, time * 8f)
        }
    }

    private fun drawBanner(c: Canvas, b: Banner) {
        val inT = clamp01(b.t / 0.3f)
        val outT = clamp01((b.life - b.t) / 0.25f)
        val k = Ease.outBack(inT) * outT
        val cy = H * 0.43f
        c.save(); c.scale(k, k, W / 2, cy)
        Art.rays(c, W / 2, cy, 560f, time * 2f, b.color, 18, 0.8f)
        val p = Ui.p; p.shader = null
        val h2 = if (b.sub != null) 115f else 85f
        p.color = -1; p.shader = android.graphics.LinearGradient(0f, cy - 95f, 0f, cy + h2, 0xF06A1B9A.toInt(), 0xF0311B92.toInt(), android.graphics.Shader.TileMode.CLAMP)
        c.drawRect(-20f, cy - 95f, W + 20f, cy + h2, p); p.shader = null
        p.color = 0xFFFFD54F.toInt(); c.drawRect(-20f, cy - 107f, W + 20f, cy - 93f, p); c.drawRect(-20f, cy + h2 - 2f, W + 20f, cy + h2 + 12f, p)
        Ui.text(c, b.text, W / 2, cy - (if (b.sub != null) 18f else 0f), 112f, gold = true, maxW = W - 60f, ow = 18f)
        if (b.sub != null) Ui.text(c, b.sub, W / 2, cy + 66f, 60f, maxW = W - 80f)
        c.restore()
    }

    private fun drawToast(c: Canvas, t: Toast) {
        val inK = Ease.outBack(clamp01(t.t / 0.35f))
        val outK = clamp01((t.life - t.t) / 0.3f)
        val y = -150f + (300f) * minOf(inK, outK)
        val l = 40f; val r = W - 40f
        Ui.panel(c, l, y - 70f, r, y + 70f, when (t.icon) { T_ATTACK, T_RAID -> 0xFFC62828.toInt(); T_PAY -> 0xFF2E7D32.toInt(); T_GIFT, T_FRIEND -> 0xFF7B1FA2.toInt(); else -> 0xFF283593.toInt() }, 40f, bw = 6f)
        val ix = l + 80f
        when (t.icon) {
            T_ATTACK -> Art.iconHammer(c, ix, y, 100f)
            T_RAID -> Art.symbol(c, Sym.RAID, ix, y, 120f)
            T_GIFT -> Art.iconGift(c, ix, y, 100f)
            T_FRIEND -> Art.iconFriends(c, ix, y, 100f)
            T_PAY -> Art.iconPix(c, ix, y, 90f)
            T_PET -> Art.iconPaw(c, ix, y, 90f)
            T_SHIELD -> Art.iconShield(c, ix, y, 96f, true)
            T_MISSION -> Art.iconScroll(c, ix, y, 96f)
            else -> Art.iconBell(c, ix, y, 90f, time, true)
        }
        Ui.text(c, t.title, l + 150f, y - 26f, 42f, 0xFFFFEB3B.toInt(), align = Paint.Align.LEFT, maxW = r - l - 180f)
        Ui.text(c, t.text, l + 150f, y + 24f, 34f, align = Paint.Align.LEFT, maxW = r - l - 180f, ow = 5f)
    }

    // ------------------------------------------------------------ HUD
    fun drawHud(c: Canvas) {
        val p = prof ?: return
        val y = 92f
        Art.avatar(c, 70f, y, 50f, p.avatar)
        // coins
        val cp = 1f + 0.12f * hudPulse
        Ui.pill(c, 128f, y - 40f, 560f, y + 40f, 0xCC1B0E05.toInt())
        c.save(); c.scale(cp, cp, 180f, y); Art.coin(c, 180f, y, 46f); c.restore()
        Ui.text(c, Fmt.n(displayCoins.roundToLong()), 360f, y, 54f, maxW = 300f)
        plus(c, 530f, y)
        // gems
        val gp = 1f + 0.18f * gemPulse
        Ui.pill(c, 580f, y - 40f, 850f, y + 40f, 0xCC1B0E05.toInt())
        c.save(); c.scale(gp, gp, 620f, y); Art.iconGem(c, 620f, y, 76f); c.restore()
        Ui.text(c, Fmt.n(displayGems.roundToLong()), 730f, y, 50f, maxW = 160f)
        plus(c, 820f, y)
        // bell
        Art.iconBell(c, 960f, y, 92f, time, p.unread > 0)
        if (p.unread > 0) Ui.badge(c, 1000f, y - 34f, if (p.unread > 9) "9+" else p.unread.toString(), time)
        // shields
        val sp = 1f + 0.2f * shieldPulse
        for (i in 0 until p.maxShields) {
            val sx = 160f + i * 70f
            c.save(); if (i == p.shields - 1) c.scale(sp, sp, sx, 182f)
            Art.iconShield(c, sx, 182f, 60f, i < p.shields); c.restore()
        }
    }

    private fun plus(c: Canvas, x: Float, y: Float) {
        Ui.p.shader = null; Ui.p.color = 0xFF43A047.toInt(); c.drawCircle(x, y, 26f, Ui.p)
        Ui.p.style = Paint.Style.STROKE; Ui.p.strokeWidth = 5f; Ui.p.color = Ui.OUTLINE; c.drawCircle(x, y, 26f, Ui.p); Ui.p.style = Paint.Style.FILL
        Ui.text(c, "+", x, y - 2f, 46f, ow = 5f)
    }

    /** Handles taps on the HUD. Returns true if consumed. */
    fun hudTouch(type: Int, x: Float, y: Float): Boolean {
        if (type != UP || prof == null || y > 140f) return false
        when {
            x < 125f -> { audio.play("click"); show(ProfilePopup(this)) }
            x in 128f..560f -> { audio.play("click"); show(ShopPopup(this, ShopPopup.TAB_COINS)) }
            x in 580f..850f -> { audio.play("click"); show(ShopPopup(this, ShopPopup.TAB_GEMS)) }
            x > 900f -> { audio.play("click"); show(InboxPopup(this)) }
            else -> return false
        }
        return true
    }

    // ------------------------------------------------------------ input / lifecycle
    fun touch(type: Int, x: Float, y: Float) {
        if (transT >= 0f) return
        if (toasts.isNotEmpty() && type == UP && y < 230f && toasts[0].t > 0.3f) { toasts[0].t = maxOf(toasts[0].t, toasts[0].life - 0.3f); return }
        val tp = popups.lastOrNull { !it.closing }
        if (tp != null) { tp.touch(type, x, y); return }
        if (popups.isNotEmpty()) return
        scene.touch(type, x, y)
    }

    fun back(): Boolean {
        val tp = popups.lastOrNull { !it.closing }
        if (tp != null) return tp.back()
        return scene.back()
    }

    fun onPause() { audio.pauseAll() }

    fun onResume() {
        audio.resumeAll()
        if (settings.token != null && prof != null && scene.inGame) { refreshProfile(); pollT = 1f }
    }

    /** Deep link from the Google login page: capicoin://login?token=... */
    fun onLoginToken(token: String?, error: String?) {
        if (!token.isNullOrEmpty()) {
            settings.token = token
            popups.clear()
            goto(LoginScene(this))
        } else if (!error.isNullOrEmpty()) toast(T_INFO, "Login", error)
    }
}
