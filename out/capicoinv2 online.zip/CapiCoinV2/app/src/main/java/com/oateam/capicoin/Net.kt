package com.oateam.capicoin

import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Platform services the game needs from the Activity (dialogs, browser, clipboard...). */
interface Host {
    class Field(val label: String, val kind: Int = TEXT, val initial: String = "") { companion object { const val TEXT = 0; const val EMAIL = 1; const val PASSWORD = 2 } }
    fun prompt(title: String, fields: List<Field>, ok: String, extra: String? = null, cb: (values: List<String>?, extraPressed: Boolean) -> Unit)
    fun openUrl(url: String)
    fun copy(text: String)
    fun share(text: String)
    fun decodeImage(bytes: ByteArray): android.graphics.Bitmap?
    fun deviceId(): String
    fun requestNotifications()
}

class Res(val ok: Boolean, val status: Int, val j: J, val error: String, val message: String)

/** HTTP client for the Capi Coin server. Calls run on a worker pool; callbacks run on the game thread. */
class Net(private val g: Game) {
    private val exec = Executors.newFixedThreadPool(3)
    var inFlight = 0
        private set

    val base: String get() = g.settings.serverUrl.trimEnd('/')

    fun call(method: String, path: String, body: Map<String, Any?>? = null, applyProfile: Boolean = true, cb: ((Res) -> Unit)? = null) {
        val token = g.settings.token
        val url = base + path
        inFlight++
        exec.execute {
            val res = request(method, url, body, token)
            g.post {
                inFlight--
                if (res.status == 401 && path.startsWith("/api/")) g.onAuthLost()
                if (res.ok && applyProfile && res.j.has("profile")) g.applyProfile(res.j["profile"])
                cb?.invoke(res)
            }
        }
    }

    companion object {
        fun request(method: String, url: String, body: Map<String, Any?>?, token: String?): Res {
            var conn: HttpURLConnection? = null
            return try {
                conn = URL(url).openConnection() as HttpURLConnection
                conn.requestMethod = method
                conn.connectTimeout = 8000
                conn.readTimeout = 20000
                conn.setRequestProperty("Accept", "application/json")
                if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
                if (body != null || method == "POST") {
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    conn.outputStream.use { it.write(Json.write(body ?: emptyMap<String, Any?>()).toByteArray(Charsets.UTF_8)) }
                }
                val code = conn.responseCode
                val stream = if (code >= 400) conn.errorStream else conn.inputStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val j = J.parse(text)
                if (code in 200..299) Res(true, code, j, "", "")
                else Res(false, code, j, j["error"].str("http_$code"), j["message"].str("Erro $code no servidor."))
            } catch (e: Exception) {
                Res(false, 0, J(null), "offline", "Sem conexão com o servidor.")
            } finally {
                try { conn?.disconnect() } catch (e: Exception) {}
            }
        }
    }
}
