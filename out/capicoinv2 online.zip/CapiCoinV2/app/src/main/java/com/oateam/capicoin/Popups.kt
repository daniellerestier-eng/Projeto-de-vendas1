package com.oateam.capicoin

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.sin

fun wrapText(s: String, size: Float, maxW: Float): List<String> {
    val out = ArrayList<String>()
    var line = ""
    for (word in s.split(" ")) {
        val tryL = if (line.isEmpty()) word else "$line $word"
        if (Ui.measure(tryL, size) > maxW && line.isNotEmpty()) { out.add(line); line = word } else line = tryL
    }
    if (line.isNotEmpty()) out.add(line)
    return out
}

/** Round "X" close button. */
class CloseBtn(val onClick: () -> Unit) {
    var x = 0f; var y = 0f; private var pressed = false
    fun draw(c: Canvas) {
        val p = Ui.p; p.shader = null; p.style = Paint.Style.FILL
        p.color = if (pressed) 0xFFB71C1C.toInt() else 0xFFE53935.toInt(); c.drawCircle(x, y, 46f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = Ui.OUTLINE; c.drawCircle(x, y, 46f, p)
        p.color = 0xFFFFFFFF.toInt(); p.strokeWidth = 11f; p.strokeCap = Paint.Cap.ROUND
        c.drawLine(x - 16f, y - 16f, x + 16f, y + 16f, p); c.drawLine(x + 16f, y - 16f, x - 16f, y + 16f, p)
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
    }
    fun touch(type: Int, px: Float, py: Float, g: Game): Boolean {
        val inside = (px - x) * (px - x) + (py - y) * (py - y) < 70f * 70f
        when (type) {
            Game.DOWN -> if (inside) { pressed = true; return true }
            Game.UP -> if (pressed) { pressed = false; if (inside) { g.audio.play("click"); onClick() }; return true }
        }
        return false
    }
}

// ============================================================================ Daily wheel
class WheelPopup(g: Game) : Popup(g), HudOnTop {
    private val colors = intArrayOf(0xFFE53935.toInt(), 0xFFFFB300.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFF8E24AA.toInt(), 0xFF00ACC1.toInt(), 0xFFFB8C00.toInt(), 0xFF212121.toInt())
    private var top = 0f; private val cx = 540f; private var cy = 0f; private val R = 380f
    private var theta = 0f; private var from = 0f; private var to = 0f; private var spinT = -1f; private var dur = 5f
    private var result = -1; private var lastIdx = 0; private var flick = 0f; private var done = false; private var waiting = false; private var doneT = 0f
    private var got: J = J(null)
    private val xBtn = CloseBtn { close() }
    private val spinBtn = Button(0f, 0f, 0f, 0f, "GIRAR!", 0xFFE53935.toInt()) { if (done) collect() else spin() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()

    override fun layout() {
        top = (g.H - 1500f) / 2 + 40f
        cy = top + 600f
        spinBtn.set(g.W / 2 - 230f, top + 1200f, 460f, 150f); spinBtn.textSize = 60f
        xBtn.x = g.W - 80f; xBtn.y = top - 10f
    }

    private fun segs(): List<J> = g.wheelInfo.list.ifEmpty { List(8) { J(null) } }

    private fun idxUnderPointer(th: Float): Int {
        val a = (((-th) % 360f) + 360f) % 360f
        return (floor((a + 22.5f) / 45f).toInt()) % 8
    }

    private fun spin() {
        val pr = g.prof ?: return
        if (spinT >= 0f || waiting || !pr.wheelReadyNow()) return
        waiting = true; spinBtn.enabled = false
        g.net.call("POST", "/api/wheel/spin", applyProfile = false) { res ->
            waiting = false
            if (!res.ok) { g.error(res); spinBtn.enabled = true; return@call }
            result = res.j["result"]["index"].int()
            got = res.j["result"]["got"]
            pendingProfile = res.j["profile"]
            from = theta
            val want = -result * 45f + rnd(-15f, 15f)
            val delta = (((want - from) % 360f) + 360f) % 360f
            to = from + 360f * (if (g.settings.turbo) 3 else 6) + delta
            dur = if (g.settings.turbo) 2.6f else 5f
            spinT = 0f
            g.audio.play("whoosh")
        }
    }
    private var pendingProfile: J? = null

    private fun collect() {
        g.celebrate(got, cx, cy)
        close()
    }

    override fun update(dt: Float) {
        super.update(dt)
        flick = (flick - dt * 6f).coerceAtLeast(0f)
        if (done) doneT += dt
        if (spinT >= 0f && !done) {
            spinT += dt
            val wind = 0.3f
            theta = if (spinT < wind) from - 18f * Ease.outCubic(spinT / wind)
            else { val k = clamp01((spinT - wind) / dur); (from - 18f) + (to - from + 18f) * (1f - (1f - k).pow(4)) }
            val idx = idxUnderPointer(theta)
            if (idx != lastIdx) { lastIdx = idx; flick = 1f; g.audio.play("tick", 0.8f, 1.2f, 30) }
            if (spinT >= wind + dur) { done = true; award() }
        } else if (!done && !waiting) theta += dt * 10f
    }

    private fun award() {
        pendingProfile?.let { g.applyProfile(it) }
        g.audio.play(if (result == 7) "jackpot" else "win"); g.audio.vibrate(120, 200)
        g.fx.confetti(if (result == 7) 150 else 60)
        spinBtn.label = "COLETAR"; spinBtn.enabled = true; spinBtn.pulse = true
    }

    override fun draw(c: Canvas) {
        val sc = begin(c, 30f, top - 60f, g.W - 30f, top + 1420f, 0xFF283593.toInt())
        ribbon(c, cx, top + 20f, 640f, "RODA DA SORTE", 0xFFE53935.toInt())
        Art.rays(c, cx, cy, R * 1.6f, g.time, 0xFFFFF59D.toInt(), 18, 0.5f)
        // stand
        path.reset(); path.moveTo(cx - 70f, cy + R - 20f); path.lineTo(cx + 70f, cy + R - 20f); path.lineTo(cx + 170f, cy + R + 140f); path.lineTo(cx - 170f, cy + R + 140f); path.close()
        p.color = -1; p.shader = LinearGradient(cx - 170f, 0f, cx + 170f, 0f, 0xFF8D6E00.toInt(), 0xFFFFE082.toInt(), Shader.TileMode.MIRROR); c.drawPath(path, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = Ui.OUTLINE; c.drawPath(path, p); p.style = Paint.Style.FILL
        // rim
        p.shader = null; p.color = 0x77000000; c.drawCircle(cx, cy + 22f, R + 44f, p)
        p.color = -1; p.shader = LinearGradient(cx - R, cy - R, cx + R, cy + R, intArrayOf(0xFFFFF8E1.toInt(), 0xFFFFC107.toInt(), 0xFF8D6E00.toInt(), 0xFFFFE082.toInt()), floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R + 44f, p); p.shader = null
        p.color = 0xFF4A148C.toInt(); c.drawCircle(cx, cy, R + 8f, p)
        r.set(cx - R, cy - R, cx + R, cy + R)
        val ss = segs()
        for (i in 0 until 8) {
            val col = colors[i]
            p.color = -1; p.shader = RadialGradient(cx, cy, R, intArrayOf(lighten(col, 0.45f), col, darken(col, 0.25f)), floatArrayOf(0f, 0.7f, 1f), Shader.TileMode.CLAMP)
            c.drawArc(r, theta + i * 45f - 90f - 22.5f, 45f, true, p); p.shader = null
            if (done && i == result) { p.color = withAlpha(0xFFFFFFFF.toInt(), (90 + 90 * sin(g.time * 10f)).toInt()); c.drawArc(r, theta + i * 45f - 90f - 22.5f, 45f, true, p) }
        }
        for (i in 0 until 8) {
            val a = Math.toRadians((theta + i * 45f - 90f - 22.5f).toDouble())
            p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = 0xFFFFE082.toInt()
            c.drawLine(cx, cy, cx + (Math.cos(a) * R).toFloat(), cy + (Math.sin(a) * R).toFloat(), p); p.style = Paint.Style.FILL
            val px = cx + (Math.cos(a) * (R + 22f)).toFloat(); val py = cy + (Math.sin(a) * (R + 22f)).toFloat()
            p.color = -1; p.shader = RadialGradient(px - 4f, py - 4f, 16f, -1, 0xFFB8860B.toInt(), Shader.TileMode.CLAMP); c.drawCircle(px, py, 13f, p); p.shader = null
        }
        for (i in 0 until 8) {
            val give = ss[i]["give"]
            c.save(); c.rotate(theta + i * 45f, cx, cy)
            val iy = cy - R * 0.76f; val ty = cy - R * 0.48f
            when {
                i == 7 -> { Art.symbol(c, Sym.CAPI, cx, iy, 120f); Ui.text(c, "JACKPOT", cx, ty, 32f, 0xFFFFEB3B.toInt(), maxW = 150f) }
                give["spins"].int() > 0 -> { Art.capsule(c, cx, iy, 0.4f); Ui.text(c, give["spins"].int().toString(), cx, ty, 58f); Ui.text(c, "giros", cx, ty + 44f, 26f, ow = 4f) }
                give["coins"].long() > 0 -> { Art.coin(c, cx, iy, 36f); Ui.text(c, Fmt.n(give["coins"].long()), cx, ty, 42f, maxW = 140f) }
                give["gems"].int() > 0 -> { Art.iconGem(c, cx, iy, 86f); Ui.text(c, give["gems"].int().toString(), cx, ty, 54f); Ui.text(c, "gemas", cx, ty + 42f, 26f, ow = 4f) }
                give["petiscos"].int() > 0 -> { Art.iconPetisco(c, cx, iy, 100f); Ui.text(c, "petisco", cx, ty + 10f, 30f, ow = 4f) }
                else -> { Art.iconShield(c, cx, iy + 6f, 90f, true); Ui.text(c, "escudo", cx, ty + 20f, 30f, ow = 4f) }
            }
            c.restore()
        }
        for (i in 0 until 28) {
            val a = Math.toRadians((i * (360.0 / 28) + g.time * (if (spinT >= 0f && !done) 120f else 25f)).toDouble())
            val bx = cx + (Math.cos(a) * (R + 30f)).toFloat(); val by = cy + (Math.sin(a) * (R + 30f)).toFloat()
            val on = (i + (g.time * 10f).toInt()) % 2 == 0
            if (on) Art.glow(c, bx, by, 22f, 0xFFFFFDE7.toInt(), 0.8f)
            p.color = if (on) -1 else 0xFFFFCC80.toInt(); c.drawCircle(bx, by, 8f, p)
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.color = Ui.OUTLINE; c.drawCircle(cx, cy, R + 44f, p); c.drawCircle(cx, cy, R, p); p.style = Paint.Style.FILL
        // hub
        p.color = -1; p.shader = RadialGradient(cx - 20f, cy - 20f, 110f, 0xFFFFF59D.toInt(), 0xFFFF8F00.toInt(), Shader.TileMode.CLAMP); c.drawCircle(cx, cy, 92f, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = Ui.OUTLINE; c.drawCircle(cx, cy, 92f, p); p.style = Paint.Style.FILL
        c.save(); c.translate(cx, cy + 118f); c.scale(0.4f, 0.4f); Art.capi(c, 0f, 0f, 1f, g.time, if (done) Art.Mood.HAPPY else Art.Mood.WOW, 0, 0, headOnly = true); c.restore()
        // pointer
        c.save(); c.rotate(-flick * 24f, cx, cy - R - 40f)
        path.reset(); path.moveTo(cx - 50f, cy - R - 84f); path.lineTo(cx + 50f, cy - R - 84f); path.lineTo(cx, cy - R + 36f); path.close()
        p.color = -1; p.shader = LinearGradient(cx - 50f, 0f, cx + 50f, 0f, 0xFFFF5252.toInt(), 0xFFB71C1C.toInt(), Shader.TileMode.CLAMP); c.drawPath(path, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = Ui.OUTLINE; c.drawPath(path, p); p.style = Paint.Style.FILL
        Art.gem(c, cx, cy - R - 62f, 0.24f, 0xFFFFEB3B.toInt())
        c.restore()
        // prize card
        if (done) {
            val k = Ease.outBack(clamp01((doneT - 0.2f) / 0.4f))
            c.save(); c.scale(k, k, cx, cy)
            Art.rays(c, cx, cy, 420f, g.time * 2f, 0xFFFFF59D.toInt(), 16, 0.9f)
            Ui.panel(c, cx - 320f, cy - 100f, cx + 320f, cy + 100f, 0xFF6A1B9A.toInt(), 50f, bw = 8f)
            UiX.rewards(c, got, cx, cy, 76f)
            c.restore()
        }
        val pr = g.prof
        if (pr != null && (pr.wheelReadyNow() || spinT >= 0f || waiting)) { spinBtn.visible = true; spinBtn.pulse = spinT < 0f || done; spinBtn.draw(c, g.time) }
        else {
            spinBtn.visible = false
            val left = pr?.let { it.wheelResetMs - (System.currentTimeMillis() - it.receivedAt) } ?: 0L
            Ui.text(c, "Próxima rodada em", g.W / 2, top + 1210f, 44f, 0xFFE1BEE7.toInt())
            Ui.text(c, Fmt.clock(left), g.W / 2, top + 1290f, 76f, gold = true)
        }
        if (spinT < 0f || done) xBtn.draw(c)
        c.restoreToCount(sc)
    }

    override fun touch(type: Int, x: Float, y: Float) {
        if ((spinT < 0f || done) && xBtn.touch(type, x, y, g)) return
        spinBtn.touch(type, x, y, g)
    }
    override fun back(): Boolean { if (done) collect() else if (spinT < 0f) close(); return true }
}

// ============================================================================ Daily login bonus
class DailyBonusPopup(g: Game, private val bonus: J) : Popup(g), HudOnTop {
    private var top = 0f
    private val ok = Button(0f, 0f, 0f, 0f, "COLETAR", 0xFF43A047.toInt()) { g.celebrate(bonus["reward"], g.W / 2, top + 640f); g.audio.play("coins_big"); close() }
    init { ok.pulse = true }
    override fun layout() { top = (g.H - 1200f) / 2; ok.set(g.W / 2 - 220f, top + 990f, 440f, 140f) }
    override fun draw(c: Canvas) {
        val sc = begin(c, 40f, top, g.W - 40f, top + 1180f, 0xFF00897B.toInt())
        ribbon(c, g.W / 2, top + 20f, 620f, "BÔNUS DIÁRIO", 0xFFFB8C00.toInt())
        val day = bonus["day"].int(1)
        Ui.text(c, "Dia $day de 7 · sequência: ${bonus["streak"].int(1)}", g.W / 2, top + 130f, 42f)
        val table = bonus["table"].list
        val w = (g.W - 160f) / 7
        for (i in 0 until 7) {
            val x = 80f + i * w
            val cur = i + 1 == day
            val past = i + 1 < day
            Ui.panel(c, x + 4f, top + 190f, x + w - 4f, top + 380f, if (cur) 0xFFFFB300.toInt() else if (past) 0xFF2E7D32.toInt() else 0xFF37474F.toInt(), 22f, bw = 5f)
            Ui.text(c, "Dia ${i + 1}", x + w / 2, top + 222f, 24f, ow = 4f)
            val give = table.getOrNull(i) ?: J(null)
            when { give["gems"].int() > 0 -> Art.iconGem(c, x + w / 2, top + 290f, 64f); give["petiscos"].int() > 0 -> Art.iconPetisco(c, x + w / 2, top + 290f, 70f); else -> Art.capsule(c, x + w / 2, top + 290f, 0.3f) }
            Ui.text(c, give["spins"].int().toString(), x + w / 2, top + 352f, 30f, ow = 5f)
            if (past) { Ui.p.color = 0xFF69F0AE.toInt(); Ui.text(c, "✔", x + w - 20f, top + 200f, 40f, 0xFF69F0AE.toInt(), ow = 5f) }
        }
        Art.rays(c, g.W / 2, top + 640f, 360f, g.time, 0xFFFFF59D.toInt(), 14, 0.7f)
        Art.chest(c, g.W / 2, top + 650f, 1.2f, 0.6f + 0.1f * sin(g.time * 4f), if (day >= 7) 2 else 1)
        UiX.rewards(c, bonus["reward"], g.W / 2, top + 870f, 60f)
        ok.draw(c, g.time)
        c.restoreToCount(sc)
    }
    override fun touch(type: Int, x: Float, y: Float) { ok.touch(type, x, y, g) }
    override fun back(): Boolean { g.celebrate(bonus["reward"], g.W / 2, top + 640f); close(); return true }
}

// ============================================================================ No spins
class NoSpinsPopup(g: Game) : Popup(g) {
    private var top = 0f
    private val buy = Button(0f, 0f, 0f, 0f, "COMPRAR GIROS", 0xFFE53935.toInt()) { close(); onClosed = { g.show(ShopPopup(g, ShopPopup.TAB_SPINS)) } }
    private val wheel = Button(0f, 0f, 0f, 0f, "RODA DA SORTE", 0xFFFB8C00.toInt()) { close(); onClosed = { g.show(WheelPopup(g)) } }
    private val friends = Button(0f, 0f, 0f, 0f, "PRESENTES DE AMIGOS", 0xFF7B1FA2.toInt()) { close(); onClosed = { g.show(FriendsPopup(g)) } }
    private val ok = Button(0f, 0f, 0f, 0f, "ESPERAR", 0xFF546E7A.toInt()) { close() }
    private val btns = listOf(buy, wheel, friends, ok)
    override fun layout() {
        top = (g.H - 1400f) / 2
        buy.set(110f, top + 760f, g.W - 220f, 120f); buy.pulse = true
        wheel.set(110f, top + 900f, g.W - 220f, 110f)
        friends.set(110f, top + 1030f, g.W - 220f, 110f)
        ok.set(g.W / 2 - 160f, top + 1160f, 320f, 100f)
    }
    override fun draw(c: Canvas) {
        val pr = g.prof
        val sc = begin(c, 60f, top, g.W - 60f, top + 1320f, 0xFF6A1B9A.toInt())
        ribbon(c, g.W / 2, top + 20f, 560f, "SEM GIROS!", 0xFFE53935.toInt())
        Art.capi(c, g.W / 2, top + 520f, 0.85f, g.time, Art.Mood.SAD, 0, 0)
        if (pr != null) Ui.text(c, "Próximo giro em " + Fmt.clock(pr.msToNextSpin()), g.W / 2, top + 600f, 52f)
        Ui.text(c, "1 giro a cada 3 min (até ${pr?.maxSpins ?: 80})", g.W / 2, top + 670f, 36f, 0xFFE1BEE7.toInt())
        wheel.visible = pr?.wheelReadyNow() == true; wheel.pulse = true
        friends.badge = if ((pr?.giftsPending ?: 0) > 0) pr!!.giftsPending.toString() else null
        for (b in btns) b.draw(c, g.time)
        c.restoreToCount(sc)
        if (pr != null && pr.spinsNow() > 0 && !closing && t > 1f) close()
    }
    override fun touch(type: Int, x: Float, y: Float) { for (b in btns) if (b.touch(type, x, y, g)) return }
}

// ============================================================================ Settings
class SettingsPopup(g: Game) : Popup(g) {
    private var top = 0f
    private val s = g.settings
    private val music = Button(0f, 0f, 0f, 0f, "", 0xFF43A047.toInt()) { s.music = !s.music; g.audio.refreshMusic() }
    private val sfx = Button(0f, 0f, 0f, 0f, "", 0xFF43A047.toInt()) { s.sfx = !s.sfx }
    private val vibe = Button(0f, 0f, 0f, 0f, "", 0xFF43A047.toInt()) { s.vibe = !s.vibe; g.audio.vibrate(60, 200) }
    private val notif = Button(0f, 0f, 0f, 0f, "", 0xFF43A047.toInt()) { s.notifs = !s.notifs; if (s.notifs) g.host.requestNotifications() }
    private val turbo = Button(0f, 0f, 0f, 0f, "", 0xFF43A047.toInt()) { s.turbo = !s.turbo }
    private val account = Button(0f, 0f, 0f, 0f, "Minha conta", 0xFF1E88E5.toInt()) { close(); onClosed = { g.show(ProfilePopup(g)) } }
    private val story = Button(0f, 0f, 0f, 0f, "Rever história", 0xFF7B1FA2.toInt()) { close(); onClosed = { g.goto(CutsceneScene(g, Scripts.intro()) { g.goto(g.slot) }) } }
    private val server = Button(0f, 0f, 0f, 0f, "Servidor", 0xFF546E7A.toInt()) {
        g.host.prompt("Endereço do servidor", listOf(Host.Field("URL", Host.Field.TEXT, s.serverUrl)), "SALVAR") { v, _ ->
            if (v != null && v[0].isNotBlank()) { var u = v[0].trim(); if (!u.startsWith("http")) u = "http://$u"; s.serverUrl = u; g.logout() }
        }
    }
    private val xBtn = CloseBtn { close() }
    private val toggles = listOf(music, sfx, vibe, notif, turbo)
    private val btns = toggles + listOf(account, story, server)

    override fun layout() {
        top = (g.H - 1440f) / 2
        for ((i, b) in toggles.withIndex()) b.set(120f, top + 170f + i * 140f, g.W - 240f, 112f)
        account.set(120f, top + 900f, g.W - 240f, 112f)
        story.set(120f, top + 1030f, (g.W - 260f) / 2, 100f); story.textSize = 34f
        server.set(140f + (g.W - 260f) / 2, top + 1030f, (g.W - 260f) / 2, 100f); server.textSize = 34f
        xBtn.x = g.W - 100f; xBtn.y = top + 10f
    }
    override fun draw(c: Canvas) {
        val sc = begin(c, 60f, top - 30f, g.W - 60f, top + 1380f, 0xFF455A64.toInt())
        ribbon(c, g.W / 2, top + 20f, 480f, "AJUSTES", 0xFF1E88E5.toInt())
        fun tg(b: Button, name: String, on: Boolean) { b.label = "$name: " + if (on) "LIGADO" else "DESLIGADO"; b.color = if (on) 0xFF43A047.toInt() else 0xFF757575.toInt() }
        tg(music, "Música", s.music); tg(sfx, "Sons", s.sfx); tg(vibe, "Vibração", s.vibe); tg(notif, "Notificações", s.notifs); tg(turbo, "Turbo", s.turbo)
        for (b in btns) b.draw(c, g.time)
        Ui.text(c, s.serverUrl, g.W / 2, top + 1180f, 28f, 0xFFB0BEC5.toInt(), maxW = g.W - 200f, ow = 4f)
        Ui.text(c, "Capi Coin v2.0 · OA Team", g.W / 2, top + 1250f, 34f, 0xFFECEFF1.toInt(), ow = 4f)
        xBtn.draw(c)
        c.restoreToCount(sc)
    }
    override fun touch(type: Int, x: Float, y: Float) { if (xBtn.touch(type, x, y, g)) return; for (b in btns) if (b.touch(type, x, y, g)) return }
}

// ============================================================================ Profile / account
class ProfilePopup(g: Game) : Popup(g) {
    private var top = 0f
    private val xBtn = CloseBtn { close() }
    private val rename = Button(0f, 0f, 0f, 0f, "Trocar nome", 0xFF1E88E5.toInt()) {
        g.host.prompt("Seu nome no jogo", listOf(Host.Field("Nome", Host.Field.TEXT, g.prof?.name ?: "")), "SALVAR") { v, _ ->
            if (v != null) g.net.call("POST", "/api/profile/name", mapOf("name" to v[0])) { r -> if (!r.ok) g.error(r) }
        }
    }
    private val linkGoogle = Button(0f, 0f, 0f, 0f, "Vincular Google", 0xFFFFFFFF.toInt()) {
        if (!g.googleOn) g.toast(Game.T_INFO, "Login com Google", "Ainda não configurado no servidor.")
        else g.host.openUrl(g.net.base + "/auth/google/start?link=" + (g.settings.token ?: ""))
    }
    private val linkEmail = Button(0f, 0f, 0f, 0f, "Vincular e-mail", 0xFF1E88E5.toInt()) {
        g.host.prompt("Salvar com e-mail", listOf(Host.Field("E-mail", Host.Field.EMAIL), Host.Field("Senha (mín. 6)", Host.Field.PASSWORD)), "SALVAR") { v, _ ->
            if (v != null) g.net.call("POST", "/auth/register", mapOf("email" to v[0], "password" to v[1], "name" to (g.prof?.name ?: ""))) { r ->
                if (r.ok) { g.settings.token = r.j["token"].str(); g.toast(Game.T_INFO, "Conta salva!", "Agora você pode entrar com seu e-mail."); g.refreshProfile() } else g.error(r)
            }
        }
    }
    private val copy = Button(0f, 0f, 0f, 0f, "Copiar", 0xFF7B1FA2.toInt()) { g.prof?.let { g.host.copy(it.friendCode); g.toast(Game.T_FRIEND, "Copiado!", it.friendCode) } }
    private val logout = Button(0f, 0f, 0f, 0f, "Sair da conta", 0xFFC62828.toInt()) {
        if (g.prof?.guest == true) g.toast(Game.T_INFO, "Atenção", "Vincule Google ou e-mail antes de sair, ou perderá a ilha!")
        else g.logout()
    }
    private val btns = listOf(rename, linkGoogle, linkEmail, copy, logout)
    private val avatarRects = Array(6) { RectF() }

    override fun layout() {
        top = (g.H - 1500f) / 2
        rename.set(420f, top + 230f, 380f, 90f); rename.textSize = 34f
        copy.set(g.W - 330f, top + 560f, 220f, 90f); copy.textSize = 34f
        linkGoogle.set(120f, top + 1000f, g.W - 240f, 110f); linkGoogle.textColor = 0xFF37474F.toInt(); linkGoogle.textOutline = -1
        linkEmail.set(120f, top + 1130f, g.W - 240f, 110f)
        logout.set(g.W / 2 - 200f, top + 1290f, 400f, 100f); logout.textSize = 36f
        for (i in 0 until 6) avatarRects[i].set(130f + i * 140f, top + 380f, 250f + i * 140f, top + 500f)
        xBtn.x = g.W - 90f; xBtn.y = top + 10f
    }
    override fun draw(c: Canvas) {
        val pr = g.prof ?: return
        val sc = begin(c, 50f, top - 30f, g.W - 50f, top + 1440f, 0xFF3949AB.toInt())
        ribbon(c, g.W / 2, top + 20f, 520f, "MEU PERFIL", 0xFF7B1FA2.toInt())
        Art.avatar(c, 230f, top + 230f, 100f, pr.avatar)
        Ui.text(c, pr.name, 420f, top + 170f, 60f, align = Paint.Align.LEFT, gold = true, maxW = 520f)
        rename.draw(c, g.time)
        for (i in 0 until 6) {
            val rc = avatarRects[i]
            Art.avatar(c, rc.centerX(), rc.centerY(), 54f, i, if (i == pr.avatar) 0xFF69F0AE.toInt() else 0xFFFFD54F.toInt())
        }
        Ui.panel(c, 110f, top + 540f, g.W - 110f, top + 670f, 0xFF283593.toInt(), 30f, bw = 5f)
        Ui.text(c, "Seu código de amigo", 150f, top + 575f, 30f, 0xFFC5CAE9.toInt(), align = Paint.Align.LEFT, ow = 4f)
        Ui.text(c, pr.friendCode, 150f, top + 628f, 54f, 0xFFFFEB3B.toInt(), align = Paint.Align.LEFT)
        copy.draw(c, g.time)
        val st = pr.stats
        val lines = listOf("Giros: ${st["spins"].int()}", "Ataques: ${st["attacks"].int()}", "Saques: ${st["raids"].int()}", "Vilas: ${st["villages"].int()}", "Maior prêmio: ${Fmt.n(st["bestWin"].long())}", "Defesas: ${st["blocks"].int()}")
        for ((i, s) in lines.withIndex()) Ui.text(c, s, if (i % 2 == 0) 130f else g.W / 2 + 50f, top + 720f + (i / 2) * 60f, 34f, align = Paint.Align.LEFT, ow = 5f, maxW = g.W / 2 - 150f)
        if (pr.guest) {
            Ui.text(c, "Conta de convidado: salve sua ilha!", g.W / 2, top + 950f, 38f, 0xFFFFCDD2.toInt())
            linkGoogle.visible = true; linkEmail.visible = true
        } else {
            linkGoogle.visible = !pr.google; linkEmail.visible = false
            Ui.text(c, (pr.email ?: "Conta Google") + (if (pr.google) " · Google ✔" else ""), g.W / 2, top + 950f, 36f, 0xFFB9F6CA.toInt(), maxW = g.W - 200f)
        }
        for (b in btns) b.draw(c, g.time)
        if (linkGoogle.visible) Art.iconGoogle(c, linkGoogle.x + 80f, linkGoogle.y + linkGoogle.h / 2, 64f)
        xBtn.draw(c)
        c.restoreToCount(sc)
    }
    override fun touch(type: Int, x: Float, y: Float) {
        if (xBtn.touch(type, x, y, g)) return
        for (b in btns) if (b.touch(type, x, y, g)) return
        if (type == Game.UP) for (i in 0 until 6) if (avatarRects[i].contains(x, y)) {
            g.audio.play("pop")
            g.net.call("POST", "/api/profile/name", mapOf("name" to (g.prof?.name ?: "Capi"), "avatar" to i)) { r -> if (!r.ok) g.error(r) }
        }
    }
}

// ============================================================================ Inbox (events)
class InboxPopup(g: Game) : Popup(g) {
    private var top = 0f
    private var events: List<J>? = null
    private var scroll = 0f; private var dragY = -1f; private var dragStart = 0f
    private val xBtn = CloseBtn { close() }
    override fun layout() { top = (g.H - 1500f) / 2; xBtn.x = g.W - 90f; xBtn.y = top + 10f }
    init {
        g.net.call("GET", "/api/events") { r ->
            events = if (r.ok) r.j["events"].list else emptyList()
            if (!r.ok) g.error(r) else g.net.call("GET", "/api/profile")
        }
    }
    override fun draw(c: Canvas) {
        val sc = begin(c, 40f, top - 30f, g.W - 40f, top + 1460f, 0xFF37474F.toInt())
        ribbon(c, g.W / 2, top + 20f, 520f, "EVENTOS", 0xFFE53935.toInt())
        val ev = events
        if (ev == null) UiX.spinner(c, g.W / 2, top + 600f, 50f, g.time)
        else if (ev.isEmpty()) {
            Art.capi(c, g.W / 2, top + 700f, 0.8f, g.time, Art.Mood.HAPPY, 0, 0)
            Ui.text(c, "Tudo tranquilo na ilha!", g.W / 2, top + 800f, 46f)
        } else {
            val save = c.save()
            c.clipRect(60f, top + 110f, g.W - 60f, top + 1400f)
            var y = top + 130f - scroll
            val now = System.currentTimeMillis()
            for (e in ev) {
                if (y > top + 1400f) break
                if (y + 150f > top + 110f) {
                    val type = e["type"].str()
                    val who = e["actor"].str("Alguém")
                    val col = when (type) { "attack", "raid" -> 0xFF8E1F1F.toInt(); "payment" -> 0xFF1B5E20.toInt(); "block" -> 0xFF0D47A1.toInt(); else -> 0xFF4A148C.toInt() }
                    Ui.panel(c, 70f, y, g.W - 70f, y + 140f, col, 30f, bw = 5f, gloss = false)
                    val ix = 150f; val iy = y + 70f
                    when (type) {
                        "attack" -> Art.iconHammer(c, ix, iy, 110f)
                        "raid" -> Art.symbol(c, Sym.RAID, ix, iy, 120f)
                        "block" -> Art.iconShield(c, ix, iy, 96f, true)
                        "gift" -> Art.iconGift(c, ix, iy, 96f)
                        "friend_req", "friend_ok" -> Art.iconFriends(c, ix, iy, 100f)
                        "payment" -> Art.iconPix(c, ix, iy, 90f)
                        "pet_unlock" -> Art.iconPaw(c, ix, iy, 90f)
                        else -> Art.iconBell(c, ix, iy, 80f, 0f, false)
                    }
                    val text = when (type) {
                        "attack" -> "$who quebrou: ${e["data"]["building"].str("um prédio")}"
                        "raid" -> "$who saqueou ${Fmt.n(e["data"]["amount"].long())} moedas"
                        "block" -> "$who tentou atacar, mas você bloqueou!"
                        "gift" -> "$who te mandou um presente"
                        "friend_req" -> "$who quer ser seu amigo"
                        "friend_ok" -> "$who aceitou sua amizade"
                        "payment" -> "Compra aprovada: ${e["data"]["item"].str()}"
                        "pet_unlock" -> "Novo pet: ${e["data"]["name"].str()}"
                        else -> type
                    }
                    Ui.text(c, text, 230f, y + 52f, 36f, align = Paint.Align.LEFT, maxW = g.W - 330f, ow = 5f)
                    val sub = (if (type == "attack" || type == "raid") "Gire 3 martelos para se VINGAR! · " else "") + Fmt.ago(now - e["at"].long())
                    Ui.text(c, sub, 230f, y + 100f, 28f, 0xFFFFCC80.toInt(), align = Paint.Align.LEFT, maxW = g.W - 330f, ow = 4f)
                }
                y += 156f
            }
            c.restoreToCount(save)
        }
        xBtn.draw(c)
        c.restoreToCount(sc)
    }
    override fun touch(type: Int, x: Float, y: Float) {
        if (xBtn.touch(type, x, y, g)) return
        val n = events?.size ?: 0
        when (type) {
            Game.DOWN -> { dragY = y; dragStart = scroll }
            Game.MOVE -> if (dragY >= 0) scroll = (dragStart - (y - dragY)).coerceIn(0f, maxOf(0f, n * 156f - 1240f))
            Game.UP -> dragY = -1f
        }
    }
}

// ============================================================================ Attack target picker
class TargetPopup(g: Game, private val options: List<Target>, private val pick: (Long) -> Unit) : Popup(g) {
    private var top = 0f
    private val xBtn = CloseBtn { close() }
    override fun layout() { top = (g.H - 1400f) / 2; xBtn.x = g.W - 90f; xBtn.y = top + 10f }
    override fun draw(c: Canvas) {
        val sc = begin(c, 40f, top - 30f, g.W - 40f, top + 1380f, 0xFF4527A0.toInt())
        ribbon(c, g.W / 2, top + 20f, 560f, "ESCOLHA O ALVO", 0xFFE53935.toInt())
        for ((i, t) in options.take(9).withIndex()) {
            val y = top + 120f + i * 140f
            Ui.panel(c, 70f, y, g.W - 70f, y + 124f, if (t.revenge) 0xFF8E1F1F.toInt() else if (t.friend) 0xFF6A1B9A.toInt() else 0xFF283593.toInt(), 30f, bw = 5f, gloss = false)
            Art.avatar(c, 140f, y + 62f, 46f, t.avatar)
            Ui.text(c, t.name, 210f, y + 44f, 42f, align = Paint.Align.LEFT, maxW = 480f)
            Ui.text(c, "Vila ${t.village} · ${t.theme.name}", 210f, y + 92f, 28f, 0xFFC5CAE9.toInt(), align = Paint.Align.LEFT, maxW = 480f, ow = 4f)
            Ui.pill(c, g.W - 290f, y + 38f, g.W - 100f, y + 88f, t.tagColor)
            Ui.text(c, t.tag, g.W - 195f, y + 63f, 28f, maxW = 170f, ow = 4f)
        }
        xBtn.draw(c)
        c.restoreToCount(sc)
    }
    override fun touch(type: Int, x: Float, y: Float) {
        if (xBtn.touch(type, x, y, g)) return
        if (type != Game.UP) return
        for ((i, t) in options.take(9).withIndex()) {
            val yy = top + 120f + i * 140f
            if (y in yy..(yy + 124f) && x in 70f..(g.W - 70f)) { g.audio.play("click"); close(); pick(t.id); return }
        }
    }
}

// ============================================================================ Village complete → voyage
class VillageCompletePopup(g: Game) : Popup(g) {
    private var top = 0f
    private var busy = false
    private val next = Button(0f, 0f, 0f, 0f, "NAVEGAR!", 0xFF43A047.toInt()) { advance() }
    init { dismissible = false; next.pulse = true }
    override fun layout() { top = (g.H - 1300f) / 2; next.set(g.W / 2 - 260f, top + 1080f, 520f, 150f) }
    private fun advance() {
        if (busy) return
        busy = true; next.enabled = false
        g.net.call("POST", "/api/village/next") { r ->
            if (!r.ok) { busy = false; next.enabled = true; g.error(r); return@call }
            val v = r.j["result"]["village"].int(2)
            val pets = r.j["result"]["unlockedPets"].list.map { it.str() }
            g.audio.play("complete")
            close()
            onClosed = {
                g.goto(CutsceneScene(g, Scripts.voyage(v)) {
                    g.goto(g.village)
                    if (pets.isNotEmpty()) g.post { g.show(DialogPopup(g, listOf((if (pets[0] == "quati") Who.QUATI else if (pets[0] == "onca") Who.ONCA else Who.TUCANO) to "Oba! Agora sou seu pet! Me dê um petisco na tela de PETS e eu te ajudo!"))) }
                })
            }
        }
    }
    override fun draw(c: Canvas) {
        val pr = g.prof
        val sc = begin(c, 50f, top, g.W - 50f, top + 1280f, 0xFF00838F.toInt())
        Art.rays(c, g.W / 2, top + 500f, 650f, g.time, 0xFFFFF59D.toInt(), 18, 0.8f)
        ribbon(c, g.W / 2, top + 20f, 660f, "VILA COMPLETA!", 0xFFFB8C00.toInt())
        val jy = -kotlin.math.abs(sin(g.time * 4f)) * 50f
        Art.capi(c, g.W / 2, top + 640f + jy, 1f, g.time, Art.Mood.HAPPY, 1, 0, swing = sin(g.time * 5f) * 20f)
        Ui.text(c, "Prêmio da viagem:", g.W / 2, top + 740f, 48f)
        val v = pr?.village ?: 1
        UiX.rewards(c, J(mapOf("spins" to (30 + v * 5).toLong(), "gems" to 10L)), g.W / 2, top + 830f, 66f)
        Ui.text(c, "Próxima ilha: ${Themes.forVillage(v + 1).name}", g.W / 2, top + 950f, 44f, 0xFFB2EBF2.toInt())
        next.draw(c, g.time)
        c.restoreToCount(sc)
    }
    override fun touch(type: Int, x: Float, y: Float) { next.touch(type, x, y, g) }
}
