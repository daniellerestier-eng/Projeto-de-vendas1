package com.oateam.capicoin

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.sin

/** Story characters: the villain Barão Tatu, the three pets and the little boat. */
object Chars {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val o = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND }
    private val path = Path()
    private val r = RectF()
    private const val INK = Art.INK

    private fun ol(w: Float, col: Int = INK) { o.shader = null; o.pathEffect = null; o.strokeWidth = w; o.color = col }
    private fun grad(x0: Float, y0: Float, x1: Float, y1: Float, c0: Int, c1: Int) { p.color = -1; p.shader = LinearGradient(x0, y0, x1, y1, c0, c1, Shader.TileMode.CLAMP) }
    private fun rad(x: Float, y: Float, rr: Float, c0: Int, c1: Int) { p.color = -1; p.shader = RadialGradient(x, y, rr, c0, c1, Shader.TileMode.CLAMP) }

    object VMood { const val SMIRK = 0; const val LAUGH = 1; const val ANGRY = 2 }

    /** Barão Tatu: armadillo villain with top hat, monocle, mustache and cape. Feet at (x,y). */
    fun barao(c: Canvas, x: Float, y: Float, s: Float, t: Float, mood: Int, flip: Boolean = false) {
        c.save(); c.translate(x, y); c.scale(if (flip) -s else s, s)
        val bob = sin(t * 2.2f) * 5f + (if (mood == VMood.LAUGH) sin(t * 22f) * 6f else 0f)
        p.shader = null; p.color = 0x44000000; c.drawOval(-120f, -16f, 120f, 16f, p)
        // cape
        path.reset(); path.moveTo(-70f, -250f + bob); path.cubicTo(-170f, -150f, -150f, -40f, -120f, -10f); path.lineTo(120f, -10f); path.cubicTo(150f, -40f, 170f, -150f, 70f, -250f + bob); path.close()
        grad(0f, -250f, 0f, -10f, 0xFF7B1FA2.toInt(), 0xFF38006B.toInt()); c.drawPath(path, p); p.shader = null
        ol(7f); c.drawPath(path, o)
        p.color = 0xFFC62828.toInt(); r.set(-110f, -60f, 110f, -10f); c.drawArc(r, 0f, 180f, true, p)
        // legs
        p.color = 0xFF6D5A4B.toInt()
        c.drawOval(-70f, -40f, -20f, 6f, p); c.drawOval(20f, -40f, 70f, 6f, p)
        ol(6f); c.drawOval(-70f, -40f, -20f, 6f, o); c.drawOval(20f, -40f, 70f, 6f, o)
        c.save(); c.translate(0f, bob * 0.6f)
        // shell body
        r.set(-110f, -255f, 110f, -24f)
        rad(-30f, -200f, 200f, 0xFFB8A48E.toInt(), 0xFF6B5846.toInt()); c.drawOval(r, p); p.shader = null
        ol(8f); c.drawOval(r, o)
        ol(5f, 0xFF4E3E31.toInt())
        for (k in -2..2) { r.set(-60f + k * 34f - 30f, -250f, -60f + k * 34f + 150f, -30f); c.drawArc(r, 110f, 140f, false, o) }
        p.color = 0xFFE6D3B3.toInt(); c.drawOval(-55f, -150f, 55f, -40f, p)
        // vest buttons
        p.color = 0xFFFFD54F.toInt(); c.drawCircle(0f, -120f, 7f, p); c.drawCircle(0f, -90f, 7f, p); c.drawCircle(0f, -60f, 7f, p)
        // arms + cane
        p.color = 0xFF8D7B6A.toInt()
        c.save(); c.rotate(-20f, -95f, -170f); c.drawOval(-125f, -180f, -80f, -90f, p); ol(6f); c.drawOval(-125f, -180f, -80f, -90f, o); c.restore()
        ol(10f, INK); c.drawLine(118f, -150f, 118f, 0f, o); ol(6f, 0xFF3E2723.toInt()); c.drawLine(118f, -150f, 118f, 0f, o)
        p.color = 0xFFFFD54F.toInt(); c.drawCircle(118f, -156f, 14f, p); ol(5f); c.drawCircle(118f, -156f, 14f, o)
        p.color = 0xFF8D7B6A.toInt(); c.drawOval(84f, -175f, 128f, -125f, p); ol(6f); c.drawOval(84f, -175f, 128f, -125f, o)
        c.restore()
        c.save(); c.translate(0f, bob)
        // ears
        for (sx in floatArrayOf(-1f, 1f)) {
            path.reset(); path.moveTo(sx * 40f, -370f); path.quadTo(sx * 92f, -430f, sx * 92f, -372f); path.quadTo(sx * 80f, -350f, sx * 52f, -350f); path.close()
            p.color = 0xFF8D7B6A.toInt(); c.drawPath(path, p); ol(6f); c.drawPath(path, o)
        }
        // head (wide top narrowing into snout)
        path.reset(); path.moveTo(-74f, -330f); path.cubicTo(-80f, -400f, 80f, -400f, 74f, -330f)
        path.cubicTo(70f, -290f, 32f, -270f, 20f, -220f); path.quadTo(0f, -200f, -20f, -220f); path.cubicTo(-32f, -270f, -70f, -290f, -74f, -330f); path.close()
        rad(-20f, -360f, 160f, 0xFFC9B8A3.toInt(), 0xFF7E6A57.toInt()); c.drawPath(path, p); p.shader = null
        ol(8f); c.drawPath(path, o)
        // nose
        p.color = 0xFF4E2A2A.toInt(); c.drawOval(-16f, -228f, 16f, -206f, p)
        p.color = 0x66FFFFFF; c.drawOval(-8f, -224f, 0f, -216f, p)
        // mustache
        p.color = 0xFF1B1B1B.toInt()
        path.reset(); path.moveTo(0f, -236f); path.cubicTo(-30f, -250f, -52f, -232f, -62f, -248f); path.cubicTo(-58f, -222f, -26f, -220f, 0f, -230f)
        path.cubicTo(26f, -220f, 58f, -222f, 62f, -248f); path.cubicTo(52f, -232f, 30f, -250f, 0f, -236f); path.close(); c.drawPath(path, p)
        // mouth
        if (mood == VMood.LAUGH) {
            path.reset(); path.moveTo(-22f, -214f); path.quadTo(0f, -184f, 22f, -214f); path.close()
            p.color = 0xFF7B1F1F.toInt(); c.drawPath(path, p); ol(4f); c.drawPath(path, o)
        } else { ol(5f); path.reset(); path.moveTo(-14f, -206f); path.quadTo(4f, -196f, 18f, -212f); c.drawPath(path, o) }
        // eyes + brows
        for (sx in floatArrayOf(-1f, 1f)) {
            val ex = sx * 32f
            if (mood == VMood.LAUGH) { ol(7f); r.set(ex - 14f, -342f, ex + 14f, -318f); c.drawArc(r, 200f, 140f, false, o) }
            else {
                p.color = 0xFFFFFFFF.toInt(); c.drawOval(ex - 16f, -346f, ex + 16f, -316f, p)
                p.color = INK; c.drawCircle(ex + 3f, -328f, 8f, p)
                p.color = 0xFF8D7B6A.toInt(); r.set(ex - 18f, -350f, ex + 18f, -330f); c.drawRect(r, p) // heavy lid
                ol(5f); c.drawOval(ex - 16f, -346f, ex + 16f, -316f, o)
            }
            ol(9f); c.drawLine(ex - sx * 22f, -368f + (if (mood == VMood.ANGRY) -6f else 0f), ex + sx * 18f, -352f, o)
        }
        // monocle
        ol(6f, 0xFFFFD54F.toInt()); c.drawCircle(32f, -330f, 24f, o)
        p.color = 0x3390CAF9; c.drawCircle(32f, -330f, 22f, p)
        ol(3f, 0xFFFFD54F.toInt()); path.reset(); path.moveTo(54f, -320f); path.quadTo(80f, -260f, 60f, -200f); c.drawPath(path, o)
        // top hat
        r.set(-86f, -398f, 86f, -376f); p.color = 0xFF212121.toInt(); c.drawRoundRect(r, 11f, 11f, p); ol(6f); c.drawRoundRect(r, 11f, 11f, o)
        r.set(-52f, -500f, 52f, -390f); grad(-52f, 0f, 52f, 0f, 0xFF424242.toInt(), 0xFF111111.toInt()); c.drawRect(r, p); p.shader = null; ol(6f); c.drawRect(r, o)
        p.color = 0xFFC62828.toInt(); c.drawRect(-52f, -418f, 52f, -396f, p)
        p.color = 0xFFFFD54F.toInt(); c.drawRect(-12f, -420f, 12f, -394f, p)
        p.color = 0x22FFFFFF; c.drawRect(-40f, -494f, -28f, -424f, p)
        c.restore()
        c.restore()
    }

    // ------------------------------------------------------------------ pets
    /** Quati Fuçador: coati with miner helmet. Feet at (x,y), about 230 tall at s=1. */
    fun quati(c: Canvas, x: Float, y: Float, s: Float, t: Float, awake: Boolean) {
        c.save(); c.translate(x, y); c.scale(s, s)
        val bob = if (awake) sin(t * 4f) * 4f else sin(t * 1.5f) * 2f
        p.shader = null; p.color = 0x44000000; c.drawOval(-100f, -12f, 100f, 12f, p)
        // ringed tail
        ol(34f, INK); path.reset(); path.moveTo(50f, -50f); path.cubicTo(140f, -60f, 150f, -170f, 100f, -230f); c.drawPath(path, o)
        ol(24f, 0xFFB5733A.toInt()); c.drawPath(path, o)
        o.pathEffect = android.graphics.DashPathEffect(floatArrayOf(18f, 18f), 0f); ol(24f, 0xFF4E2A12.toInt()); o.pathEffect = android.graphics.DashPathEffect(floatArrayOf(18f, 18f), 0f); c.drawPath(path, o); o.pathEffect = null
        c.save(); c.translate(0f, bob)
        // body
        r.set(-80f, -130f, 80f, -10f); rad(-20f, -100f, 120f, 0xFFD9955A.toInt(), 0xFF8E5326.toInt()); c.drawOval(r, p); p.shader = null
        ol(7f); c.drawOval(r, o)
        p.color = 0xFFF1D3A6.toInt(); c.drawOval(-40f, -90f, 40f, -16f, p)
        p.color = 0xFF6D3F1C.toInt(); c.drawOval(-62f, -26f, -22f, 4f, p); c.drawOval(22f, -26f, 62f, 4f, p)
        // head
        for (sx in floatArrayOf(-1f, 1f)) { p.color = 0xFF8E5326.toInt(); c.drawCircle(sx * 48f, -210f, 18f, p); ol(5f); c.drawCircle(sx * 48f, -210f, 18f, o) }
        r.set(-66f, -220f, 66f, -110f); rad(-10f, -190f, 110f, 0xFFDDA06A.toInt(), 0xFF9A5D2E.toInt()); c.drawOval(r, p); p.shader = null
        ol(7f); c.drawOval(r, o)
        // long snout
        path.reset(); path.moveTo(-26f, -150f); path.quadTo(0f, -120f, 26f, -150f); path.lineTo(10f, -86f); path.quadTo(0f, -80f, -10f, -86f); path.close()
        p.color = 0xFFF1D3A6.toInt(); c.drawPath(path, p); ol(6f); c.drawPath(path, o)
        p.color = INK; c.drawOval(-12f, -96f, 12f, -80f, p)
        // eye mask markings
        p.color = 0xFFF1D3A6.toInt(); c.drawOval(-50f, -184f, -12f, -150f, p); c.drawOval(12f, -184f, 50f, -150f, p)
        if (awake) { p.color = INK; c.drawCircle(-30f, -166f, 9f, p); c.drawCircle(30f, -166f, 9f, p); p.color = -1; c.drawCircle(-27f, -169f, 3f, p); c.drawCircle(33f, -169f, 3f, p) }
        else { ol(5f); c.drawLine(-40f, -164f, -20f, -164f, o); c.drawLine(20f, -164f, 40f, -164f, o) }
        // miner helmet + lamp
        r.set(-58f, -246f, 58f, -186f); p.color = 0xFFFFC107.toInt(); c.drawArc(r, 180f, 180f, true, p); ol(6f); c.drawArc(r, 180f, 180f, true, o)
        r.set(-66f, -220f, 66f, -206f); p.color = 0xFFFFA000.toInt(); c.drawRoundRect(r, 7f, 7f, p); ol(5f); c.drawRoundRect(r, 7f, 7f, o)
        if (awake) Art.glow(c, 0f, -234f, 60f, 0xFFFFF59D.toInt(), 0.9f)
        p.color = if (awake) 0xFFFFFDE7.toInt() else 0xFFBDBDBD.toInt(); c.drawCircle(0f, -234f, 13f, p); ol(4f); c.drawCircle(0f, -234f, 13f, o)
        c.restore()
        if (!awake) zzz(c, 60f, -250f, t)
        c.restore()
    }

    /** Onça Guerreira: jaguar cub with a red warrior headband. */
    fun onca(c: Canvas, x: Float, y: Float, s: Float, t: Float, awake: Boolean) {
        c.save(); c.translate(x, y); c.scale(s, s)
        val bob = if (awake) sin(t * 4f) * 4f else sin(t * 1.5f) * 2f
        p.shader = null; p.color = 0x44000000; c.drawOval(-100f, -12f, 100f, 12f, p)
        // tail
        ol(26f, INK); path.reset(); path.moveTo(60f, -40f); path.cubicTo(140f, -40f, 130f, -140f, 160f, -150f); c.drawPath(path, o)
        ol(16f, 0xFFF2B33D.toInt()); c.drawPath(path, o)
        p.color = INK; c.drawCircle(158f, -150f, 10f, p)
        c.save(); c.translate(0f, bob)
        r.set(-82f, -130f, 82f, -10f); rad(-20f, -100f, 120f, 0xFFFFD27A.toInt(), 0xFFDB8F1E.toInt()); c.drawOval(r, p); p.shader = null
        ol(7f); c.drawOval(r, o)
        p.color = 0xFFFFF3DC.toInt(); c.drawOval(-42f, -90f, 42f, -16f, p)
        spots(c, floatArrayOf(-60f, -80f, 56f, -86f, -40f, -40f, 50f, -36f, 0f, -118f))
        p.color = 0xFFDB8F1E.toInt(); c.drawOval(-64f, -26f, -22f, 4f, p); c.drawOval(22f, -26f, 64f, 4f, p); ol(5f); c.drawOval(-64f, -26f, -22f, 4f, o); c.drawOval(22f, -26f, 64f, 4f, o)
        // ears
        for (sx in floatArrayOf(-1f, 1f)) { p.color = 0xFFDB8F1E.toInt(); c.drawCircle(sx * 56f, -214f, 24f, p); ol(6f); c.drawCircle(sx * 56f, -214f, 24f, o); p.color = 0xFF5D3A1A.toInt(); c.drawCircle(sx * 56f, -212f, 10f, p) }
        r.set(-78f, -232f, 78f, -104f); rad(-10f, -200f, 120f, 0xFFFFDA8A.toInt(), 0xFFE39A2A.toInt()); c.drawOval(r, p); p.shader = null
        ol(7f); c.drawOval(r, o)
        spots(c, floatArrayOf(-46f, -200f, 46f, -204f, -60f, -160f, 60f, -158f))
        // headband
        r.set(-78f, -206f, 78f, -186f); p.color = 0xFFE53935.toInt(); c.drawRect(r, p)
        path.reset(); path.moveTo(70f, -200f); path.lineTo(110f, -214f + sin(t * 8f) * 6f); path.lineTo(104f, -190f); path.close(); c.drawPath(path, p)
        // muzzle
        p.color = 0xFFFFF3DC.toInt(); c.drawOval(-40f, -150f, 40f, -108f, p)
        p.color = 0xFF5D3A1A.toInt(); path.reset(); path.moveTo(-12f, -144f); path.lineTo(12f, -144f); path.lineTo(0f, -130f); path.close(); c.drawPath(path, p)
        ol(4f); path.reset(); path.moveTo(-14f, -120f); path.quadTo(0f, -112f, 0f, -128f); path.quadTo(0f, -112f, 14f, -120f); c.drawPath(path, o)
        ol(3f, 0xAA5D3A1A.toInt()); c.drawLine(-36f, -130f, -72f, -138f, o); c.drawLine(-36f, -124f, -72f, -120f, o); c.drawLine(36f, -130f, 72f, -138f, o); c.drawLine(36f, -124f, 72f, -120f, o)
        if (awake) {
            for (sx in floatArrayOf(-1f, 1f)) { p.color = 0xFF66BB6A.toInt(); c.drawOval(sx * 30f - 13f, -178f, sx * 30f + 13f, -152f, p); p.color = INK; c.drawOval(sx * 30f - 5f, -176f, sx * 30f + 5f, -154f, p); p.color = -1; c.drawCircle(sx * 30f - 4f, -170f, 3f, p) }
        } else { ol(5f); c.drawLine(-42f, -164f, -18f, -164f, o); c.drawLine(18f, -164f, 42f, -164f, o) }
        c.restore()
        if (!awake) zzz(c, 70f, -250f, t)
        c.restore()
    }

    private fun spots(c: Canvas, pts: FloatArray) {
        var i = 0
        while (i < pts.size) {
            ol(5f, 0xFF5D3A1A.toInt()); c.drawCircle(pts[i], pts[i + 1], 11f, o)
            p.color = 0xFF5D3A1A.toInt(); c.drawCircle(pts[i], pts[i + 1], 3f, p)
            i += 2
        }
    }

    /** Tucano Guardião: toucan with a tiny knight helmet. */
    fun tucano(c: Canvas, x: Float, y: Float, s: Float, t: Float, awake: Boolean) {
        c.save(); c.translate(x, y); c.scale(s, s)
        val bob = if (awake) sin(t * 4f) * 4f else sin(t * 1.5f) * 2f
        p.shader = null; p.color = 0x44000000; c.drawOval(-80f, -12f, 80f, 12f, p)
        p.color = 0xFFFF8F00.toInt(); ol(6f)
        c.drawLine(-20f, -40f, -24f, 0f, o); c.drawLine(20f, -40f, 24f, 0f, o)
        c.save(); c.translate(0f, bob)
        // body
        r.set(-70f, -230f, 70f, -30f); rad(-20f, -180f, 160f, 0xFF424242.toInt(), 0xFF111111.toInt()); c.drawOval(r, p); p.shader = null
        ol(7f); c.drawOval(r, o)
        p.color = 0xFFFFF59D.toInt(); c.drawOval(-44f, -190f, 44f, -110f, p)
        p.color = 0xFFE53935.toInt(); c.drawOval(-30f, -112f, 30f, -84f, p)
        // wing
        val flap = if (awake) sin(t * 6f) * 10f else 0f
        c.save(); c.rotate(-10f + flap, 50f, -160f)
        r.set(30f, -170f, 90f, -60f); p.color = 0xFF263238.toInt(); c.drawOval(r, p); ol(6f); c.drawOval(r, o)
        c.restore()
        // eye
        if (awake) {
            p.color = 0xFF29B6F6.toInt(); c.drawCircle(-14f, -200f, 22f, p)
            p.color = INK; c.drawCircle(-12f, -200f, 9f, p); p.color = -1; c.drawCircle(-15f, -203f, 3f, p)
        } else { p.color = 0xFF29B6F6.toInt(); c.drawCircle(-14f, -200f, 22f, p); ol(5f); c.drawLine(-26f, -200f, -2f, -200f, o) }
        // huge beak
        path.reset(); path.moveTo(-4f, -214f); path.cubicTo(-80f, -230f, -170f, -200f, -186f, -170f); path.cubicTo(-150f, -168f, -60f, -168f, -4f, -178f); path.close()
        grad(-186f, 0f, 0f, 0f, 0xFFFF6F00.toInt(), 0xFFFFEB3B.toInt()); c.drawPath(path, p); p.shader = null
        ol(7f); c.drawPath(path, o)
        p.color = INK; path.reset(); path.moveTo(-186f, -170f); path.lineTo(-160f, -190f); path.lineTo(-150f, -170f); path.close(); c.drawPath(path, p)
        ol(4f, 0xAA8D2B0B.toInt()); c.drawLine(-10f, -194f, -150f, -184f, o)
        // knight helmet
        r.set(-50f, -268f, 50f, -206f); grad(0f, -268f, 0f, -206f, 0xFFECEFF1.toInt(), 0xFF78909C.toInt()); c.drawArc(r, 180f, 180f, true, p); p.shader = null
        ol(6f); c.drawArc(r, 180f, 180f, true, o)
        p.color = 0xFFE53935.toInt(); path.reset(); path.moveTo(0f, -268f); path.quadTo(30f, -310f, 60f, -300f + sin(t * 6f) * 5f); path.quadTo(30f, -290f, 8f, -262f); path.close(); c.drawPath(path, p)
        c.restore()
        if (!awake) zzz(c, 50f, -280f, t)
        c.restore()
    }

    fun pet(c: Canvas, key: String, x: Float, y: Float, s: Float, t: Float, awake: Boolean) {
        when (key) {
            "quati" -> quati(c, x, y, s, t, awake)
            "onca" -> onca(c, x, y, s, t, awake)
            else -> tucano(c, x, y, s, t, awake)
        }
    }

    private fun zzz(c: Canvas, x: Float, y: Float, t: Float) {
        for (k in 0..2) {
            val ph = (t * 0.6f + k / 3f) % 1f
            Ui.text(c, "z", x + ph * 50f, y - ph * 80f, 34f + k * 8f, 0xFFE3F2FD.toInt(), alpha = 1f - ph, ow = 5f)
        }
    }

    // ------------------------------------------------------------------ boat for the voyage cutscene
    fun boat(c: Canvas, x: Float, y: Float, s: Float, t: Float, villain: Boolean = false) {
        c.save(); c.translate(x, y + sin(t * 2.4f) * 8f); c.rotate(sin(t * 1.8f) * 3f); c.scale(s, s)
        // mast + sail
        ol(10f); c.drawLine(0f, -40f, 0f, -330f, o); ol(6f, 0xFF5D4037.toInt()); c.drawLine(0f, -40f, 0f, -330f, o)
        path.reset(); path.moveTo(8f, -320f); path.quadTo(150f + sin(t * 3f) * 10f, -220f, 8f, -90f); path.close()
        p.color = if (villain) 0xFF212121.toInt() else 0xFFFFF8E1.toInt(); c.drawPath(path, p); ol(6f); c.drawPath(path, o)
        if (villain) { p.color = -1; c.drawCircle(60f, -210f, 18f, p); ol(4f, -1); c.drawLine(42f, -186f, 78f, -170f, o); c.drawLine(78f, -186f, 42f, -170f, o) }
        else { p.color = 0xFFF57C00.toInt(); c.drawCircle(56f, -206f, 22f, p); p.color = 0xFF7CB342.toInt(); c.drawOval(52f, -236f, 72f, -224f, p) }
        path.reset(); path.moveTo(-8f, -300f); path.quadTo(-110f, -200f, -8f, -110f); path.close()
        p.color = if (villain) 0xFF424242.toInt() else 0xFFFFECB3.toInt(); c.drawPath(path, p); ol(6f); c.drawPath(path, o)
        // flag
        p.color = if (villain) 0xFF7B1FA2.toInt() else 0xFFE53935.toInt()
        path.reset(); path.moveTo(0f, -330f); path.lineTo(60f, -316f + sin(t * 8f) * 6f); path.lineTo(0f, -302f); path.close(); c.drawPath(path, p)
        // hull
        path.reset(); path.moveTo(-170f, -60f); path.lineTo(170f, -60f); path.lineTo(130f, 10f); path.lineTo(-130f, 10f); path.close()
        grad(0f, -60f, 0f, 10f, if (villain) 0xFF4E342E.toInt() else 0xFFA1887F.toInt(), if (villain) 0xFF1B0F0B.toInt() else 0xFF5D4037.toInt()); c.drawPath(path, p); p.shader = null
        ol(7f); c.drawPath(path, o)
        p.color = if (villain) 0xFFFFD54F.toInt() else 0xFFFFFFFF.toInt(); c.drawRect(-150f, -48f, 150f, -38f, p)
        for (k in -2..2) { p.color = 0xFF263238.toInt(); c.drawCircle(k * 50f, -20f, 9f, p) }
        c.restore()
    }

    /** Island silhouette growing on the horizon. */
    fun island(c: Canvas, x: Float, y: Float, s: Float, th: Theme) {
        c.save(); c.translate(x, y); c.scale(s, s)
        p.color = th.ground2; r.set(-260f, -60f, 260f, 40f); c.drawOval(r, p)
        p.color = th.ground1; r.set(-220f, -90f, 220f, 10f); c.drawOval(r, p)
        p.color = th.roof; path.reset(); path.moveTo(-60f, -80f); path.lineTo(0f, -160f); path.lineTo(60f, -80f); path.close(); c.drawPath(path, p)
        p.color = th.wall; c.drawRect(-44f, -82f, 44f, -40f, p)
        p.color = 0xFF2E7D32.toInt(); c.drawCircle(-150f, -90f, 40f, p); c.drawCircle(150f, -84f, 34f, p)
        c.restore()
    }
}
