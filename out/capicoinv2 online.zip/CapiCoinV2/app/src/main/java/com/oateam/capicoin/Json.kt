package com.oateam.capicoin

/** Tiny dependency-free JSON parser/writer. */
object Json {
    fun parse(s: String): Any? = P(s).run { ws(); val v = value(); ws(); v }

    private class P(val s: String) {
        var i = 0
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun value(): Any? {
            ws()
            if (i >= s.length) throw IllegalArgumentException("json: fim inesperado")
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> { expect("true"); true }
                'f' -> { expect("false"); false }
                'n' -> { expect("null"); null }
                else -> if (c == '-' || c.isDigit()) num() else throw IllegalArgumentException("json: '$c' em $i")
            }
        }
        fun expect(w: String) { if (!s.startsWith(w, i)) throw IllegalArgumentException("json: esperado $w"); i += w.length }
        fun obj(): Map<String, Any?> {
            val m = LinkedHashMap<String, Any?>()
            i++; ws()
            if (s[i] == '}') { i++; return m }
            while (true) {
                ws(); val k = str(); ws()
                if (s[i] != ':') throw IllegalArgumentException("json: ':' esperado"); i++
                m[k] = value(); ws()
                when (s[i]) { ',' -> i++; '}' -> { i++; return m }; else -> throw IllegalArgumentException("json: ',' ou '}'") }
            }
        }
        fun arr(): List<Any?> {
            val l = ArrayList<Any?>()
            i++; ws()
            if (s[i] == ']') { i++; return l }
            while (true) {
                l.add(value()); ws()
                when (s[i]) { ',' -> i++; ']' -> { i++; return l }; else -> throw IllegalArgumentException("json: ',' ou ']'") }
            }
        }
        fun str(): String {
            val sb = StringBuilder()
            i++
            while (true) {
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        when (val e = s[i++]) {
                            'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r'); 'b' -> sb.append('\b'); 'f' -> sb.append('\u000c')
                            'u' -> { sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                            else -> sb.append(e)
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }
        fun num(): Any {
            val st = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' || s[i] == '-')) i++
            val t = s.substring(st, i)
            return if (t.contains('.') || t.contains('e') || t.contains('E')) t.toDouble() else (t.toLongOrNull() ?: t.toDouble())
        }
    }

    fun write(v: Any?): String = StringBuilder().also { w(it, v) }.toString()

    private fun w(sb: StringBuilder, v: Any?) {
        when (v) {
            null -> sb.append("null")
            is String -> { sb.append('"'); for (c in v) when (c) { '"' -> sb.append("\\\""); '\\' -> sb.append("\\\\"); '\n' -> sb.append("\\n"); '\r' -> sb.append("\\r"); '\t' -> sb.append("\\t"); else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c) }; sb.append('"') }
            is Boolean, is Int, is Long -> sb.append(v.toString())
            is Number -> { val d = v.toDouble(); if (d == Math.floor(d) && !d.isInfinite() && Math.abs(d) < 1e15) sb.append(d.toLong()) else sb.append(d) }
            is Map<*, *> -> { sb.append('{'); var first = true; for ((k, x) in v) { if (!first) sb.append(','); first = false; w(sb, k.toString()); sb.append(':'); w(sb, x) }; sb.append('}') }
            is Iterable<*> -> { sb.append('['); var first = true; for (x in v) { if (!first) sb.append(','); first = false; w(sb, x) }; sb.append(']') }
            is IntArray -> w(sb, v.toList())
            else -> w(sb, v.toString())
        }
    }
}

/** Convenience wrapper for reading parsed JSON safely. */
class J(val v: Any?) {
    operator fun get(k: String): J = J((v as? Map<*, *>)?.get(k))
    operator fun get(i: Int): J = J((v as? List<*>)?.getOrNull(i))
    val isNull: Boolean get() = v == null
    fun has(k: String) = (v as? Map<*, *>)?.containsKey(k) == true && (v as Map<*, *>)[k] != null
    fun str(d: String = ""): String = when (v) { null -> d; is String -> v; else -> v.toString() }
    fun strOrNull(): String? = v as? String
    fun int(d: Int = 0): Int = (v as? Number)?.toInt() ?: d
    fun long(d: Long = 0): Long = (v as? Number)?.toLong() ?: d
    fun dbl(d: Double = 0.0): Double = (v as? Number)?.toDouble() ?: d
    fun bool(d: Boolean = false): Boolean = (v as? Boolean) ?: d
    val list: List<J> get() = (v as? List<*>)?.map { J(it) } ?: emptyList()
    val keys: List<String> get() = (v as? Map<*, *>)?.keys?.map { it.toString() } ?: emptyList()
    val size: Int get() = (v as? List<*>)?.size ?: (v as? Map<*, *>)?.size ?: 0
    override fun toString(): String = Json.write(v)
    companion object { fun parse(s: String): J = try { J(Json.parse(s)) } catch (e: Exception) { J(null) } }
}
