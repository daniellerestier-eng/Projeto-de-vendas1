package com.oateam.capicoin

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator

class Audio(private val ctx: Context, private val st: Settings) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(12)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()

    private val ids = HashMap<String, Int>()
    private var music: MediaPlayer? = null
    private var spinStream = 0
    private val lastPlay = HashMap<String, Long>()
    @Suppress("DEPRECATION")
    private val vibrator: Vibrator? = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    init {
        val map = mapOf(
            "click" to R.raw.sfx_click, "coin" to R.raw.sfx_coin, "coins_big" to R.raw.sfx_coins_big,
            "spin" to R.raw.sfx_spin, "stop" to R.raw.sfx_stop, "win" to R.raw.sfx_win,
            "jackpot" to R.raw.sfx_jackpot, "whoosh" to R.raw.sfx_whoosh, "hammer" to R.raw.sfx_hammer,
            "crumble" to R.raw.sfx_crumble, "shield" to R.raw.sfx_shield, "dig" to R.raw.sfx_dig,
            "build" to R.raw.sfx_build, "complete" to R.raw.sfx_complete, "pop" to R.raw.sfx_pop,
            "alarm" to R.raw.sfx_alarm, "chest" to R.raw.sfx_chest, "tick" to R.raw.sfx_tick,
            "gem" to R.raw.sfx_gem, "notify" to R.raw.sfx_notify, "blip" to R.raw.sfx_blip, "pet" to R.raw.sfx_pet,
            "cash" to R.raw.sfx_cash, "turbo" to R.raw.sfx_turbo, "bigwin" to R.raw.sfx_bigwin, "laugh" to R.raw.sfx_laugh
        )
        for ((k, v) in map) ids[k] = pool.load(ctx, v, 1)
    }

    /** Plays a sound effect. minGapMs throttles very frequent sounds (coin ticks). */
    fun play(name: String, vol: Float = 1f, rate: Float = 1f, minGapMs: Long = 0) {
        if (!st.sfx) return
        val id = ids[name] ?: return
        if (minGapMs > 0) {
            val now = System.currentTimeMillis()
            if (now - (lastPlay[name] ?: 0L) < minGapMs) return
            lastPlay[name] = now
        }
        pool.play(id, vol, vol, 1, 0, rate.coerceIn(0.5f, 2f))
    }

    fun startSpinLoop() {
        if (!st.sfx) return
        stopSpinLoop()
        val id = ids["spin"] ?: return
        spinStream = pool.play(id, 0.7f, 0.7f, 2, -1, 1f)
    }

    fun stopSpinLoop() {
        if (spinStream != 0) pool.stop(spinStream)
        spinStream = 0
    }

    fun startMusic() {
        if (!st.music) return
        if (music == null) {
            music = MediaPlayer.create(ctx, R.raw.music_loop)?.apply {
                isLooping = true
                setVolume(0.38f, 0.38f)
            }
        }
        try { if (music?.isPlaying == false) music?.start() } catch (e: Exception) {}
    }

    fun pauseMusic() {
        try { if (music?.isPlaying == true) music?.pause() } catch (e: Exception) {}
    }

    fun refreshMusic() { if (st.music) startMusic() else pauseMusic() }

    fun vibrate(ms: Long, strength: Int = 120) {
        if (!st.vibe) return
        val v = vibrator ?: return
        try {
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, strength.coerceIn(1, 255)))
            else v.vibrate(ms)
        } catch (e: Exception) {}
    }

    fun pauseAll() { pauseMusic(); pool.autoPause(); stopSpinLoop() }
    fun resumeAll() { pool.autoResume(); startMusic() }

    fun release() {
        pool.release()
        music?.release(); music = null
    }
}
